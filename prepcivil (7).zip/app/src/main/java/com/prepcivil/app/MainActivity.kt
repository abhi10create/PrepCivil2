package com.prepcivil.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.prepcivil.app.db.AppSyncRepository
import com.prepcivil.app.model.CardRating
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.StudyRepository
import com.prepcivil.app.model.Subject
import com.prepcivil.app.model.SyllabusProgressManager
import com.prepcivil.app.ui.components.AppTab
import com.prepcivil.app.ui.components.DashboardPane
import com.prepcivil.app.ui.components.ERegisterCanvasPane
import com.prepcivil.app.ui.components.FlashcardsPane
import com.prepcivil.app.ui.components.FooterStatusBar
import com.prepcivil.app.ui.components.LoginScreen
import com.prepcivil.app.ui.components.MasterbankPane
import com.prepcivil.app.ui.components.PyqPane
import com.prepcivil.app.ui.components.ReaderPane
import com.prepcivil.app.ui.components.TopNavBar
import com.prepcivil.app.ui.components.WorkspaceSplitScreenView
import com.prepcivil.app.ui.theme.AppTheme
import com.prepcivil.app.ui.theme.PrepCivilTheme
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      com.google.android.gms.security.ProviderInstaller.installIfNeeded(this)
    } catch (e: SecurityException) {
      android.util.Log.w("MainActivity", "ProviderInstaller SecurityException safely caught: ${e.message}")
    } catch (e: Exception) {
      android.util.Log.w("MainActivity", "ProviderInstaller Exception safely caught: ${e.message}")
    }
    enableEdgeToEdge()
    setContent {
      EduStudyApp()
    }
  }
}

@Composable
fun EduStudyApp(viewModel: MainViewModel = viewModel()) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val syncRepository = remember { AppSyncRepository(context) }

  var showSplashScreen by remember { mutableStateOf(true) }
  val isAuthChecking by viewModel.isAuthChecking.collectAsStateWithLifecycle()
  var timerFinished by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    kotlinx.coroutines.delay(2000L)
    timerFinished = true
  }

  // 3-second timeout fallback in case auth check is slow or offline
  LaunchedEffect(Unit) {
    kotlinx.coroutines.delay(3000L)
    showSplashScreen = false
  }

  LaunchedEffect(timerFinished, isAuthChecking) {
    if (timerFinished && !isAuthChecking) {
      showSplashScreen = false
    }
  }

  val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
  val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
  val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
  val currentUserEmailState by viewModel.currentUserEmail.collectAsStateWithLifecycle()

  var subjects by remember { mutableStateOf(StudyRepository.subjects) }
  var selectedSubject by remember { mutableStateOf(subjects.first()) }
  var selectedChapter by remember { mutableStateOf(selectedSubject.chapters.first()) }
  var activeTab by remember { mutableStateOf(AppTab.DASHBOARD) }

  // Local Persistent Completion Tracking with Room DB
  val roomCompletedIds by syncRepository.completedChapterIdsFlow.collectAsStateWithLifecycle(
    initialValue = SyllabusProgressManager.getCompletedChapterIds(context)
  )
  val heatmapSessions by syncRepository.heatmapDataFlow.collectAsStateWithLifecycle(
    initialValue = emptyList()
  )
  val syncStatusText by syncRepository.syncStatusText.collectAsStateWithLifecycle()
  val isSyncing by syncRepository.isSyncing.collectAsStateWithLifecycle()

  var completedChapterIds by remember { mutableStateOf(SyllabusProgressManager.getCompletedChapterIds(context)) }

  val effectiveCompletedChapterIds = remember(completedChapterIds, roomCompletedIds) {
    completedChapterIds + roomCompletedIds
  }

  val masteryPercentage = remember(subjects, effectiveCompletedChapterIds) {
    SyllabusProgressManager.calculateOverallMastery(subjects, effectiveCompletedChapterIds)
  }

  val isProUser by viewModel.isProUser.collectAsStateWithLifecycle()
  val activePlanType by viewModel.activePlanType.collectAsStateWithLifecycle()
  var mainsDailyLimitUsed by remember { mutableIntStateOf(0) }
  var showUpgradeModal by remember { mutableStateOf(false) }
  var isZenMode by remember { mutableStateOf(false) }
  var isAdminAuthenticated by remember { mutableStateOf(false) }
  var showAdminAuthModal by remember { mutableStateOf(false) }
  var accessDeniedNotification by remember { mutableStateOf<String?>(null) }

  val toggleChapterCompletion: (String) -> Unit = { chapterId ->
    coroutineScope.launch {
      syncRepository.toggleChapterCompleted(chapterId)
    }
    val updatedSet = SyllabusProgressManager.toggleChapterCompleted(context, chapterId).second
    completedChapterIds = updatedSet
  }

  PrepCivilTheme(darkTheme = isDarkMode) {
    if (showSplashScreen) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0xFF0D0C12))
          .statusBarsPadding()
          .navigationBarsPadding(),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier
              .size(112.dp)
              .clip(CircleShape)
              .background(Color(0xFF1C1B24))
              .border(1.dp, Color(0xFF8B5CF6), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Image(
              painter = painterResource(id = R.drawable.ic_prep_civil_logo),
              contentDescription = "PrepCivil Logo",
              modifier = Modifier.size(64.dp)
            )
          }
          Spacer(modifier = Modifier.height(20.dp))
          Text(
            text = "PrepCivil",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFFFFFF)
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Empowering Civil Services Aspirants",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF9CA3AF)
          )
        }
      }
    } else if (!isLoggedIn) {
      LoginScreen(
        onLoginSuccess = { uid, email ->
          viewModel.onUserAuthenticated(uid, email)
        }
      )
    } else {
      Scaffold(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding()
          .testTag("main_scaffold"),
        topBar = {
          if (!isZenMode || activeTab != AppTab.WORKSPACE) {
            TopNavBar(
              activeTab = activeTab,
              onTabSelected = { newTab ->
                if (newTab == AppTab.ADMIN) {
                  if (!isAdmin) {
                    android.widget.Toast.makeText(context, "Access Denied: Admin privileges required.", android.widget.Toast.LENGTH_SHORT).show()
                    activeTab = AppTab.DASHBOARD
                  } else if (isAdminAuthenticated) {
                    activeTab = AppTab.ADMIN
                  } else {
                    showAdminAuthModal = true
                  }
                } else {
                  activeTab = newTab
                }
              },
              isDarkMode = isDarkMode,
              onToggleDarkMode = {
                viewModel.toggleDarkMode(isDarkMode)
              },
              isSubscribed = isProUser,
              currentUserEmail = currentUserEmailState.ifBlank { "sabhishek607@gmail.com" },
              isAdmin = isAdmin,
              onUpgradeToPro = { showUpgradeModal = true },
              onLogout = {
                viewModel.signOut()
              }
            )
          }
        },
        bottomBar = {}
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(MaterialTheme.colorScheme.background)
        ) {
          when (activeTab) {
            AppTab.DASHBOARD -> {
              DashboardPane(
                masteryPercentage = masteryPercentage,
                subjects = subjects,
                completedChapterIds = effectiveCompletedChapterIds,
                heatmapSessions = heatmapSessions,
                onSelectSubject = { subject ->
                  selectedSubject = subject
                  selectedChapter = subject.chapters.first()
                  activeTab = AppTab.WORKSPACE
                },
                onStartSrsReview = {
                  activeTab = AppTab.FLASHCARDS
                },
                isProUser = isProUser,
                onOpenUpgradeModal = {
                  showUpgradeModal = true
                },
                isAdmin = isAdmin,
                onOpenAdminPanel = {
                  if (!isAdmin) {
                    android.widget.Toast.makeText(context, "Access Denied: Admin privileges required.", android.widget.Toast.LENGTH_SHORT).show()
                  } else if (isAdminAuthenticated) {
                    activeTab = AppTab.ADMIN
                  } else {
                    showAdminAuthModal = true
                  }
                }
              )
            }
            AppTab.WORKSPACE -> {
              WorkspaceSplitScreenView(
                selectedSubject = selectedSubject,
                subjects = subjects,
                onSubjectSelected = { newSubject: Subject ->
                  selectedSubject = newSubject
                  selectedChapter = newSubject.chapters.first()
                },
                selectedChapter = selectedChapter,
                chapters = selectedSubject.chapters,
                onChapterSelected = { newChapter: Chapter ->
                  selectedChapter = newChapter
                },
                completedChapterIds = effectiveCompletedChapterIds,
                onToggleChapterCompleted = toggleChapterCompletion,
                isProUser = isProUser,
                onOpenUpgradeModal = {
                  showUpgradeModal = true
                },
                isZenMode = isZenMode,
                onToggleZenMode = { isZenMode = !isZenMode },
                syncRepository = syncRepository
              )
            }
            AppTab.PYQS -> {
              PyqPane(
                subjects = subjects,
                initialSubject = selectedSubject,
                initialChapter = selectedChapter
              )
            }
            AppTab.FLASHCARDS -> {
              FlashcardsPane(
                subjects = subjects,
                initialSubject = selectedSubject,
                initialChapter = selectedChapter,
                syncRepository = syncRepository,
                onRatingUpdated = { _ ->
                  // Progress is purely driven by completed chapters / check-ins
                }
              )
            }
            AppTab.MASTERBANK -> {
              MasterbankPane(
                subjects = subjects,
                initialSubject = selectedSubject,
                initialChapter = selectedChapter,
                onQuizCompleted = { _, _ ->
                  // Progress is purely driven by completed chapters / check-ins
                }
              )
            }
          AppTab.MAINS_AI -> {
            com.prepcivil.app.ui.components.MainsAiPane(
              isProUser = isProUser,
              dailyLimitUsed = mainsDailyLimitUsed,
              dailyLimitMax = if (isProUser) 3 else 5,
              onIncrementUsage = {
                mainsDailyLimitUsed++
              },
              onOpenUpgradeModal = {
                showUpgradeModal = true
              }
            )
          }
          AppTab.STORE -> {
            com.prepcivil.app.ui.components.StorePane(
              isProUser = isProUser,
              activePlanType = activePlanType,
              onOpenUpgradeModal = {
                showUpgradeModal = true
              },
              onUpgradeMonthly = {
                viewModel.upgradeToPro("monthly")
              },
              onUpgradeAnnual = {
                viewModel.upgradeToPro("annual")
              }
            )
          }
          AppTab.ADMIN -> {
            if (!isAdmin) {
              android.widget.Toast.makeText(context, "Access Denied: Admin privileges required.", android.widget.Toast.LENGTH_SHORT).show()
              activeTab = AppTab.DASHBOARD
            } else {
              com.prepcivil.app.ui.components.AdminPane(
                isAdminAuthenticated = isAdminAuthenticated,
                currentUserEmail = currentUserEmailState.ifBlank { "sabhishek607@gmail.com" },
                onLogoutAdmin = {
                  isAdminAuthenticated = false
                  activeTab = AppTab.DASHBOARD
                },
                onReturnToDashboard = {
                  activeTab = AppTab.DASHBOARD
                },
                onPublishChapter = { targetSubjectName, newChapter ->
                  val existingSubject = subjects.find { it.name.equals(targetSubjectName, ignoreCase = true) }
                  if (existingSubject != null) {
                    val updatedSubject = existingSubject.copy(
                      chapters = existingSubject.chapters + newChapter
                    )
                    subjects = subjects.map { if (it.id == existingSubject.id) updatedSubject else it }
                    selectedSubject = updatedSubject
                    selectedChapter = newChapter
                  } else {
                    val newSubId = "sub_${targetSubjectName.lowercase().replace(Regex("[^a-z0-9]"), "_")}"
                    val newSubject = Subject(
                      id = newSubId,
                      name = targetSubjectName,
                      chapters = listOf(newChapter)
                    )
                    subjects = subjects + newSubject
                    selectedSubject = newSubject
                    selectedChapter = newChapter
                  }
                }
              )
            }
          }
        }

        if (showAdminAuthModal) {
          com.prepcivil.app.ui.components.AdminAuthModal(
            onDismiss = { showAdminAuthModal = false },
            onAuthenticateSuccess = {
              isAdminAuthenticated = true
              activeTab = AppTab.ADMIN
              accessDeniedNotification = null
            },
            onAccessDenied = {
              accessDeniedNotification = "Access Denied: Restricted to Authorized Administrators"
              activeTab = AppTab.DASHBOARD
            }
          )
        }

        if (showUpgradeModal) {
          com.prepcivil.app.ui.components.ProUpgradeModal(
            onDismiss = { showUpgradeModal = false },
            onUpgradeSuccess = { planType ->
              viewModel.upgradeToPro(planType)
            }
          )
        }
      }
    }
  }
}
}

// WorkspaceSplitScreenView moved to its own file.
