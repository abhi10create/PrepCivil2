package com.prepcivil.app

import android.app.Application
import android.util.Log

class PrepCivilApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            com.google.android.gms.security.ProviderInstaller.installIfNeeded(this)
        } catch (e: SecurityException) {
            Log.w("PrepCivilApplication", "ProviderInstaller SecurityException safely caught: ${e.message}")
        } catch (e: Exception) {
            Log.w("PrepCivilApplication", "ProviderInstaller Exception safely caught: ${e.message}")
        }
    }
}
