package com.prepcivil.app.ui.components

import android.widget.Toast
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.ui.theme.CanvasBackground
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

data class DrawPath(
  val path: Path,
  val color: Color,
  val strokeWidth: Float,
  val alpha: Float = 1f,
  val isEraser: Boolean = false
)

enum class CanvasTool {
  PEN, HIGHLIGHTER, ERASER
}

@Composable
fun ERegisterCanvasPane(
  chapterId: String = "global",
  syncRepository: com.prepcivil.app.db.AppSyncRepository? = null,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
  val canvasBgColor = MaterialTheme.colorScheme.surface
  val gridBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
  val primaryAccentColor = PurpleAccent
  val onSurfaceColor = MaterialTheme.colorScheme.onSurface

  var activeTool by remember { mutableStateOf(CanvasTool.PEN) }
  var selectedColor by remember(primaryAccentColor) { mutableStateOf(primaryAccentColor) }
  var strokeWidth by remember { mutableFloatStateOf(6f) }
  var savedNotification by remember { mutableStateOf<String?>(null) }

  val paths = remember { mutableStateListOf<DrawPath>() }
  val undoStack = remember { mutableStateListOf<DrawPath>() }

  // High-performance real-time drawing state
  var currentPathState by remember { mutableStateOf<DrawPath?>(null) }
  var drawTrigger by remember { mutableIntStateOf(0) }

  val availableColors = listOf(
    primaryAccentColor,
    Color(0xFF81D4FA), // Cyan
    Color(0xFFA5D6A7), // Green
    Color(0xFFFFF59D), // Yellow
    Color(0xFFFFAB91), // Orange/Red
    onSurfaceColor
  )

  val strokeWidths = listOf(
    3f to "Fine",
    6f to "Medium",
    12f to "Bold",
    24f to "X-Bold"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .border(1.dp, MaterialTheme.colorScheme.outline)
  ) {
    // Toolbar Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outline)
        .padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Tool Selector & Undo/Redo Buttons
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        // Pen Tool Button
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (activeTool == CanvasTool.PEN) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .border(
              1.dp,
              if (activeTool == CanvasTool.PEN) PurpleAccent else Color.Transparent,
              RoundedCornerShape(8.dp)
            )
            .clickable { activeTool = CanvasTool.PEN }
            .testTag("pen_tool"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Create,
            contentDescription = "Pen Tool",
            tint = PurpleAccent,
            modifier = Modifier.size(18.dp)
          )
        }

        // Highlighter Tool Button
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (activeTool == CanvasTool.HIGHLIGHTER) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .border(
              1.dp,
              if (activeTool == CanvasTool.HIGHLIGHTER) Color(0xFFFFF59D) else Color.Transparent,
              RoundedCornerShape(8.dp)
            )
            .clickable {
              activeTool = CanvasTool.HIGHLIGHTER
              strokeWidth = 24f
            }
            .testTag("highlighter_tool"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.FormatPaint,
            contentDescription = "Highlighter Tool",
            tint = Color(0xFFFFF59D),
            modifier = Modifier.size(18.dp)
          )
        }

        // Eraser Button
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (activeTool == CanvasTool.ERASER) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .border(
              1.dp,
              if (activeTool == CanvasTool.ERASER) PurpleAccent else Color.Transparent,
              RoundedCornerShape(8.dp)
            )
            .clickable { activeTool = CanvasTool.ERASER }
            .testTag("eraser_tool"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Backspace,
            contentDescription = "Eraser Tool",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
        }

        // Undo Button
        IconButton(
          onClick = {
            if (paths.isNotEmpty()) {
              val removed = paths.removeAt(paths.lastIndex)
              undoStack.add(removed)
            }
          },
          enabled = paths.isNotEmpty(),
          modifier = Modifier.size(34.dp).testTag("canvas_undo")
        ) {
          Icon(
            imageVector = Icons.Default.Undo,
            contentDescription = "Undo",
            tint = if (paths.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(18.dp)
          )
        }

        // Redo Button
        IconButton(
          onClick = {
            if (undoStack.isNotEmpty()) {
              val restored = undoStack.removeAt(undoStack.lastIndex)
              paths.add(restored)
            }
          },
          enabled = undoStack.isNotEmpty(),
          modifier = Modifier.size(34.dp).testTag("canvas_redo")
        ) {
          Icon(
            imageVector = Icons.Default.Redo,
            contentDescription = "Redo",
            tint = if (undoStack.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(18.dp)
          )
        }

        // Clear Canvas Button
        IconButton(
          onClick = {
            paths.clear()
            undoStack.clear()
            savedNotification = "Canvas Cleared"
            syncRepository?.let { repo ->
              coroutineScope.launch {
                repo.clearCanvasDrawing(chapterId)
              }
            }
          },
          modifier = Modifier
            .size(34.dp)
            .testTag("clear_canvas_button")
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Clear Canvas",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // Color Palette Picker
      if (activeTool != CanvasTool.ERASER) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          availableColors.forEach { color ->
            Box(
              modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  1.dp,
                  if (selectedColor == color) Color.White else Color.Transparent,
                  CircleShape
                )
                .clickable { selectedColor = color }
            )
          }
        }
      }

      // Note Save Button
      IconButton(
        onClick = {
          savedNotification = "Note Saved to E-Register (${paths.size} strokes)"
          Toast.makeText(context, "Digital note saved & synced to Room database!", Toast.LENGTH_SHORT).show()
          syncRepository?.let { repo ->
            coroutineScope.launch {
              repo.saveCanvasDrawing(chapterId, "{\"strokes\": ${paths.size}}")
            }
          }
        },
        modifier = Modifier
          .size(34.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(MaterialTheme.colorScheme.primaryContainer)
          .testTag("download_note_button")
      ) {
        Icon(
          imageVector = Icons.Default.Download,
          contentDescription = "Download Note",
          tint = PurpleAccent,
          modifier = Modifier.size(18.dp)
        )
      }
    }

    // Stroke Width Preset Bar inside clean Surface container with subtle border
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 4.dp),
      shape = RoundedCornerShape(8.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Stroke:",
          fontSize = 10.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontWeight = FontWeight.Bold
        )
        strokeWidths.forEach { (width, label) ->
          val isSelected = strokeWidth == width
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
              .border(
                1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(6.dp)
              )
              .clickable { strokeWidth = width }
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = label,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // Canvas Drawing Surface (Zero-Lag Optimized)
    Box(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f)
        .padding(6.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(MaterialTheme.colorScheme.surface)
        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
      var lastPoint by remember { mutableStateOf<Offset?>(null) }

      Canvas(
        modifier = Modifier
          .fillMaxSize()
          .pointerInput(activeTool, selectedColor, strokeWidth) {
            detectDragGestures(
              onDragStart = { offset ->
                val p = Path().apply { moveTo(offset.x, offset.y) }
                lastPoint = offset

                val colorToUse = when (activeTool) {
                  CanvasTool.ERASER -> canvasBgColor
                  CanvasTool.HIGHLIGHTER -> selectedColor
                  CanvasTool.PEN -> selectedColor
                }

                val alphaToUse = if (activeTool == CanvasTool.HIGHLIGHTER) 0.45f else 1.0f
                val strokeWidthToUse = when (activeTool) {
                  CanvasTool.ERASER -> 36f
                  CanvasTool.HIGHLIGHTER -> 24f
                  CanvasTool.PEN -> strokeWidth
                }

                currentPathState = DrawPath(
                  path = p,
                  color = colorToUse,
                  strokeWidth = strokeWidthToUse,
                  alpha = alphaToUse,
                  isEraser = activeTool == CanvasTool.ERASER
                )
                drawTrigger++
              },
              onDrag = { change, _ ->
                val current = change.position
                val prev = lastPoint ?: current
                val mid = Offset((prev.x + current.x) / 2f, (prev.y + current.y) / 2f)

                currentPathState?.path?.quadraticTo(prev.x, prev.y, mid.x, mid.y)
                lastPoint = current

                // Force 60fps render update without re-allocating list memory
                drawTrigger++
              },
              onDragEnd = {
                currentPathState?.let { dp ->
                  paths.add(dp)
                  undoStack.clear()
                }
                currentPathState = null
                lastPoint = null
                drawTrigger++
              }
            )
          }
          .testTag("drawing_canvas")
      ) {
        // Force reading drawTrigger so Compose invalidates drawing layer efficiently
        @Suppress("UNUSED_VARIABLE")
        val dummy = drawTrigger

        // Draw grid lines in canvas background
        val gridStep = 40.dp.toPx()
        val numCols = (size.width / gridStep).toInt()
        val numRows = (size.height / gridStep).toInt()

        for (i in 0..numCols) {
          drawLine(
            color = gridBorderColor,
            start = Offset(i * gridStep, 0f),
            end = Offset(i * gridStep, size.height),
            strokeWidth = 1f
          )
        }
        for (j in 0..numRows) {
          drawLine(
            color = gridBorderColor,
            start = Offset(0f, j * gridStep),
            end = Offset(size.width, j * gridStep),
            strokeWidth = 1f
          )
        }

        // Draw saved paths efficiently
        paths.forEach { drawPath ->
          drawPath(
            path = drawPath.path,
            color = drawPath.color,
            alpha = drawPath.alpha,
            style = Stroke(
              width = drawPath.strokeWidth,
              cap = StrokeCap.Round,
              join = StrokeJoin.Round
            )
          )
        }

        // Draw currently active dragging path in real-time
        currentPathState?.let { activeDp ->
          drawPath(
            path = activeDp.path,
            color = activeDp.color,
            alpha = activeDp.alpha,
            style = Stroke(
              width = activeDp.strokeWidth,
              cap = StrokeCap.Round,
              join = StrokeJoin.Round
            )
          )
        }
      }

      // E-Register Watermark Label
      Box(
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(12.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(DarkContainer.copy(alpha = 0.85f))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text(
          text = if (paths.isEmpty()) "E-Register Smooth Canvas Active" else "E-Register (${paths.size} strokes)",
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace,
          color = TextMuted,
          letterSpacing = 1.sp
        )
      }

      // Status Notification Banner if saved
      savedNotification?.let { notif ->
        Box(
          modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .border(1.dp, PurpleAccent, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Text(
            text = notif,
            fontSize = 11.sp,
            color = PurpleAccent,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
