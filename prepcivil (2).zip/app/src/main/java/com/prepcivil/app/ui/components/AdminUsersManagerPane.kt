package com.prepcivil.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.DarkPurpleText

@Composable
fun AdminUsersManagerSection(
  adminUsersList: List<AdminUserRecord>,
  onTogglePro: (String) -> Unit,
  onResetLimit: (String) -> Unit
) {
  Column(
    verticalArrangement = Arrangement.spacedBy(14.dp),
    modifier = Modifier.testTag("admin_users_manager_section")
  ) {
    Column {
      Text(
        text = "User Accounts & AI Limit Control",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
      Text(
        text = "Manage registered users, toggle Pro status, and reset daily evaluation limits",
        fontSize = 12.sp,
        color = TextSecondary
      )
    }

    adminUsersList.forEach { user ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = user.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              if (user.isPro) {
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = StatusGreen.copy(alpha = 0.2f)
                ) {
                  Text(
                    text = "PRO",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusGreen,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
            Text(
              text = user.email,
              fontSize = 12.sp,
              color = TextMuted
            )
            Text(
              text = "Daily Limit Used: ${user.dailyLimitUsed} / ${user.dailyLimitMax}",
              fontSize = 11.sp,
              color = TextSecondary
            )
          }

          Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Button(
              onClick = { onTogglePro(user.id) },
              colors = ButtonDefaults.buttonColors(containerColor = if (user.isPro) StatusGreen else PurpleAccent),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(32.dp)
            ) {
              Text(if (user.isPro) "Pro Active" else "Toggle Pro", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarkPurpleText)
            }

            OutlinedButton(
              onClick = { onResetLimit(user.id) },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(32.dp)
            ) {
              Text("Reset Limit", fontSize = 10.sp)
            }
          }
        }
      }
    }
  }
}
