package com.prepcivil.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import com.prepcivil.app.R
import com.prepcivil.app.model.Subject
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary
import com.prepcivil.app.ui.theme.HeatmapFill

@Composable
fun DashboardPane(
  masteryPercentage: Int,
  subjects: List<Subject>,
  completedChapterIds: Set<String> = emptySet(),
  heatmapSessions: List<com.prepcivil.app.db.StudySessionEntity> = emptyList(),
  onSelectSubject: (Subject) -> Unit,
  onStartSrsReview: () -> Unit,
  isProUser: Boolean = false,
  onOpenUpgradeModal: (() -> Unit)? = null,
  isAdmin: Boolean = false,
  onOpenAdminPanel: (() -> Unit)? = null
) {
  val scrollState = rememberScrollState()
  val srsDueCount = subjects.flatMap { it.chapters }.flatMap { it.flashcards }
    .count { it.stage == com.prepcivil.app.model.SrsStage.DUE || it.stage == com.prepcivil.app.model.SrsStage.NEW }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isTablet = maxWidth >= 650.dp

    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(
          horizontal = if (isTablet) 24.dp else 16.dp,
          vertical = if (isTablet) 24.dp else 16.dp
        )
        .navigationBarsPadding()
        .padding(bottom = 24.dp)
        .verticalScroll(scrollState),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 0. Admin Control Panel Navigation Card (Rendered if user has Admin privileges)
      if (isAdmin) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_admin_card")
            .clickable { onOpenAdminPanel?.invoke() },
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D1B2D)
          ),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9C27B0))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color(0xFF6B21A8)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.AdminPanelSettings,
                  contentDescription = "Admin Panel",
                  tint = Color(0xFFE9D5FF),
                  modifier = Modifier.size(24.dp)
                )
              }
              Column {
                Text(
                  text = "Administrator Control Panel",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = "Manage syllabus content, mains question bank & users",
                  fontSize = 12.sp,
                  color = Color(0xFFD8B4FE)
                )
              }
            }
            Button(
              onClick = { onOpenAdminPanel?.invoke() },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("open_admin_panel_button")
            ) {
              Text("Open Admin", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
      // 0. Compact Free Plan / Pro Banner
      if (isProUser) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF4338CA), Color(0xFF3730A3))))
            .border(1.dp, Color(0xFF8178FF), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 14.dp)
            .testTag("dashboard_plan_banner")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF6366F1)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "PRO",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = stringResource(R.string.pro_pass_activated),
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = stringResource(R.string.pro_pass_subtitle),
                  fontSize = 12.sp,
                  color = Color(0xFFE2DDFE)
                )
              }
            }
          }
        }
      } else {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_plan_banner"),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
          ),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Plan Banner",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = stringResource(R.string.free_plan),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "Upgrade to Pro for full syllabus & unlimited flashcards",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1
                )
              }
            }

            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = { onOpenUpgradeModal?.invoke() },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(8.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
              modifier = Modifier.height(32.dp).testTag("dashboard_upgrade_button")
            ) {
              Text(
                text = "Upgrade",
                color = MaterialTheme.colorScheme.onPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            }
          }
        }
      }

      // Middle Section: Hero Mastery Card
      HeroMasteryCard(
        masteryPercentage = masteryPercentage,
        subjects = subjects,
        completedChapterIds = completedChapterIds,
        srsDueCount = srsDueCount,
        heatmapSessions = heatmapSessions
      )

      // 7-Day Study Consistency Heatmap Widget
      RevisionHeatmapWidget(heatmapSessions = heatmapSessions)

      // 3. Subject Completion Cards Header
      Text(
        text = "Syllabus Progress & Subjects",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = PurpleAccent,
        modifier = Modifier.padding(top = 4.dp)
      )

      // Subject Cards Grid (2-column on Tablet, 1-column on Mobile)
      if (isTablet) {
        val rows = subjects.chunked(2)
        rows.forEach { rowSubjects ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            rowSubjects.forEach { subject ->
              Box(modifier = Modifier.weight(1f)) {
                SubjectProgressCard(
                  subject = subject,
                  completedChapterIds = completedChapterIds,
                  onSelectSubject = onSelectSubject
                )
              }
            }
            if (rowSubjects.size == 1) {
              Spacer(modifier = Modifier.weight(1f))
            }
          }
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          subjects.forEach { subject ->
            SubjectProgressCard(
              subject = subject,
              completedChapterIds = completedChapterIds,
              onSelectSubject = onSelectSubject
            )
          }
        }
      }
    }
  }
}

@Composable
fun HeroMasteryCard(
  masteryPercentage: Int,
  subjects: List<Subject>,
  completedChapterIds: Set<String>,
  srsDueCount: Int,
  heatmapSessions: List<com.prepcivil.app.db.StudySessionEntity> = emptyList()
) {
  val totalChapters = subjects.sumOf { it.chapters.size }
  val totalCompleted = subjects.sumOf { subject ->
    subject.chapters.count { completedChapterIds.contains(it.id) }
  }
  val totalStudyHours = heatmapSessions.sumOf { it.studyTimeHours.toDouble() }.toFloat()
  val activeDays = heatmapSessions.count { it.studyTimeHours > 0f || it.flashcardsReviewedCount > 0 }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("overall_progress_card"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier.padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.School,
              contentDescription = "Overall Progress",
              tint = PurpleAccent,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = stringResource(R.string.overall_syllabus_mastery),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = "$totalCompleted / $totalChapters " + stringResource(R.string.chapters_completed),
              fontSize = 11.sp,
              color = if (totalCompleted > 0) StatusGreen else TextMuted
            )
          }
        }

        // Streak indicator
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.LocalFireDepartment,
            contentDescription = "Streak",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (activeDays > 0) "$activeDays Days" else "0 Days",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Mastery Level",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "$masteryPercentage%",
          fontSize = 16.sp,
          fontWeight = FontWeight.Black,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      LinearProgressIndicator(
        progress = { masteryPercentage / 100f },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.surfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Quick Stats Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        StatChip(title = "Study Time", value = String.format("%.1f hrs", totalStudyHours), icon = Icons.Default.Timer)
        StatChip(title = "Flashcards", value = "$srsDueCount Due", icon = Icons.Default.Psychology)
        StatChip(title = "Quiz Acc.", value = if (totalCompleted > 0) "88.4%" else "0.0%", icon = Icons.Default.CheckCircle)
      }
    }
  }
}



@Composable
fun SubjectProgressCard(
  subject: Subject,
  completedChapterIds: Set<String>,
  onSelectSubject: (Subject) -> Unit
) {
  val colorAccent = when (subject.id) {
    "polity" -> PurpleAccent
    "history" -> Color(0xFF81D4FA)
    "geography" -> Color(0xFF81C784)
    "economy" -> Color(0xFFFFB74D)
    else -> Color(0xFFBA68C8)
  }

  val totalChapters = subject.chapters.size
  val completedCount = subject.chapters.count { completedChapterIds.contains(it.id) }
  val progress = if (totalChapters > 0) completedCount.toFloat() / totalChapters.toFloat() else 0f
  val percentageStr = "${(progress * 100).toInt()}%"

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onSelectSubject(subject) }
      .testTag("subject_card_${subject.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(colorAccent.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Book,
            contentDescription = subject.name,
            tint = colorAccent,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = subject.name,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = "$completedCount / $totalChapters Completed",
              fontSize = 11.sp,
              color = if (completedCount > 0) StatusGreen else TextMuted
            )
            val isPyq = subject.id.hashCode() % 2 == 0
            val badgeTag = if (isPyq) "PYQs" else "UPSC Quiz"
            val badgeBg = if (isPyq) colorAccent.copy(alpha = 0.15f) else Color(0x260284C7)
            val badgeBorder = if (isPyq) colorAccent.copy(alpha = 0.4f) else Color(0x660284C7)
            val badgeTextColor = if (isPyq) colorAccent else Color(0xFF38BDF8)

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(badgeBg)
                .border(1.dp, badgeBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = badgeTag,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = badgeTextColor
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .fillMaxWidth(0.9f)
              .height(5.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = if (completedCount > 0) StatusGreen else colorAccent,
            trackColor = MaterialTheme.colorScheme.background
          )
        }
      }

      Column(
        horizontalAlignment = Alignment.End
      ) {
        Text(
          text = percentageStr,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = if (completedCount > 0) StatusGreen else colorAccent
        )
        Spacer(modifier = Modifier.height(2.dp))
        Icon(
          imageVector = Icons.Default.ChevronRight,
          contentDescription = "Open Subject",
          tint = TextMuted,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}

@Composable
fun StatChip(
  title: String,
  value: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant)
      .padding(horizontal = 8.dp, vertical = 6.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = title,
      tint = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.size(14.dp)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Column {
      Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
  }
}

@Composable
fun RevisionHeatmapWidget(
  heatmapSessions: List<com.prepcivil.app.db.StudySessionEntity> = emptyList()
) {
  val defaultDays = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
  val sessionMap = heatmapSessions.associateBy { it.dateKey }
  val totalHours = defaultDays.sumOf { day -> (sessionMap[day]?.studyTimeHours ?: 0f).toDouble() }.toFloat()
  val totalCards = defaultDays.sumOf { day -> sessionMap[day]?.flashcardsReviewedCount ?: 0 }
  val activeDaysCount = heatmapSessions.count { it.studyTimeHours > 0f || it.flashcardsReviewedCount > 0 }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("study_heatmap_widget"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier.padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.DateRange,
            contentDescription = "Heatmap",
            tint = PurpleAccent,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "7-Day Revision Heatmap",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = "Daily Revision Consistency Grid",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (activeDaysCount > 0) StatusGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.LocalFireDepartment,
            contentDescription = "Streak",
            tint = if (activeDaysCount > 0) StatusGreen else TextMuted,
            modifier = Modifier.size(12.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (activeDaysCount > 0) "$activeDaysCount Active" else "0 Active",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (activeDaysCount > 0) StatusGreen else TextMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // 7-Day Grid Heatmap Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        defaultDays.forEachIndexed { index, dayLabel ->
          val hours = sessionMap[dayLabel]?.studyTimeHours ?: 0f
          val boxAlpha = if (hours > 0f) (hours / 4.5f).coerceIn(0.25f, 1.0f) else 0.08f

          Column(
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = dayLabel,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = TextMuted
            )
            Spacer(modifier = Modifier.height(6.dp))
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(HeatmapFill.copy(alpha = boxAlpha))
                .border(
                  1.dp,
                  if (hours > 0f) HeatmapFill.copy(alpha = (boxAlpha + 0.2f).coerceAtMost(1f)) else DarkBorder,
                  RoundedCornerShape(8.dp)
                )
                .testTag("heatmap_day_$index"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = if (hours > 0f) String.format("%.1fh", hours) else "0h",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (hours > 0f && boxAlpha > 0.6f) DarkPurpleText else TextMuted
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
          .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = String.format("Total This Week: %.1f hrs • %d Flashcards Reviewed", totalHours, totalCards),
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}


