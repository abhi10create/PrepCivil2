package com.prepcivil.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.prepcivil.app.model.Subject
import com.prepcivil.app.model.Chapter

@Composable
fun StorePane(
    isProUser: Boolean,
    subjects: List<Subject>,
    onSelectChapter: (Subject, Chapter) -> Unit,
    onOpenUpgradeModal: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Store & UPSC Study Passes", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onOpenUpgradeModal) {
                Text(text = if (isProUser) "Pro Pass Active" else "Upgrade to Pro")
            }
        }
    }
}
