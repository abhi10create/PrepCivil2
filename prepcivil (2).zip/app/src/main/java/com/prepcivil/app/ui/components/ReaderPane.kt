package com.prepcivil.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.prepcivil.app.db.UserNoteEntity
import androidx.compose.ui.res.stringResource
import com.prepcivil.app.R
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

enum class ReaderTheme(
  val label: String,
  val bg: Color,
  val cardBg: Color,
  val textColor: Color,
  val secondaryTextColor: Color,
  val headerBg: Color
) {
  SOFT_CREAM(
    label = "Soft Cream",
    bg = Color(0xFFFDFBF7),
    cardBg = Color(0xFFF7F3E9),
    textColor = Color(0xFF2B2823),
    secondaryTextColor = Color(0xFF656055),
    headerBg = Color(0xFFF3EFE3)
  ),
  DARK(
    label = "Slate Dark",
    bg = Color(0xFF19181F),
    cardBg = Color(0xFF26242E),
    textColor = Color(0xFFFFFFFF),
    secondaryTextColor = Color(0xFF9E9AAB),
    headerBg = Color(0xFF17161C)
  ),
  SEPIA(
    label = "Sepia",
    bg = Color(0xFF2D2A26),
    cardBg = Color(0xFF383430),
    textColor = Color(0xFFE8DCC4),
    secondaryTextColor = Color(0xFFB8AA94),
    headerBg = Color(0xFF25221F)
  ),
  LIGHT(
    label = "Light",
    bg = Color(0xFFFFFFFF),
    cardBg = Color(0xFFF5F5F7),
    textColor = Color(0xFF1E1F2E),
    secondaryTextColor = Color(0xFF5A5B6E),
    headerBg = Color(0xFFEEEEEF)
  )
}

data class SavedHighlight(
  val id: String,
  val paragraphIndex: Int,
  val text: String,
  val color: Color,
  val colorName: String,
  var note: String = ""
)

fun parseHexToColor(colorHex: String): Color {
  return when (colorHex.uppercase()) {
    "#FFF176", "YELLOW" -> Color(0xFFFFF176)
    "#A5D6A7", "GREEN" -> Color(0xFFA5D6A7)
    "#F48FB1", "PINK" -> Color(0xFFF48FB1)
    "#81D4FA", "CYAN" -> Color(0xFF81D4FA)
    "#FFCC80", "ORANGE" -> Color(0xFFFFCC80)
    "#D1C4E9", "PURPLE" -> Color(0xFFD1C4E9)
    else -> {
      try {
        Color(android.graphics.Color.parseColor(colorHex))
      } catch (e: Exception) {
        Color(0xFFFFF176)
      }
    }
  }
}

fun colorToHexStr(colorName: String): String {
  return when (colorName.lowercase()) {
    "green" -> "#A5D6A7"
    "pink" -> "#F48FB1"
    "cyan" -> "#81D4FA"
    "orange" -> "#FFCC80"
    "purple" -> "#D1C4E9"
    else -> "#FFF176"
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderPane(
  chapter: Chapter,
  isCanvasOpen: Boolean = true,
  onToggleCanvas: (() -> Unit)? = null,
  isZenMode: Boolean = false,
  onToggleZenMode: (() -> Unit)? = null,
  isProUser: Boolean = false,
  onOpenUpgradeModal: (() -> Unit)? = null,
  userEmail: String = "sabhishek607@gmail.com",
  isChapterCompleted: Boolean = false,
  onToggleChapterCompleted: (() -> Unit)? = null,
  syncRepository: com.prepcivil.app.db.AppSyncRepository? = null,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val isDark = androidx.compose.foundation.isSystemInDarkTheme()
  var readerTheme by remember(isDark) {
    mutableStateOf(if (isDark) ReaderTheme.DARK else ReaderTheme.SOFT_CREAM)
  }
  var fontSizeSp by remember { mutableStateOf(14) }
  val scrollState = rememberScrollState()

  val isLocked = chapter.isPremium && !isProUser

  // Room DB Notes Flow
  val dbNotesFlow = remember(chapter.id, syncRepository) {
    syncRepository?.getNotesForChapter(chapter.id)
  }
  val roomNotesEntities by (dbNotesFlow?.collectAsStateWithLifecycle(initialValue = emptyList())
    ?: remember { mutableStateOf(emptyList()) })

  // Highlighting State
  var isHighlightMode by remember { mutableStateOf(false) }
  var selectedHighlightColor by remember { mutableStateOf(Color(0xFFFFF176)) } // Default Yellow
  var selectedColorName by remember { mutableStateOf("Yellow") }

  var editingNoteEntity by remember { mutableStateOf<UserNoteEntity?>(null) }
  var showHighlightsDialog by remember { mutableStateOf(false) }

  // Drag Selection State & Word Bounds Map
  var dragStartKey by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var dragCurrentKey by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  val wordBoundsMap = remember { mutableStateMapOf<Pair<Int, Int>, Rect>() }

  fun checkWordHighlight(pIndex: Int, wIndex: Int, wordToken: String, paragraphWords: List<String>): Pair<Boolean, String?> {
    val start = dragStartKey
    val current = dragCurrentKey
    if (start != null && current != null) {
      val sVal = start.first * 10000L + start.second
      val cVal = current.first * 10000L + current.second
      val currVal = pIndex * 10000L + wIndex
      val minVal = minOf(sVal, cVal)
      val maxVal = maxOf(sVal, cVal)
      if (currVal in minVal..maxVal) {
        return Pair(true, colorToHexStr(selectedColorName))
      }
    }

    for (note in roomNotesEntities) {
      if (note.paragraphIndex != pIndex) continue
      val cleanSelected = note.selectedText.trim()
      val cleanWord = wordToken.trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
      
      if (cleanSelected.equals(cleanWord, ignoreCase = true) || cleanSelected.equals(wordToken.trim(), ignoreCase = true)) {
        return Pair(true, note.colorHex)
      }

      val selectedWords = cleanSelected.split(" ").map { it.trim() }.filter { it.isNotEmpty() }
      if (selectedWords.size > 1) {
        for (i in 0..paragraphWords.size - selectedWords.size) {
          var matches = true
          for (j in selectedWords.indices) {
            val pw = paragraphWords[i + j].trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
            val sw = selectedWords[j].trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
            if (!pw.equals(sw, ignoreCase = true)) {
              matches = false
              break
            }
          }
          if (matches && wIndex in i until (i + selectedWords.size)) {
            return Pair(true, note.colorHex)
          }
        }
      }
    }
    return Pair(false, null)
  }

  fun getSavedNoteForWord(pIndex: Int, wIndex: Int, wordToken: String, paragraphWords: List<String>): UserNoteEntity? {
    for (note in roomNotesEntities) {
      if (note.paragraphIndex != pIndex) continue
      val cleanSelected = note.selectedText.trim()
      val cleanWord = wordToken.trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
      
      if (cleanSelected.equals(cleanWord, ignoreCase = true) || cleanSelected.equals(wordToken.trim(), ignoreCase = true)) {
        return note
      }
      val selectedWords = cleanSelected.split(" ").map { it.trim() }.filter { it.isNotEmpty() }
      if (selectedWords.size > 1) {
        for (i in 0..paragraphWords.size - selectedWords.size) {
          var matches = true
          for (j in selectedWords.indices) {
            val pw = paragraphWords[i + j].trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
            val sw = selectedWords[j].trim().removeSurrounding("(", ")").removeSurrounding("\"", "\"").removeSuffix(".").removeSuffix(",")
            if (!pw.equals(sw, ignoreCase = true)) {
              matches = false
              break
            }
          }
          if (matches && wIndex in i until (i + selectedWords.size)) {
            return note
          }
        }
      }
    }
    return null
  }

  val highlightColors = listOf(
    Triple("Yellow", Color(0xFFFFF176), Color(0xFF332F00)),
    Triple("Green", Color(0xFFA5D6A7), Color(0xFF003305)),
    Triple("Pink", Color(0xFFF48FB1), Color(0xFF330018)),
    Triple("Cyan", Color(0xFF81D4FA), Color(0xFF002233)),
    Triple("Orange", Color(0xFFFFCC80), Color(0xFF3E2723)),
    Triple("Purple", Color(0xFFD1C4E9), Color(0xFF311B92))
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(readerTheme.bg)
      .border(
        1.dp,
        if (readerTheme == ReaderTheme.SOFT_CREAM) Color(0xFFE2DBCB) else MaterialTheme.colorScheme.outline
      )
  ) {
    // Reader Header Controls
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(readerTheme.headerBg)
        .padding(horizontal = 12.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(
          imageVector = Icons.Default.MenuBook,
          contentDescription = "Reader",
          tint = if (readerTheme == ReaderTheme.SOFT_CREAM) Color(0xFF4A4231) else if (readerTheme == ReaderTheme.LIGHT) Color(0xFF381E72) else PurpleAccent,
          modifier = Modifier.size(16.dp)
        )
        Text(
          text = stringResource(R.string.chapter_reader).uppercase(),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          color = if (readerTheme == ReaderTheme.SOFT_CREAM) Color(0xFF4A4231) else if (readerTheme == ReaderTheme.LIGHT) Color(0xFF381E72) else PurpleAccent
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Saved Highlights Badge / Modal Opener
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (roomNotesEntities.isNotEmpty()) DarkPurpleText else Color.Transparent)
            .border(1.dp, if (roomNotesEntities.isNotEmpty()) PurpleAccent else DarkBorder, RoundedCornerShape(8.dp))
            .clickable { showHighlightsDialog = true }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("saved_highlights_button"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.FormatPaint,
              contentDescription = "Saved Highlights",
              tint = PurpleAccent,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = "Highlights (${roomNotesEntities.size})",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = PurpleAccent
            )
          }
        }

        // Zen Mode Toggle
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isZenMode) PurpleAccent else Color.Transparent)
            .border(1.dp, if (isZenMode) PurpleAccent else DarkBorder, RoundedCornerShape(8.dp))
            .clickable { onToggleZenMode?.invoke() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("zen_mode_toggle"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.SelfImprovement,
              contentDescription = "Zen Mode",
              tint = if (isZenMode) DarkPurpleText else PurpleAccent,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = if (isZenMode) "Zen Active" else "Zen Mode",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isZenMode) DarkPurpleText else PurpleAccent
            )
          }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Reader Theme Toggle Options
        ReaderTheme.entries.forEach { theme ->
          val isSelected = theme == readerTheme
          val borderClr = if (isSelected) PurpleAccent 
                          else if (readerTheme == ReaderTheme.SOFT_CREAM) Color(0xFFD6CEBB) 
                          else if (readerTheme == ReaderTheme.LIGHT) Color(0xFFD6D0C4) 
                          else DarkBorder

          Box(
            modifier = Modifier
              .size(22.dp)
              .clip(CircleShape)
              .background(theme.bg)
              .border(
                1.dp,
                borderClr,
                CircleShape
              )
              .clickable { readerTheme = theme }
              .testTag("reader_theme_${theme.name.lowercase()}"),
            contentAlignment = Alignment.Center
          ) {
            if (isSelected) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(
                    if (theme == ReaderTheme.SOFT_CREAM) Color(0xFF4A4231)
                    else if (theme == ReaderTheme.LIGHT) Color(0xFF381E72)
                    else PurpleAccent
                  )
              )
            }
          }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Font size adjuster
        IconButton(
          onClick = {
            fontSizeSp = if (fontSizeSp >= 18) 12 else fontSizeSp + 2
          },
          modifier = Modifier
            .size(28.dp)
            .testTag("font_size_toggle")
        ) {
          Icon(
            imageVector = Icons.Default.FormatSize,
            contentDescription = "Font Size",
            tint = readerTheme.secondaryTextColor,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }

    // Single Highlighting Active Toolbar Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(if (isHighlightMode) Color(0xFF2D1B4E) else DarkContainer.copy(alpha = 0.5f))
        .border(1.dp, DarkBorder)
        .padding(horizontal = 12.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isHighlightMode) PurpleAccent else Color.Transparent)
            .border(1.dp, if (isHighlightMode) PurpleAccent else DarkBorder, RoundedCornerShape(6.dp))
            .clickable { isHighlightMode = !isHighlightMode }
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .testTag("highlight_mode_toggle")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.FormatPaint,
              contentDescription = "Highlight Marker",
              tint = if (isHighlightMode) DarkPurpleText else TextSecondary,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = if (isHighlightMode) "✨ Highlighting ON" else "Highlight",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isHighlightMode) DarkPurpleText else TextSecondary
            )
          }
        }
      }

      if (isHighlightMode) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          highlightColors.forEach { (name, color, _) ->
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  2.dp,
                  if (selectedColorName == name) Color.White else Color.Transparent,
                  CircleShape
                )
                .clickable {
                  selectedHighlightColor = color
                  selectedColorName = name
                }
            )
          }
        }
      }
    }

    // Reading Scrollable Area
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(12.dp)
    ) {
      // Reading Text Content
      Column(
        modifier = Modifier
          .fillMaxSize()
          .navigationBarsPadding()
          .padding(bottom = 16.dp)
          .verticalScroll(scrollState)
          .pointerInput(isHighlightMode) {
            if (!isHighlightMode) return@pointerInput
            detectDragGestures(
              onDragStart = { offset ->
                val found = wordBoundsMap.entries.minByOrNull { (_, rect) ->
                  if (rect.contains(offset)) 0f else (rect.center - offset).getDistance()
                }?.key
                if (found != null) {
                  dragStartKey = found
                  dragCurrentKey = found
                }
              },
              onDrag = { change, _ ->
                val offset = change.position
                val found = wordBoundsMap.entries.minByOrNull { (_, rect) ->
                  if (rect.contains(offset)) 0f else (rect.center - offset).getDistance()
                }?.key
                if (found != null) {
                  dragCurrentKey = found
                }
              },
              onDragEnd = {
                val start = dragStartKey
                val current = dragCurrentKey
                if (start != null && current != null) {
                  val sVal = start.first * 10000L + start.second
                  val cVal = current.first * 10000L + current.second
                  val minKey = if (sVal <= cVal) start else current
                  val maxKey = if (sVal <= cVal) current else start

                  val spannedWords = mutableListOf<String>()
                  for (pi in minKey.first..maxKey.first) {
                    if (pi < 0 || pi >= chapter.textContent.size) continue
                    val pWords = chapter.textContent[pi].split(" ").map { it.trim() }.filter { it.isNotEmpty() }
                    val wStart = if (pi == minKey.first) minKey.second.coerceIn(0, pWords.size - 1) else 0
                    val wEnd = if (pi == maxKey.first) maxKey.second.coerceIn(0, pWords.size - 1) else pWords.size - 1
                    if (wStart <= wEnd) {
                      for (wi in wStart..wEnd) {
                        spannedWords.add(pWords[wi])
                      }
                    }
                  }

                  if (spannedWords.isNotEmpty()) {
                    val spannedText = spannedWords.joinToString(" ")
                    val newEntity = UserNoteEntity(
                      id = "hl_${chapter.id}_${minKey.first}_${minKey.second}_${System.currentTimeMillis()}",
                      chapterId = chapter.id,
                      paragraphIndex = minKey.first,
                      selectedText = spannedText,
                      colorHex = colorToHexStr(selectedColorName),
                      colorName = selectedColorName,
                      note = ""
                    )
                    coroutineScope.launch {
                      syncRepository?.saveNote(newEntity)
                    }
                    Toast.makeText(context, "Highlighted text range", Toast.LENGTH_SHORT).show()
                  }
                }
                dragStartKey = null
                dragCurrentKey = null
              },
              onDragCancel = {
                dragStartKey = null
                dragCurrentKey = null
              }
            )
          }
      ) {
        Text(
          text = chapter.title,
          fontSize = (fontSizeSp + 4).sp,
          fontWeight = FontWeight.Bold,
          color = if (readerTheme == ReaderTheme.DARK) PurpleAccent else readerTheme.textColor,
          modifier = Modifier.padding(bottom = 2.dp)
        )

        Text(
          text = chapter.subtitle,
          fontSize = (fontSizeSp - 2).sp,
          fontWeight = FontWeight.Medium,
          color = readerTheme.secondaryTextColor,
          modifier = Modifier.padding(bottom = 8.dp)
        )

        val chapterHash = remember(chapter.id) { kotlin.math.abs(chapter.id.hashCode()) }
        val pYear = listOf("2019", "2021", "2023", "2024")[chapterHash % 4]

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          PyqBadge(tag = "PYQ $pYear", color = PurpleAccent)
          PyqBadge(tag = "UPSC Quiz", color = Color(0xFF38BDF8))
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
              if (readerTheme == ReaderTheme.SOFT_CREAM) Color(0xFFE2DBCB)
              else if (readerTheme == ReaderTheme.LIGHT) Color.LightGray
              else DarkBorder
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (isLocked) {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 16.dp)
              .testTag("paywall_overlay_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkContainer),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFF8A65))
            )
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                modifier = Modifier
                  .size(52.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF3E2723)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = "Locked",
                  tint = Color(0xFFFF8A65),
                  modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.height(16.dp))

              Text(
                text = "🔒 Pro Pass Required",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8A65),
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = "Chapter 3 onwards across all books are locked under the Free Tier. Upgrade to PrepCivil Pro Pass to unlock full access.",
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
              )

              Spacer(modifier = Modifier.height(20.dp))

              Button(
                onClick = { onOpenUpgradeModal?.invoke() },
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(46.dp)
                  .testTag("paywall_unlock_button")
              ) {
                Text(
                  text = "Unlock Access — Special Launch Offer",
                  color = DarkPurpleText,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
              }
            }
          }

          if (chapter.textContent.isNotEmpty()) {
            Text(
              text = chapter.textContent.first() + " ...",
              fontSize = fontSizeSp.sp,
              lineHeight = (fontSizeSp * 1.5).sp,
              color = readerTheme.textColor.copy(alpha = 0.5f),
              modifier = Modifier.padding(bottom = 10.dp)
            )
          }
        } else {
          // Precise Word-Level Interactive Paragraphs with Seamless Highlight Range Merging
          chapter.textContent.forEachIndexed { pIndex, paragraph ->
            val words = paragraph.split(" ")
            FlowRow(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.Start,
              verticalArrangement = Arrangement.Center
            ) {
              words.forEachIndexed { wIndex, wordToken ->
                val cleanWord = wordToken.trim()
                  .removeSurrounding("(", ")")
                  .removeSurrounding("\"", "\"")
                  .removeSuffix(".")
                  .removeSuffix(",")
                  .removeSuffix(":")
                  .removeSuffix(";")

                val targetWord = if (cleanWord.isNotBlank()) cleanWord else wordToken.trim()

                val savedNoteEntity = getSavedNoteForWord(pIndex, wIndex, wordToken, words)
                val (isHl, hlColor) = checkWordHighlight(pIndex, wIndex, wordToken, words)

                val (isNextHl, nextColor) = if (wIndex + 1 < words.size) checkWordHighlight(pIndex, wIndex + 1, words[wIndex + 1], words) else Pair(false, null)
                val (isPrevHl, prevColor) = if (wIndex > 0) checkWordHighlight(pIndex, wIndex - 1, words[wIndex - 1], words) else Pair(false, null)

                val shouldMergeNext = isHl && isNextHl && hlColor == nextColor
                val shouldMergePrev = isHl && isPrevHl && hlColor == prevColor

                val bgColor = if (isHl) parseHexToColor(hlColor ?: "#FFF176") else Color.Transparent
                val textColor = if (isHl) Color(0xFF1C1B1F) else readerTheme.textColor

                val shape = RoundedCornerShape(
                  topStart = if (shouldMergePrev) 0.dp else 4.dp,
                  bottomStart = if (shouldMergePrev) 0.dp else 4.dp,
                  topEnd = if (shouldMergeNext) 0.dp else 4.dp,
                  bottomEnd = if (shouldMergeNext) 0.dp else 4.dp
                )

                val spacerWidth = if (shouldMergeNext) 0.dp else 3.dp

                val isHeaderWord = (paragraph.startsWith("PART ") || paragraph.startsWith("A. ") || paragraph.startsWith("B. ") || paragraph.startsWith("1. ") || paragraph.startsWith("Core Aggregate Metrics:"))

                Box(
                  modifier = Modifier
                    .onGloballyPositioned { coordinates ->
                      try {
                        val bounds = coordinates.boundsInParent()
                        wordBoundsMap[Pair(pIndex, wIndex)] = bounds
                      } catch (e: Exception) {}
                    }
                    .clip(shape)
                    .background(bgColor)
                    .border(
                      width = if (isHl && savedNoteEntity != null) 1.5.dp else 0.dp,
                      color = if (isHl && savedNoteEntity != null) parseHexToColor(savedNoteEntity.colorHex) else Color.Transparent,
                      shape = shape
                    )
                    .clickable {
                      if (savedNoteEntity != null) {
                        editingNoteEntity = savedNoteEntity
                      } else if (isHighlightMode) {
                        val newEntity = UserNoteEntity(
                          id = "hl_${chapter.id}_${pIndex}_${targetWord}_${System.currentTimeMillis()}",
                          chapterId = chapter.id,
                          paragraphIndex = pIndex,
                          selectedText = targetWord,
                          colorHex = colorToHexStr(selectedColorName),
                          colorName = selectedColorName,
                          note = ""
                        )
                        coroutineScope.launch {
                          syncRepository?.saveNote(newEntity)
                        }
                        Toast.makeText(context, "Highlighted '$targetWord'", Toast.LENGTH_SHORT).show()
                      }
                    }
                    .padding(horizontal = 2.dp, vertical = 1.dp)
                ) {
                  Text(
                    text = wordToken,
                    fontSize = fontSizeSp.sp,
                    lineHeight = (fontSizeSp * 1.5).sp,
                    color = textColor,
                    fontWeight = if (savedNoteEntity != null || isHeaderWord) FontWeight.Bold else FontWeight.Normal
                  )
                }
                Spacer(modifier = Modifier.width(spacerWidth))
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chapter Completion Check-In Banner / Card
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .testTag("chapter_completion_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isChapterCompleted) Color(0xFF1B5E20) else DarkContainer
          ),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (isChapterCompleted) com.prepcivil.app.ui.theme.StatusGreen else PurpleAccent)
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isChapterCompleted) "✓ Chapter Completed" else "Check In & Complete Chapter",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = if (isChapterCompleted) "Syllabus progress saved locally." else "Mark as complete to dynamically update your UPSC progress bar.",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(
              onClick = { onToggleChapterCompleted?.invoke() },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isChapterCompleted) com.prepcivil.app.ui.theme.StatusGreen else PurpleAccent
              ),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("toggle_chapter_complete_button")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (isChapterCompleted) Icons.Default.CheckCircle else Icons.Default.CheckCircleOutline,
                  contentDescription = "Complete Chapter",
                  tint = if (isChapterCompleted) Color.White else DarkPurpleText,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isChapterCompleted) "Completed" else "Check In",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = if (isChapterCompleted) Color.White else DarkPurpleText
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(60.dp))
      }

      // Floating Canvas Button
      if (onToggleCanvas != null) {
        Row(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(8.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(PurpleAccent)
            .clickable { onToggleCanvas() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("canvas_toggle_button"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Brush,
            contentDescription = "Toggle Canvas",
            tint = DarkPurpleText,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = if (isCanvasOpen) "Hide Canvas" else "Notes / Canvas",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = DarkPurpleText
          )
        }
      }
    }
  }

  // Saved Highlights Overview Modal (Persisted Room Database)
  if (showHighlightsDialog) {
    Dialog(onDismissRequest = { showHighlightsDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = PurpleAccent,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = "Saved Chapter Highlights",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            IconButton(onClick = { showHighlightsDialog = false }) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = TextMuted,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          if (roomNotesEntities.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No highlights saved yet. Touch or tap any word in the chapter text with finger/stylus to highlight and save!",
                fontSize = 13.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
              )
            }
          } else {
            LazyColumn(
              modifier = Modifier
                .fillMaxWidth()
                .height(260.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              items(roomNotesEntities) { item ->
                val hlColor = parseHexToColor(item.colorHex)
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(hlColor.copy(alpha = 0.2f))
                    .border(1.dp, hlColor, RoundedCornerShape(8.dp))
                    .padding(10.dp)
                ) {
                  Column {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = item.colorName.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = hlColor
                      )

                      Row {
                        // Copy Button
                        IconButton(
                          onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Chapter Highlight", item.selectedText)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                          },
                          modifier = Modifier.size(28.dp)
                        ) {
                          Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                          )
                        }

                        // Delete Button
                        IconButton(
                          onClick = {
                            coroutineScope.launch {
                              syncRepository?.deleteNote(item.id)
                            }
                            Toast.makeText(context, "Highlight removed!", Toast.LENGTH_SHORT).show()
                          },
                          modifier = Modifier.size(28.dp)
                        ) {
                          Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color(0xFFE57373),
                            modifier = Modifier.size(14.dp)
                          )
                        }
                      }
                    }

                    Text(
                      text = "\"${item.selectedText}\"",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary,
                      maxLines = 3,
                      overflow = TextOverflow.Ellipsis
                    )

                    if (item.note.isNotEmpty()) {
                      Spacer(modifier = Modifier.height(4.dp))
                      Text(
                        text = "Note: ${item.note}",
                        fontSize = 11.sp,
                        color = PurpleAccent,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                      )
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = { showHighlightsDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = DarkPurpleText),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(text = "Close", color = PurpleAccent)
          }
        }
      }
    }
  }

  // Edit / Add Note Dialog for Room DB Highlight
  editingNoteEntity?.let { noteEntity ->
    var noteInput by remember { mutableStateOf(noteEntity.note) }

    Dialog(onDismissRequest = { editingNoteEntity = null }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp)
        ) {
          Text(
            text = "Edit Highlight & Study Note",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "\"${noteEntity.selectedText}\"",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = parseHexToColor(noteEntity.colorHex),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = noteInput,
            onValueChange = { noteInput = it },
            label = { Text("Add Study Note / Key Takeaway") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = PurpleAccent,
              unfocusedBorderColor = DarkBorder,
              focusedLabelColor = PurpleAccent,
              unfocusedLabelColor = TextMuted,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            TextButton(
              onClick = {
                coroutineScope.launch {
                  syncRepository?.deleteNote(noteEntity.id)
                }
                editingNoteEntity = null
                Toast.makeText(context, "Highlight removed", Toast.LENGTH_SHORT).show()
              }
            ) {
              Text(text = "Remove Highlight", color = Color(0xFFE57373))
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
              onClick = {
                val updatedNote = noteEntity.copy(
                  note = noteInput,
                  updatedAt = System.currentTimeMillis()
                )
                coroutineScope.launch {
                  syncRepository?.saveNote(updatedNote)
                }
                editingNoteEntity = null
                Toast.makeText(context, "Note saved & synced to Room DB!", Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent)
            ) {
              Text(text = "Save Note", color = DarkPurpleText)
            }
          }
        }
      }
    }
  }
}

@Composable
fun PyqBadge(
  tag: String,
  color: Color = PurpleAccent
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.15f))
      .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
      .testTag("pyq_badge")
  ) {
    Icon(
      imageVector = Icons.Default.LocalOffer,
      contentDescription = "PYQ Tag",
      tint = color,
      modifier = Modifier.size(10.dp)
    )
    Text(
      text = tag,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = color
    )
  }
}
