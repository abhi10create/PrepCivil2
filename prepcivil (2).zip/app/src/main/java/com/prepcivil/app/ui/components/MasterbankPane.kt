package com.prepcivil.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import com.prepcivil.app.R
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Subject
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.ErrorRed
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

@Composable
fun MasterbankPane(
  subjects: List<Subject>,
  initialSubject: Subject,
  initialChapter: Chapter,
  onQuizCompleted: (score: Int, total: Int) -> Unit = { _, _ -> }
) {
  var selectedSubject by remember { mutableStateOf(initialSubject) }
  var selectedChapter by remember { mutableStateOf(initialChapter) }

  var subjectDropdownExpanded by remember { mutableStateOf(false) }
  var chapterDropdownExpanded by remember { mutableStateOf(false) }

  // Get guaranteed 20 high-quality Masterbank questions
  val masterbankQuestions = remember(selectedChapter) {
    selectedChapter.get20MasterbankQuestions(selectedSubject.name)
  }

  var currentQuestionIndex by remember(selectedChapter) { mutableIntStateOf(0) }
  val selectedAnswers = remember(selectedChapter) { mutableStateMapOf<Int, Int>() }
  var isSubmitted by remember(selectedChapter) { mutableStateOf(false) }

  val scrollState = rememberScrollState()
  val stepperScrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp)
      .navigationBarsPadding()
      .padding(bottom = 16.dp)
      .verticalScroll(scrollState)
  ) {
    // 1. TOP HEADER & SUBJECT/CHAPTER DROPDOWNS
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("masterbank_header_card"),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Quiz,
                contentDescription = "Masterbank",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "UPSC Masterbank",
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = stringResource(R.string.masterbank_subtitle),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          IconButton(
            onClick = {
              selectedAnswers.clear()
              isSubmitted = false
              currentQuestionIndex = 0
            },
            modifier = Modifier.size(32.dp).testTag("masterbank_reset_button")
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = "Restart Masterbank",
              tint = MaterialTheme.colorScheme.primary
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selectors Row (Subject & Chapter)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Subject Picker Box
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
              .clickable { subjectDropdownExpanded = true }
              .padding(horizontal = 10.dp, vertical = 8.dp)
              .testTag("masterbank_subject_selector")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = stringResource(R.string.subject), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Text(
                  text = selectedSubject.name,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1
                )
              }
              Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            DropdownMenu(
              expanded = subjectDropdownExpanded,
              onDismissRequest = { subjectDropdownExpanded = false }
            ) {
              subjects.forEach { sub ->
                DropdownMenuItem(
                  text = { Text(sub.name, fontSize = 13.sp) },
                  onClick = {
                    selectedSubject = sub
                    selectedChapter = sub.chapters.first()
                    subjectDropdownExpanded = false
                  }
                )
              }
            }
          }

          // Chapter Picker Box
          Box(
            modifier = Modifier
              .weight(1.2f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
              .clickable { chapterDropdownExpanded = true }
              .padding(horizontal = 10.dp, vertical = 8.dp)
              .testTag("masterbank_chapter_selector")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = stringResource(R.string.chapter), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Text(
                  text = selectedChapter.title,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  maxLines = 1
                )
              }
              Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            DropdownMenu(
              expanded = chapterDropdownExpanded,
              onDismissRequest = { chapterDropdownExpanded = false }
            ) {
              selectedSubject.chapters.forEach { ch ->
                DropdownMenuItem(
                  text = { Text(ch.title, fontSize = 13.sp) },
                  onClick = {
                    selectedChapter = ch
                    chapterDropdownExpanded = false
                  }
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // 2. QUESTION STEPPER / NUMBER BAR (1 to 20)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(stepperScrollState)
        .padding(vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      masterbankQuestions.forEachIndexed { idx, _ ->
        val isCurrent = idx == currentQuestionIndex
        val isAnswered = selectedAnswers.containsKey(idx)

        val chipBg = when {
          isCurrent -> MaterialTheme.colorScheme.onSurface
          isAnswered -> MaterialTheme.colorScheme.primaryContainer
          else -> MaterialTheme.colorScheme.surfaceVariant
        }

        val chipBorder = when {
          isCurrent -> MaterialTheme.colorScheme.onSurface
          isAnswered -> StatusGreen
          else -> DarkBorder
        }

        val textColor = when {
          isCurrent -> MaterialTheme.colorScheme.surface
          isAnswered -> StatusGreen
          else -> MaterialTheme.colorScheme.onSurfaceVariant
        }

        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(chipBg)
            .border(1.dp, chipBorder, RoundedCornerShape(8.dp))
            .clickable { currentQuestionIndex = idx }
            .testTag("masterbank_nav_chip_$idx"),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "${idx + 1}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Progress Bar
    LinearProgressIndicator(
      progress = { (selectedAnswers.size.toFloat() / masterbankQuestions.size.toFloat()).coerceIn(0f, 1f) },
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = PurpleAccent,
      trackColor = DarkContainer
    )

    Spacer(modifier = Modifier.height(14.dp))

    // 3. CURRENT QUESTION CARD
    if (masterbankQuestions.isNotEmpty() && currentQuestionIndex in masterbankQuestions.indices) {
      val question = masterbankQuestions[currentQuestionIndex]
      val selectedOption = selectedAnswers[currentQuestionIndex]

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("masterbank_question_card_$currentQuestionIndex"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Question Header Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(PurpleAccent.copy(alpha = 0.15f))
                .border(1.dp, PurpleAccent.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = "Question ${currentQuestionIndex + 1} of ${masterbankQuestions.size}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent
              )
            }

            if (selectedOption != null) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(StatusGreen.copy(alpha = 0.15f))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = "Answered",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = StatusGreen
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = question.questionText,
            style = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 22.sp, color = MaterialTheme.colorScheme.onSurface),
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.height(16.dp))

          // 4 Options
          question.options.forEachIndexed { optIdx, optText ->
            val isSelected = selectedOption == optIdx
            val isCorrect = optIdx == question.correctAnswerIndex

            val optionBg = when {
              isSubmitted && isCorrect -> StatusGreen.copy(alpha = 0.2f)
              isSubmitted && isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.2f)
              isSelected -> MaterialTheme.colorScheme.primaryContainer
              else -> MaterialTheme.colorScheme.surfaceVariant
            }

            val optionBorder = when {
              isSubmitted && isCorrect -> StatusGreen
              isSubmitted && isSelected && !isCorrect -> ErrorRed
              isSelected -> PurpleAccent
              else -> MaterialTheme.colorScheme.outline
            }

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(optionBg)
                .border(1.dp, optionBorder, RoundedCornerShape(10.dp))
                .clickable {
                  selectedAnswers[currentQuestionIndex] = optIdx
                }
                .padding(12.dp)
                .testTag("masterbank_q_${currentQuestionIndex}_opt_$optIdx")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                  selected = isSelected,
                  onClick = { selectedAnswers[currentQuestionIndex] = optIdx },
                  colors = RadioButtonDefaults.colors(
                    selectedColor = PurpleAccent,
                    unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = optText,
                  fontSize = 13.sp,
                  color = if (isSelected || (isSubmitted && isCorrect)) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                  fontWeight = if (isSelected || (isSubmitted && isCorrect)) FontWeight.SemiBold else FontWeight.Normal,
                  lineHeight = 18.sp
                )
              }
            }
          }

          // Show explanation if submitted
          if (isSubmitted) {
            Spacer(modifier = Modifier.height(14.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                .padding(12.dp)
            ) {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Explanation",
                    tint = StatusGreen,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "UPSC Analytical Explanation:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusGreen
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = question.explanation,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  lineHeight = 17.sp
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 4. BOTTOM NAVIGATION & SUBMISSION BAR
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Button(
        onClick = {
          if (currentQuestionIndex > 0) currentQuestionIndex--
        },
        enabled = currentQuestionIndex > 0,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("masterbank_prev_button")
      ) {
        Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Prev", tint = MaterialTheme.colorScheme.onSurface)
        Text(text = "Prev", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
      }

      Text(
        text = "Answered: ${selectedAnswers.size} / ${masterbankQuestions.size}",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Button(
        onClick = {
          if (currentQuestionIndex < masterbankQuestions.size - 1) currentQuestionIndex++
        },
        enabled = currentQuestionIndex < masterbankQuestions.size - 1,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("masterbank_next_button")
      ) {
        Text(text = "Next", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next", tint = MaterialTheme.colorScheme.onSurface)
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Submit Masterbank Test Button
    if (!isSubmitted) {
      Button(
        onClick = {
          isSubmitted = true
          var correctCount = 0
          masterbankQuestions.forEachIndexed { i, q ->
            if (selectedAnswers[i] == q.correctAnswerIndex) correctCount++
          }
          onQuizCompleted(correctCount, masterbankQuestions.size)
        },
        enabled = selectedAnswers.isNotEmpty(),
        colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("submit_masterbank_button")
      ) {
        Text(
          text = if (selectedAnswers.size == masterbankQuestions.size) "Submit Masterbank Test (20/20)" else "Submit Masterbank Test (${selectedAnswers.size}/20)",
          color = Color.Black,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
      }
    } else {
      // Score Summary Banner
      var correctCount = 0
      masterbankQuestions.forEachIndexed { i, q ->
        if (selectedAnswers[i] == q.correctAnswerIndex) correctCount++
      }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("masterbank_results_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        border = androidx.compose.foundation.BorderStroke(1.dp, StatusGreen)
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(text = "🎉 Masterbank Completed!", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = StatusGreen)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Score: $correctCount / ${masterbankQuestions.size} (${(correctCount * 100) / masterbankQuestions.size}%)",
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = {
              selectedAnswers.clear()
              isSubmitted = false
              currentQuestionIndex = 0
            },
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(text = "Retry Chapter Masterbank", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))
  }
}
