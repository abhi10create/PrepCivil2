package com.prepcivil.app.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserNoteDao {
  @Query("SELECT * FROM user_notes WHERE chapterId = :chapterId ORDER BY updatedAt DESC")
  fun getNotesForChapter(chapterId: String): Flow<List<UserNoteEntity>>

  @Query("SELECT * FROM user_notes ORDER BY updatedAt DESC")
  fun getAllNotes(): Flow<List<UserNoteEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNote(note: UserNoteEntity)

  @Query("DELETE FROM user_notes WHERE id = :id")
  suspend fun deleteNoteById(id: String)
}

@Dao
interface CanvasDrawingDao {
  @Query("SELECT * FROM canvas_drawings WHERE chapterId = :chapterId")
  fun getCanvasDrawing(chapterId: String): Flow<CanvasDrawingEntity?>

  @Query("SELECT * FROM canvas_drawings WHERE chapterId = :chapterId")
  suspend fun getCanvasDrawingSync(chapterId: String): CanvasDrawingEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCanvasDrawing(drawing: CanvasDrawingEntity)

  @Query("DELETE FROM canvas_drawings WHERE chapterId = :chapterId")
  suspend fun clearCanvasDrawing(chapterId: String)
}

@Dao
interface ChapterProgressDao {
  @Query("SELECT * FROM chapter_progress")
  fun getAllProgress(): Flow<List<ChapterProgressEntity>>

  @Query("SELECT chapterId FROM chapter_progress WHERE isCompleted = 1")
  fun getCompletedChapterIds(): Flow<List<String>>

  @Query("SELECT chapterId FROM chapter_progress WHERE isCompleted = 1")
  suspend fun getCompletedChapterIdsSync(): List<String>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveProgress(progress: ChapterProgressEntity)
}

@Dao
interface SrsReviewDao {
  @Query("SELECT * FROM srs_reviews")
  fun getAllSrsReviews(): Flow<List<SrsReviewEntity>>

  @Query("SELECT * FROM srs_reviews")
  suspend fun getAllSrsReviewsSync(): List<SrsReviewEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveSrsReview(review: SrsReviewEntity)
}

@Dao
interface StudySessionDao {
  @Query("SELECT * FROM study_sessions ORDER BY dateKey ASC")
  fun get7DayHeatmapData(): Flow<List<StudySessionEntity>>

  @Query("SELECT * FROM study_sessions ORDER BY dateKey ASC")
  suspend fun get7DayHeatmapDataSync(): List<StudySessionEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveStudySession(session: StudySessionEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveAllStudySessions(sessions: List<StudySessionEntity>)
}

@Dao
interface SyncMetaDao {
  @Query("SELECT value FROM sync_meta WHERE key = :key")
  suspend fun getValue(key: String): String?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun setValue(meta: SyncMetaEntity)
}
