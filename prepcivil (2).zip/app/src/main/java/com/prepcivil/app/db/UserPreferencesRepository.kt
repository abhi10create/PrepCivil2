package com.prepcivil.app.db

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

import androidx.datastore.preferences.core.stringPreferencesKey

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {
  companion object {
    val IS_DARK_MODE_KEY = booleanPreferencesKey("is_dark_mode")
    val GEMINI_API_KEY_KEY = stringPreferencesKey("gemini_api_key")
  }

  val isDarkModeFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
    preferences[IS_DARK_MODE_KEY] ?: true
  }

  suspend fun setDarkMode(isDarkMode: Boolean) {
    context.dataStore.edit { preferences ->
      preferences[IS_DARK_MODE_KEY] = isDarkMode
    }
  }

  val geminiApiKeyFlow: Flow<String> = context.dataStore.data.map { preferences ->
    preferences[GEMINI_API_KEY_KEY] ?: ""
  }

  suspend fun setGeminiApiKey(apiKey: String) {
    context.dataStore.edit { preferences ->
      preferences[GEMINI_API_KEY_KEY] = apiKey
    }
  }
}
