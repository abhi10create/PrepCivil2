package com.prepcivil.app.ui.components

import kotlinx.coroutines.launch
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material.icons.filled.SentimentNeutral
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.model.CardRating
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import com.prepcivil.app.R
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Flashcard
import com.prepcivil.app.model.SrsStage
import com.prepcivil.app.model.Subject
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.ErrorRed
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary
import com.prepcivil.app.ui.theme.BackgroundDark

@Composable
fun FlashcardsPane(
  subjects: List<Subject>,
  initialSubject: Subject,
  initialChapter: Chapter,
  syncRepository: com.prepcivil.app.db.AppSyncRepository? = null,
  onRatingUpdated: (CardRating) -> Unit = {}
) {
  val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
  var selectedSubject by remember { mutableStateOf(initialSubject) }
  var selectedChapter by remember { mutableStateOf(initialChapter) }

  var subjectDropdownExpanded by remember { mutableStateOf(false) }
  var chapterDropdownExpanded by remember { mutableStateOf(false) }

  // Always get 20 high-level flashcards for selected chapter
  val flashcards = remember(selectedChapter) {
    selectedChapter.get20Flashcards(selectedSubject.name)
  }

  var currentIndex by remember(selectedChapter) { mutableIntStateOf(0) }
  var isFlipped by remember(currentIndex, selectedChapter) { mutableStateOf(false) }
  var reviewCountToday by remember { mutableIntStateOf(0) }

  val scrollState = rememberScrollState()

  val rotation by animateFloatAsState(
    targetValue = if (isFlipped) 180f else 0f,
    animationSpec = tween(durationMillis = 350),
    label = "cardFlipAnimation"
  )

  // Live SRS Metrics
  val dueCount = flashcards.count { it.stage == SrsStage.DUE || it.stage == SrsStage.NEW }
  val learningCount = flashcards.count { it.stage == SrsStage.LEARNING }
  val masteredCount = flashcards.count { it.stage == SrsStage.MASTERED }

  val isCompleted = currentIndex >= flashcards.size

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
        .navigationBarsPadding()
        .padding(bottom = 16.dp)
        .verticalScroll(scrollState),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // 1. HEADER CARD & CHAPTER SELECTOR
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("flashcards_header_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Psychology,
                  contentDescription = "SRS Flashcards",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "UPSC SRS Flashcards",
                  fontSize = 17.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = MaterialTheme.colorScheme.primary
                )
                Text(
                  text = if (!isCompleted) "Card ${currentIndex + 1} of ${flashcards.size} (20/Chapter)" else "20 Cards Reviewed!",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(
              onClick = {
                currentIndex = 0
                isFlipped = false
              },
              modifier = Modifier.size(32.dp).testTag("reset_deck_button")
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Restart Deck",
                tint = MaterialTheme.colorScheme.primary
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Selectors Row (Subject & Chapter)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Subject Picker
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                .clickable { subjectDropdownExpanded = true }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("flashcard_subject_selector")
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = stringResource(R.string.subject), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                  Text(text = selectedSubject.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                }
                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
              }

              DropdownMenu(
                expanded = subjectDropdownExpanded,
                onDismissRequest = { subjectDropdownExpanded = false }
              ) {
                subjects.forEach { sub ->
                  DropdownMenuItem(
                    text = { Text(sub.name, fontSize = 13.sp) },
                    onClick = {
                      selectedSubject = sub
                      selectedChapter = sub.chapters.first()
                      subjectDropdownExpanded = false
                    }
                  )
                }
              }
            }

            // Chapter Picker
            Box(
              modifier = Modifier
                .weight(1.2f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                .clickable { chapterDropdownExpanded = true }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("flashcard_chapter_selector")
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = stringResource(R.string.chapter), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                  Text(text = selectedChapter.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                }
                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
              }

              DropdownMenu(
                expanded = chapterDropdownExpanded,
                onDismissRequest = { chapterDropdownExpanded = false }
              ) {
                selectedSubject.chapters.forEach { ch ->
                  DropdownMenuItem(
                    text = { Text(ch.title, fontSize = 13.sp) },
                    onClick = {
                      selectedChapter = ch
                      chapterDropdownExpanded = false
                    }
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 2. SRS METRICS COUNTERS
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("srs_metrics_row"),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
              MetricCard(
          title = stringResource(R.string.srs_due),
          count = dueCount,
          color = MaterialTheme.colorScheme.primary,
          icon = Icons.Default.Schedule,
          modifier = Modifier.weight(1f).testTag("cards_due_today_counter")
        )
        MetricCard(
          title = stringResource(R.string.srs_learning),
          count = learningCount,
          color = MaterialTheme.colorScheme.secondary,
          icon = Icons.Default.Psychology,
          modifier = Modifier.weight(1f).testTag("learning_counter")
        )
        MetricCard(
          title = stringResource(R.string.srs_mastered),
          count = masteredCount,
          color = StatusGreen,
          icon = Icons.Default.Verified,
          modifier = Modifier.weight(1f).testTag("mastered_counter")
        )
      }

      Spacer(modifier = Modifier.height(18.dp))

      if (!isCompleted) {
        val currentCard = flashcards[currentIndex]

        // 3. FLASHCARD FLIP CONTAINER
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .height(290.dp)
            .graphicsLayer {
              rotationY = rotation
              cameraDistance = 12 * density
            }
            .clickable { isFlipped = !isFlipped }
            .testTag("flashcard_flip_area"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
              when (currentCard.stage) {
                SrsStage.MASTERED -> StatusGreen
                SrsStage.LEARNING -> Color(0xFFBA68C8)
                else -> MaterialTheme.colorScheme.outline
              }
            )
          )
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(20.dp),
            contentAlignment = Alignment.Center
          ) {
            if (rotation <= 90f) {
              // FRONT SIDE: Question
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxSize()
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(MaterialTheme.colorScheme.primaryContainer)
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(
                      text = currentCard.category,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary,
                      maxLines = 1
                    )
                  }

                  val (badgeLabel, badgeBg, badgeColor) = when (currentCard.stage) {
                    SrsStage.MASTERED -> Triple("Mastered", Color(0xFF1B5E20), StatusGreen)
                    SrsStage.LEARNING -> Triple("Learning", Color(0xFF4A148C), Color(0xFFE1BEE7))
                    SrsStage.DUE -> Triple("Due Today", Color(0xFFE65100), Color(0xFFFFCC80))
                    SrsStage.NEW -> Triple("New Card", Color(0xFF0D47A1), Color(0xFF90CAF9))
                  }

                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(badgeBg)
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(
                      text = badgeLabel,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = badgeColor
                    )
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                  text = currentCard.question,
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.onSurface,
                  textAlign = TextAlign.Center,
                  lineHeight = 23.sp,
                  modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  Icon(imageVector = Icons.Default.Flip, contentDescription = "Flip", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                  Text(text = stringResource(R.string.reveal_answer), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            } else {
              // BACK SIDE: Answer
              Column(
                modifier = Modifier
                  .fillMaxSize()
                  .graphicsLayer { rotationY = 180f },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "ANSWER & RECALL",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.sp,
                  color = StatusGreen
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                  text = currentCard.answer,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Normal,
                  color = MaterialTheme.colorScheme.onSurface,
                  textAlign = TextAlign.Center,
                  lineHeight = 22.sp,
                  modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                  text = "Select difficulty rating below to schedule next review",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 4. ACTION BUTTONS
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = {
                currentCard.userRating = CardRating.HARD
                currentCard.nextReviewDays = 1
                currentCard.stage = SrsStage.LEARNING
                onRatingUpdated(CardRating.HARD)
                reviewCountToday++
                isFlipped = false
                currentIndex++
                syncRepository?.let { repo ->
                  coroutineScope.launch {
                    repo.saveSrsReview(currentCard.id, "HARD", 1, "LEARNING")
                    repo.updateStudySession("Sun", 0.05f, 1)
                  }
                }
              },
              modifier = Modifier.weight(1f).height(44.dp).testTag("reaction_hard"),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer),
              shape = RoundedCornerShape(12.dp)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = stringResource(R.string.card_rating_hard), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = "1d", color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f), fontSize = 9.sp)
              }
            }

            Button(
              onClick = {
                currentCard.userRating = CardRating.GOOD
                currentCard.nextReviewDays = 3
                currentCard.stage = SrsStage.LEARNING
                onRatingUpdated(CardRating.GOOD)
                reviewCountToday++
                isFlipped = false
                currentIndex++
                syncRepository?.let { repo ->
                  coroutineScope.launch {
                    repo.saveSrsReview(currentCard.id, "GOOD", 3, "LEARNING")
                    repo.updateStudySession("Sun", 0.05f, 1)
                  }
                }
              },
              modifier = Modifier.weight(1f).height(44.dp).testTag("reaction_good"),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
              shape = RoundedCornerShape(12.dp)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = stringResource(R.string.card_rating_good), color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = "3d", color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f), fontSize = 9.sp)
              }
            }

            Button(
              onClick = {
                currentCard.userRating = CardRating.EASY
                currentCard.nextReviewDays = 7
                currentCard.stage = SrsStage.MASTERED
                onRatingUpdated(CardRating.EASY)
                reviewCountToday++
                isFlipped = false
                currentIndex++
                syncRepository?.let { repo ->
                  coroutineScope.launch {
                    repo.saveSrsReview(currentCard.id, "EASY", 7, "MASTERED")
                    repo.updateStudySession("Sun", 0.05f, 1)
                  }
                }
              },
              modifier = Modifier.weight(1f).height(44.dp).testTag("reaction_easy"),
              colors = ButtonDefaults.buttonColors(containerColor = StatusGreen.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(12.dp)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = stringResource(R.string.card_rating_easy), color = StatusGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = "7d", color = StatusGreen.copy(alpha = 0.8f), fontSize = 9.sp)
              }
            }
          }
        }
      } else {
        // Completion Card
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
            .testTag("srs_completion_card"),
          colors = CardDefaults.cardColors(containerColor = DarkContainer),
          shape = RoundedCornerShape(20.dp),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(PurpleAccent)
          )
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "Done", tint = PurpleAccent, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = "🎉 All 20 Cards Reviewed!", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PurpleAccent)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = "You've reviewed all 20 flashcards for ${selectedChapter.title}.",
              fontSize = 12.sp,
              color = TextSecondary,
              textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            Button(
              onClick = {
                currentIndex = 0
                isFlipped = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.fillMaxWidth().height(44.dp).testTag("restart_srs_deck_button")
            ) {
              Text(text = "Review Deck Again", color = BackgroundDark, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  count: Int,
  color: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = color,
          modifier = Modifier.size(18.dp)
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = "$count", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(2.dp))
      Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
    }
  }
}
