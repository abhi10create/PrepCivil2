package com.prepcivil.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PurpleAccent = Color(0xFF818CF8)
val DarkBorder = Color(0xFF3F3B4C)
val DarkContainer = Color(0xFF1F1D2B)
val DarkBackground = Color(0xFF121116)
val DarkPurpleText = Color(0xFFE0E7FF)
val StatusGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF5350)
val TextMuted = Color(0xFF9E9AAB)
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFFD1D5DB)
val HeatmapFill = Color(0xFF34D399)
val CanvasBackground = Color(0xFF1E1B2E)
val BackgroundDark = Color(0xFF0F0E13)
val SurfaceDark = Color(0xFF1A1823)
val SelectedTabBorder = Color(0xFF818CF8)

private val DarkColorScheme = darkColorScheme(
    primary = PurpleAccent,
    background = DarkBackground,
    surface = DarkContainer,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = PurpleAccent,
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

@Composable
fun PrepCivilTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    PrepCivilTheme(darkTheme = darkTheme, content = content)
}
