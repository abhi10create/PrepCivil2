package com.prepcivil.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.prepcivil.app.db.UserPreferencesRepository
import com.prepcivil.app.ui.components.MainsEvaluationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainsAIViewModel(application: Application) : AndroidViewModel(application) {

  private val userPrefsRepo = UserPreferencesRepository(application)

  private val _customApiKey = MutableStateFlow("")
  val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

  companion object {
    private const val FALLBACK_API_KEY = "AQ.Ab8RN6JIMW_LiTf8MZlhbdQm0w-zgkU0D0rBKSFKW5DMDzcfNQ"
    private const val FREE_LIFETIME_LIMIT = 5
    private const val PRO_DAILY_LIMIT = 3
  }

  val buildConfigApiKey: String = try {
    val keyFromBuildConfig = BuildConfig.GEMINI_API_KEY
    if (keyFromBuildConfig.isNotBlank() && keyFromBuildConfig != "MY_GEMINI_API_KEY") {
      keyFromBuildConfig
    } else {
      (System.getenv("GEMINI_API_KEY") ?: "").ifBlank { FALLBACK_API_KEY }
    }
  } catch (e: Throwable) {
    (System.getenv("GEMINI_API_KEY") ?: "").ifBlank { FALLBACK_API_KEY }
  }

  init {
    viewModelScope.launch {
      userPrefsRepo.geminiApiKeyFlow.collect { savedKey ->
        if (savedKey.isNotBlank()) {
          _customApiKey.value = savedKey
        }
      }
    }
    checkAdminStatusOnStart()
  }

  val effectiveApiKey: StateFlow<String> = _customApiKey.map { custom ->
    if (custom.isNotBlank()) custom else buildConfigApiKey
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = buildConfigApiKey
  )

  val isApiKeyConfigured: StateFlow<Boolean> = effectiveApiKey.map { key ->
    key.isNotBlank() && key != "MY_GEMINI_API_KEY"
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = buildConfigApiKey.isNotBlank() && buildConfigApiKey != "MY_GEMINI_API_KEY"
  )

  private val _isEvaluating = MutableStateFlow(false)
  val isEvaluating: StateFlow<Boolean> = _isEvaluating.asStateFlow()

  private val _evaluationResult = MutableStateFlow<MainsEvaluationResult?>(null)
  val evaluationResult: StateFlow<MainsEvaluationResult?> = _evaluationResult.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

  private val _isAdmin = MutableStateFlow(false)
  val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

  fun checkAdminStatusOnStart() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val auth = FirebaseAuth.getInstance()
        var user = auth.currentUser
        if (user == null) {
          val authResult = auth.signInAnonymously().await()
          user = authResult.user
        }
        val userId = user?.uid
        val userEmail = user?.email ?: ""
        if (userId != null) {
          val firestore = FirebaseFirestore.getInstance()
          val userDoc = firestore.collection("users").document(userId).get().await()
          var isUserAdmin = false
          if (userDoc.exists()) {
            val adminFlag = userDoc.getBoolean("isAdmin") ?: false
            val role = userDoc.getString("role") ?: ""
            if (adminFlag || role.equals("admin", ignoreCase = true) || userEmail == "sabhishek607@gmail.com") {
              isUserAdmin = true
            }
          } else if (userEmail == "sabhishek607@gmail.com") {
            isUserAdmin = true
          }
          _isAdmin.value = isUserAdmin
        }
      } catch (e: Exception) {
        if (FirebaseAuth.getInstance().currentUser?.email == "sabhishek607@gmail.com") {
          _isAdmin.value = true
        }
      }
    }
  }

  fun updateCustomApiKey(key: String) {
    val trimmed = key.trim()
    _customApiKey.value = trimmed
    viewModelScope.launch {
      userPrefsRepo.setGeminiApiKey(trimmed)
    }
  }

  fun clearEvaluation() {
    _evaluationResult.value = null
    _errorMessage.value = null
  }

  private suspend fun getOrCreateUserId(): String = withContext(Dispatchers.IO) {
    try {
      val auth = FirebaseAuth.getInstance()
      var user = auth.currentUser
      if (user == null) {
        val authResult = auth.signInAnonymously().await()
        user = authResult.user
      }
      user?.uid ?: "device_user"
    } catch (e: Exception) {
      "device_user"
    }
  }

  fun evaluateAnswer(
    question: String,
    maxMarks: Int,
    userAnswer: String,
    expectedKeyPoints: List<String>
  ) {
    if (_isEvaluating.value) return

    viewModelScope.launch {
      _isEvaluating.value = true
      _errorMessage.value = null
      _evaluationResult.value = null

      val key = effectiveApiKey.value

      if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
        _errorMessage.value = "Please configure a valid Gemini API key to evaluate answers."
        _isEvaluating.value = false
        return@launch
      }

      // 1. Authenticate / Identify User via Firebase Auth
      val userId = getOrCreateUserId()
      val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

      // 2. Fetch User Document from Firestore & Check Subscription Tier (isPro)
      val firestore = FirebaseFirestore.getInstance()
      var isProUser = false
      try {
        val userDoc = firestore.collection("users").document(userId).get().await()
        if (userDoc.exists()) {
          isProUser = (userDoc.getBoolean("isPro") == true) ||
                      (userDoc.getBoolean("isSubscribed") == true) ||
                      (userDoc.getString("plan")?.equals("pro", ignoreCase = true) == true)
        }
      } catch (_: Exception) {
        // Fallback gracefully if offline
      }

      // 3. Track & Enforce Quota based on Subscription Tier
      if (!isProUser) {
        // FREE User: Lifetime Limit of 5 questions total
        var totalEvaluationsCount = 0
        try {
          val totalSnapshot = firestore.collection("users")
            .document(userId)
            .collection("evaluations")
            .get()
            .await()
          totalEvaluationsCount = totalSnapshot.size()
        } catch (_: Exception) {}

        if (totalEvaluationsCount >= FREE_LIFETIME_LIMIT) {
          _errorMessage.value = "Free limit reached (5/5 total). Upgrade to Pro for 3 questions per day!"
          _isEvaluating.value = false
          return@launch
        }
      } else {
        // PRO User: Daily Quota of 3 questions per day
        var todayEvaluationsCount = 0
        try {
          val todaySnapshot = firestore.collection("users")
            .document(userId)
            .collection("evaluations")
            .whereEqualTo("dateStr", todayStr)
            .get()
            .await()
          todayEvaluationsCount = todaySnapshot.size()
        } catch (_: Exception) {}

        if (todayEvaluationsCount >= PRO_DAILY_LIMIT) {
          _errorMessage.value = "Daily Pro limit reached (3/3). Limit resets tomorrow."
          _isEvaluating.value = false
          return@launch
        }
      }

      try {
        val result = evaluateWithGeminiApi(key, question, maxMarks, userAnswer)
        if (result != null) {
          _evaluationResult.value = result

          // 3. Save Evaluation History to Firestore under users/{userId}/evaluations
          saveEvaluationToFirestore(userId, todayStr, question, userAnswer, maxMarks, result)
        } else {
          _errorMessage.value = "Server is busy processing answers. Please try again in a minute."
        }
      } catch (e: Exception) {
        val msg = e.localizedMessage ?: e.message ?: ""
        if (msg.contains("400") || msg.contains("API_KEY_INVALID", ignoreCase = true) || msg.contains("INVALID_KEY", ignoreCase = true)) {
          _errorMessage.value = "Invalid API Key. Please check your Gemini API key configuration."
        } else {
          _errorMessage.value = "Server is busy processing answers. Please try again in a minute."
        }
      } finally {
        _isEvaluating.value = false
      }
    }
  }

  private suspend fun saveEvaluationToFirestore(
    userId: String,
    dateStr: String,
    question: String,
    candidateAnswer: String,
    maxMarks: Int,
    result: MainsEvaluationResult
  ) = withContext(Dispatchers.IO) {
    try {
      val firestore = FirebaseFirestore.getInstance()
      val evalData = hashMapOf(
        "question" to question,
        "candidateAnswer" to candidateAnswer,
        "maxMarks" to maxMarks,
        "overallScore" to result.overallScore,
        "gradePill" to result.gradePill,
        "parameterBreakdown" to hashMapOf(
          "introScore" to result.introScore,
          "introMax" to result.introMax,
          "introFeedback" to result.introFeedback,
          "contentScore" to result.contentScore,
          "contentMax" to result.contentMax,
          "contentFeedback" to result.contentFeedback,
          "valueAdditionScore" to result.valueAdditionScore,
          "valueAdditionMax" to result.valueAdditionMax,
          "valueAdditionFeedback" to result.valueAdditionFeedback,
          "conclusionScore" to result.conclusionScore,
          "conclusionMax" to result.conclusionMax,
          "conclusionFeedback" to result.conclusionFeedback
        ),
        "strengths" to result.strengths,
        "weaknesses" to result.weaknesses,
        "modelAnswerOutline" to result.modelAnswerOutline,
        "timestamp" to Timestamp.now(),
        "dateStr" to dateStr
      )

      firestore.collection("users")
        .document(userId)
        .collection("evaluations")
        .add(evalData)
        .await()
    } catch (e: Exception) {
      // Non-blocking catch for background history persist
    }
  }

  private suspend fun evaluateWithGeminiApi(
    apiKey: String,
    question: String,
    maxMarks: Int,
    userAnswer: String
  ): MainsEvaluationResult? = withContext(Dispatchers.IO) {
    val promptText = """
      You are a strict UPSC Mains Answer Examiner.

      Step 1: Check if the candidate answer directly addresses the given question directive.
      Step 2: If the candidate answer is completely unrelated or off-topic (e.g., discussing Article 163 / Governor powers or unrelated topics for a question on society/ethics/aspirations), immediately assign 0/15 marks (overallScore = 0.0, introScore = 0.0, contentScore = 0.0, valueAdditionScore = 0.0, conclusionScore = 0.0) and state: 'CRITICAL ERROR: Answer is entirely off-topic and irrelevant to the question.' in contentFeedback, and set gradePill to "CRITICAL ERROR: Off-Topic Answer".
      Step 3: Only evaluate structure, keywords, and content if the answer is relevant.

      QUESTION ($maxMarks Marks):
      "$question"

      CANDIDATE ANSWER DRAFT:
      "$userAnswer"

      Respond strictly with a valid JSON object matching this schema:
      {
        "overallScore": 0.0,
        "gradePill": "CRITICAL ERROR: Off-Topic Answer",
        "introScore": 0.0,
        "introMax": ${if (maxMarks == 15) 3.0 else 2.0},
        "introFeedback": "Evaluation breakdown",
        "contentScore": 0.0,
        "contentMax": ${if (maxMarks == 15) 6.0 else 4.0},
        "contentFeedback": "CRITICAL ERROR: Answer is entirely off-topic and irrelevant to the question.",
        "valueAdditionScore": 0.0,
        "valueAdditionMax": ${if (maxMarks == 15) 3.0 else 2.0},
        "valueAdditionFeedback": "Value addition breakdown",
        "conclusionScore": 0.0,
        "conclusionMax": ${if (maxMarks == 15) 3.0 else 2.0},
        "conclusionFeedback": "Conclusion breakdown",
        "strengths": ["Submitted response"],
        "weaknesses": ["CRITICAL ERROR: Answer is entirely off-topic and irrelevant to the question."],
        "modelAnswerOutline": "Ideal outline for this question"
      }
    """.trimIndent()

    val jsonRequest = JSONObject().apply {
      put("contents", JSONArray().apply {
        put(JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply {
              put("text", promptText)
            })
          })
        })
      })
    }

    val client = OkHttpClient.Builder()
      .connectTimeout(20, TimeUnit.SECONDS)
      .readTimeout(25, TimeUnit.SECONDS)
      .build()

    var lastError: String? = null
    val modelNames = listOf("gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash")
    for (model in modelNames) {
      val request = Request.Builder()
        .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
        .post(jsonRequest.toString().toRequestBody("application/json".toMediaType()))
        .build()

      try {
        val response = client.newCall(request).execute()
        if (response.isSuccessful) {
          val responseBody = response.body?.string()
          if (responseBody != null) {
            val jsonRoot = JSONObject(responseBody)
            val textContent = jsonRoot.getJSONArray("candidates")
              .getJSONObject(0)
              .getJSONObject("content")
              .getJSONArray("parts")
              .getJSONObject(0)
              .getString("text")

            val jsonStart = textContent.indexOf("{")
            val jsonEnd = textContent.lastIndexOf("}")
            if (jsonStart != -1 && jsonEnd != -1) {
              val cleanJsonStr = textContent.substring(jsonStart, jsonEnd + 1)
              val parsedObj = JSONObject(cleanJsonStr)

              return@withContext MainsEvaluationResult(
                overallScore = parsedObj.optDouble("overallScore", 0.0),
                maxMarks = maxMarks,
                gradePill = parsedObj.optString("gradePill", "Gemini AI Evaluated"),
                introScore = parsedObj.optDouble("introScore", 0.0),
                introMax = if (maxMarks == 15) 3.0 else 2.0,
                introFeedback = parsedObj.optString("introFeedback", "Introduction feedback"),
                contentScore = parsedObj.optDouble("contentScore", 0.0),
                contentMax = if (maxMarks == 15) 6.0 else 4.0,
                contentFeedback = parsedObj.optString("contentFeedback", "Content feedback"),
                valueAdditionScore = parsedObj.optDouble("valueAdditionScore", 0.0),
                valueAdditionMax = if (maxMarks == 15) 3.0 else 2.0,
                valueAdditionFeedback = parsedObj.optString("valueAdditionFeedback", "Value addition feedback"),
                conclusionScore = parsedObj.optDouble("conclusionScore", 0.0),
                conclusionMax = if (maxMarks == 15) 3.0 else 2.0,
                conclusionFeedback = parsedObj.optString("conclusionFeedback", "Conclusion feedback"),
                strengths = parseHelperList(parsedObj.optJSONArray("strengths")),
                weaknesses = parseHelperList(parsedObj.optJSONArray("weaknesses")),
                modelAnswerOutline = parsedObj.optString("modelAnswerOutline", "Model answer outline")
              )
            }
          }
        } else {
          val errBody = response.body?.string() ?: ""
          if (response.code == 429 || errBody.contains("RESOURCE_EXHAUSTED", ignoreCase = true) || errBody.contains("Quota", ignoreCase = true)) {
            lastError = "429: Quota limit reached"
          } else {
            lastError = "HTTP ${response.code}: $errBody"
          }
        }
      } catch (e: Exception) {
        lastError = e.localizedMessage ?: e.message
      }
    }

    if (lastError != null) {
      throw Exception(lastError)
    }
    return@withContext null
  }

  private suspend fun evaluateWithAnalyticalEngine(
    question: String,
    maxMarks: Int,
    userAnswer: String,
    expectedKeyPoints: List<String>
  ): MainsEvaluationResult = withContext(Dispatchers.Default) {
    delay(1000)

    val wordCount = userAnswer.trim().split("\\s+".toRegex()).filter { it.isNotEmpty() }.size
    val lowerAnswer = userAnswer.lowercase()
    val lowerQuestion = question.lowercase()

    // Question keyword overlap check
    val questionWords = lowerQuestion.split("\\W+".toRegex())
      .filter { it.length > 3 && !listOf("what", "discuss", "examine", "critically", "explain", "analyze", "elucidate", "india", "mains", "question", "directive", "about", "their", "which", "there", "would", "should", "could").contains(it) }
    val matchingWords = questionWords.filter { lowerAnswer.contains(it) }
    val isIrrelevant = questionWords.isNotEmpty() && matchingWords.isEmpty() && (expectedKeyPoints.isNotEmpty() && expectedKeyPoints.none { kp -> lowerAnswer.contains(kp.lowercase().take(4)) })

    if (isIrrelevant || wordCount < 15) {
      return@withContext MainsEvaluationResult(
        overallScore = 1.0,
        maxMarks = maxMarks,
        gradePill = "Severe Irrelevance / Off-topic Content",
        introScore = 0.5,
        introMax = if (maxMarks == 15) 3.0 else 2.0,
        introFeedback = "Off-topic or incomplete opening context.",
        contentScore = 0.5,
        contentMax = if (maxMarks == 15) 6.0 else 4.0,
        contentFeedback = "Severe Irrelevance / Off-topic Content: The draft does not address the question directive.",
        valueAdditionScore = 0.0,
        valueAdditionMax = if (maxMarks == 15) 3.0 else 2.0,
        valueAdditionFeedback = "No relevant facts or concepts detected for this question.",
        conclusionScore = 0.0,
        conclusionMax = if (maxMarks == 15) 3.0 else 2.0,
        conclusionFeedback = "Irrelevant conclusion.",
        strengths = listOf("Submitted response draft"),
        weaknesses = listOf("Severe Irrelevance / Off-topic Content", "Draft does not align with question directive"),
        modelAnswerOutline = "1. Introduction addressing $question\n2. Core body arguments\n3. Conclusion & Way Forward"
      )
    }

    val introScoreVal = if (wordCount >= 30) (if (maxMarks == 15) 2.5 else 1.8) else (if (maxMarks == 15) 1.5 else 1.0)
    val contentScoreVal = if (wordCount >= 120) (if (maxMarks == 15) 4.5 else 3.2) else (if (maxMarks == 15) 2.5 else 1.8)
    var valueAddVal = 0.0
    val conclusionVal = if (lowerAnswer.contains("way forward") || lowerAnswer.contains("conclusion") || lowerAnswer.contains("thus")) (if (maxMarks == 15) 2.2 else 1.5) else (if (maxMarks == 15) 1.0 else 0.8)

    val detectedKeyPoints = expectedKeyPoints.filter { kp -> lowerAnswer.contains(kp.lowercase().take(5)) }
    if (detectedKeyPoints.isNotEmpty()) {
      valueAddVal += detectedKeyPoints.size * 0.5
    }
    if (lowerAnswer.contains("article") || lowerAnswer.contains("commission") || lowerAnswer.contains("case")) {
      valueAddVal += 0.8
    }

    val valueAddMaxVal = if (maxMarks == 15) 3.0 else 2.0
    val valueAddScoreFinal = valueAddVal.coerceAtMost(valueAddMaxVal)
    val totalCalculated = (introScoreVal + contentScoreVal + valueAddScoreFinal + conclusionVal).coerceAtMost(maxMarks.toDouble())

    val gradeText = when {
      totalCalculated >= maxMarks * 0.6 -> "Top Tier Answer • High Interview Score"
      totalCalculated >= maxMarks * 0.45 -> "Above Average • Solid Conceptual Base"
      else -> "Requires Value Addition & Structural Refinement"
    }

    val strengthsList = mutableListOf<String>()
    if (wordCount >= 140) strengthsList.add("Appropriate word count ($wordCount words)")
    if (lowerAnswer.contains("article") || lowerAnswer.contains("act") || lowerAnswer.contains("commission")) strengthsList.add("Includes key legal/constitutional references")
    if (lowerAnswer.contains("\n")) strengthsList.add("Clean paragraph separation and point-wise layout")
    if (strengthsList.isEmpty()) strengthsList.add("Addressed basic prompt context")

    val weaknessesList = mutableListOf<String>()
    if (!lowerAnswer.contains("article") && !lowerAnswer.contains("commission")) weaknessesList.add("Missing constitutional articles / committee references")
    if (wordCount < 100) weaknessesList.add("Word count below recommended limit ($wordCount words)")
    if (!lowerAnswer.contains("way forward")) weaknessesList.add("Add an explicit 'Way Forward' sub-section")

    MainsEvaluationResult(
      overallScore = totalCalculated,
      maxMarks = maxMarks,
      gradePill = "$gradeText (Analytical Engine)",
      introScore = introScoreVal,
      introMax = if (maxMarks == 15) 3.0 else 2.0,
      introFeedback = if (wordCount >= 30) "Good opening context setting." else "Expand opening definition/context.",
      contentScore = contentScoreVal,
      contentMax = if (maxMarks == 15) 6.0 else 4.0,
      contentFeedback = if (wordCount >= 120) "Comprehensive core body coverage." else "Core body requires broader dimensional analysis.",
      valueAdditionScore = valueAddScoreFinal,
      valueAdditionMax = valueAddMaxVal,
      valueAdditionFeedback = if (detectedKeyPoints.isNotEmpty()) "Identified key concepts: ${detectedKeyPoints.joinToString()}" else "Incorporate relevant reports, statistics, or legal articles.",
      conclusionScore = conclusionVal,
      conclusionMax = if (maxMarks == 15) 3.0 else 2.0,
      conclusionFeedback = if (lowerAnswer.contains("way forward")) "Forward-looking optimistic conclusion." else "Conclude with an actionable policy/administrative solution.",
      strengths = strengthsList,
      weaknesses = weaknessesList,
      modelAnswerOutline = "1. Introduction (20-30 words) setting core context.\n2. Body Section A: Key dimensions & arguments.\n3. Body Section B: Value addition (Articles/Data).\n4. Way Forward & Conclusion."
    )
  }

  private fun parseHelperList(jsonArray: JSONArray?): List<String> {
    if (jsonArray == null) return listOf("Structured response provided.")
    val result = mutableListOf<String>()
    for (i in 0 until jsonArray.length()) {
      result.add(jsonArray.getString(i))
    }
    return result.ifEmpty { listOf("Structured response provided.") }
  }
}
