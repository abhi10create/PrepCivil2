package com.prepcivil.app.db

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import org.json.JSONArray
import org.json.JSONObject

data class CanvasPathData(
  val points: List<Pair<Float, Float>>,
  val colorHex: String,
  val strokeWidth: Float,
  val alpha: Float,
  val isEraser: Boolean
)

object CanvasDrawingSerializer {

  fun serializePaths(pathsData: List<CanvasPathData>): String {
    val rootArray = JSONArray()
    for (pData in pathsData) {
      val obj = JSONObject()
      obj.put("colorHex", pData.colorHex)
      obj.put("strokeWidth", pData.strokeWidth.toDouble())
      obj.put("alpha", pData.alpha.toDouble())
      obj.put("isEraser", pData.isEraser)

      val ptsArray = JSONArray()
      for (pt in pData.points) {
        val ptObj = JSONObject()
        ptObj.put("x", pt.first.toDouble())
        ptObj.put("y", pt.second.toDouble())
        ptsArray.put(ptObj)
      }
      obj.put("points", ptsArray)
      rootArray.put(obj)
    }
    return rootArray.toString()
  }

  fun deserializePaths(jsonStr: String): List<CanvasPathData> {
    if (jsonStr.isBlank()) return emptyList()
    val result = mutableListOf<CanvasPathData>()
    try {
      val rootArray = JSONArray(jsonStr)
      for (i in 0 until rootArray.length()) {
        val obj = rootArray.getJSONObject(i)
        val colorHex = obj.optString("colorHex", "#818CF8")
        val strokeWidth = obj.optDouble("strokeWidth", 6.0).toFloat()
        val alpha = obj.optDouble("alpha", 1.0).toFloat()
        val isEraser = obj.optBoolean("isEraser", false)

        val ptsArray = obj.optJSONArray("points") ?: JSONArray()
        val pointsList = mutableListOf<Pair<Float, Float>>()
        for (j in 0 until ptsArray.length()) {
          val ptObj = ptsArray.getJSONObject(j)
          val x = ptObj.optDouble("x", 0.0).toFloat()
          val y = ptObj.optDouble("y", 0.0).toFloat()
          pointsList.add(Pair(x, y))
        }
        result.add(CanvasPathData(pointsList, colorHex, strokeWidth, alpha, isEraser))
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }
    return result
  }
}
