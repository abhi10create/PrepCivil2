package com.prepcivil.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.ErrorRed
import com.prepcivil.app.ui.theme.DarkPurpleText

@Composable
fun AdminMainsManagerSection(
  mainsQuestionsManagerList: List<AdminMainsQuestionItem>,
  onAddClick: () -> Unit,
  onEditClick: (AdminMainsQuestionItem) -> Unit,
  onDeleteClick: (String) -> Unit
) {
  Column(
    verticalArrangement = Arrangement.spacedBy(14.dp),
    modifier = Modifier.testTag("admin_mains_manager_section")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Mains Questions & Model Answers Manager",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "CRUD management for UPSC CSE Mains questions",
          fontSize = 12.sp,
          color = TextSecondary
        )
      }

      Button(
        onClick = onAddClick,
        colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("add_mains_question_btn")
      ) {
        Text("Add Question", color = DarkPurpleText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }

    mainsQuestionsManagerList.forEach { qItem ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = PurpleAccent.copy(alpha = 0.2f)
            ) {
              Text(
                text = qItem.paper,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
            Text(
              text = "${qItem.maxMarks} Marks • ${qItem.targetWords} Words",
              fontSize = 11.sp,
              color = TextMuted
            )
          }

          Text(
            text = qItem.questionText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Text(
            text = "Model Answer Outline:",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = PurpleAccent
          )

          Text(
            text = qItem.modelAnswer,
            fontSize = 12.sp,
            color = TextSecondary,
            maxLines = 3
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(
              onClick = { onEditClick(qItem) },
              shape = RoundedCornerShape(8.dp)
            ) {
              Text("Edit", fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = { onDeleteClick(qItem.id) },
              colors = ButtonDefaults.buttonColors(containerColor = ErrorRed.copy(alpha = 0.8f)),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text("Delete", fontSize = 11.sp, color = Color.White)
            }
          }
        }
      }
    }
  }
}
