package com.prepcivil.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.prepcivil.app.model.Subject
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.db.AppSyncRepository
import com.prepcivil.app.ui.theme.StatusGreen

@Composable
fun WorkspaceSplitScreenView(
    selectedSubject: Subject,
    subjects: List<Subject>,
    onSubjectSelected: (Subject) -> Unit,
    selectedChapter: Chapter,
    chapters: List<Chapter>,
    onChapterSelected: (Chapter) -> Unit,
    completedChapterIds: Set<String>,
    onToggleChapterCompleted: (String) -> Unit,
    isProUser: Boolean,
    onOpenUpgradeModal: () -> Unit,
    isZenMode: Boolean,
    onToggleZenMode: () -> Unit,
    syncRepository: AppSyncRepository? = null
) {
    Row(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .padding(8.dp)
        ) {
            Text(text = selectedSubject.name, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(chapters.size) { index ->
                    val ch = chapters[index]
                    val isSelected = ch.id == selectedChapter.id
                    val isCompleted = completedChapterIds.contains(ch.id)
                    Surface(
                        onClick = { onChapterSelected(ch) },
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = ch.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (isCompleted) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Completed", tint = StatusGreen)
                            }
                        }
                    }
                }
            }
        }
        
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            ReaderPane(
                chapter = selectedChapter,
                isZenMode = isZenMode,
                onToggleZenMode = onToggleZenMode,
                isProUser = isProUser,
                onOpenUpgradeModal = onOpenUpgradeModal,
                isChapterCompleted = completedChapterIds.contains(selectedChapter.id),
                onToggleChapterCompleted = { onToggleChapterCompleted(selectedChapter.id) },
                syncRepository = syncRepository
            )
        }
    }
}
