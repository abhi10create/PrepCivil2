package com.prepcivil.app.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    UserNoteEntity::class,
    CanvasDrawingEntity::class,
    ChapterProgressEntity::class,
    SrsReviewEntity::class,
    StudySessionEntity::class,
    SyncMetaEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun userNoteDao(): UserNoteDao
  abstract fun canvasDrawingDao(): CanvasDrawingDao
  abstract fun chapterProgressDao(): ChapterProgressDao
  abstract fun srsReviewDao(): SrsReviewDao
  abstract fun studySessionDao(): StudySessionDao
  abstract fun syncMetaDao(): SyncMetaDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "prep_civil_study_db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
