package com.prepcivil.app.model

import android.content.Context
import android.content.SharedPreferences

object SyllabusProgressManager {
  private const val PREFS_NAME = "edu_study_syllabus_prefs"
  private const val KEY_COMPLETED_CHAPTER_IDS = "completed_chapter_ids"

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  fun getCompletedChapterIds(context: Context): Set<String> {
    val prefs = getPrefs(context)
    return prefs.getStringSet(KEY_COMPLETED_CHAPTER_IDS, emptySet()) ?: emptySet()
  }

  fun setChapterCompleted(context: Context, chapterId: String, completed: Boolean): Set<String> {
    val currentSet = getCompletedChapterIds(context).toMutableSet()
    if (completed) {
      currentSet.add(chapterId)
    } else {
      currentSet.remove(chapterId)
    }
    getPrefs(context).edit().putStringSet(KEY_COMPLETED_CHAPTER_IDS, currentSet).apply()
    return currentSet
  }

  fun toggleChapterCompleted(context: Context, chapterId: String): Pair<Boolean, Set<String>> {
    val currentSet = getCompletedChapterIds(context).toMutableSet()
    val isNowCompleted = if (currentSet.contains(chapterId)) {
      currentSet.remove(chapterId)
      false
    } else {
      currentSet.add(chapterId)
      true
    }
    getPrefs(context).edit().putStringSet(KEY_COMPLETED_CHAPTER_IDS, currentSet).apply()
    return Pair(isNowCompleted, currentSet)
  }

  fun calculateSubjectProgress(subject: Subject, completedIds: Set<String>): Float {
    if (subject.chapters.isEmpty()) return 0f
    val completedCount = subject.chapters.count { completedIds.contains(it.id) }
    return (completedCount.toFloat() / subject.chapters.size.toFloat()).coerceIn(0f, 1f)
  }

  fun getSubjectCompletedCount(subject: Subject, completedIds: Set<String>): Int {
    return subject.chapters.count { completedIds.contains(it.id) }
  }

  fun calculateOverallMastery(subjects: List<Subject>, completedIds: Set<String>): Int {
    val totalChapters = subjects.sumOf { it.chapters.size }
    if (totalChapters == 0) return 0
    val totalCompleted = subjects.sumOf { subject ->
      subject.chapters.count { completedIds.contains(it.id) }
    }
    return ((totalCompleted.toFloat() / totalChapters.toFloat()) * 100).toInt().coerceIn(0, 100)
  }

  fun getTotalCompletedChaptersCount(subjects: List<Subject>, completedIds: Set<String>): Int {
    return subjects.sumOf { subject ->
      subject.chapters.count { completedIds.contains(it.id) }
    }
  }

  fun getTotalChaptersCount(subjects: List<Subject>): Int {
    return subjects.sumOf { it.chapters.size }
  }
}
