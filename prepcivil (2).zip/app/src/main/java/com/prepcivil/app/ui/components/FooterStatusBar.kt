package com.prepcivil.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun FooterStatusBar(
  masteryPercentage: Int,
  modifier: Modifier = Modifier
) {
  var currentTimeString by remember {
    mutableStateOf(SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()))
  }

  // Update time every 10 seconds
  LaunchedEffect(Unit) {
    while (true) {
      delay(10_000)
      currentTimeString = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
    }
  }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .height(36.dp)
      .background(DarkContainer)
      .border(1.dp, DarkBorder)
      .padding(horizontal = 16.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = "PrepCivil Dashboard",
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      color = TextMuted,
      modifier = Modifier.testTag("app_brand_indicator")
    )

    // Mastery & Time
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Text(
        text = "$masteryPercentage% Mastery",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = TextSecondary,
        modifier = Modifier.testTag("mastery_indicator")
      )

      Text(
        text = currentTimeString,
        fontSize = 11.sp,
        color = TextMuted,
        modifier = Modifier.testTag("time_indicator")
      )
    }
  }
}
