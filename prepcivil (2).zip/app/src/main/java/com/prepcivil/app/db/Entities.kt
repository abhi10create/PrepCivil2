package com.prepcivil.app.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_notes")
data class UserNoteEntity(
  @PrimaryKey val id: String,
  val chapterId: String,
  val paragraphIndex: Int,
  val selectedText: String,
  val colorHex: String,
  val colorName: String,
  val note: String = "",
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "canvas_drawings")
data class CanvasDrawingEntity(
  @PrimaryKey val chapterId: String, // "global" or specific chapter ID
  val serializedPathsJson: String,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chapter_progress")
data class ChapterProgressEntity(
  @PrimaryKey val chapterId: String,
  val isCompleted: Boolean,
  val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "srs_reviews")
data class SrsReviewEntity(
  @PrimaryKey val flashcardId: String,
  val userRatingName: String?, // "EASY", "GOOD", "HARD"
  val nextReviewDays: Int,
  val stageName: String, // "NEW", "DUE", "LEARNING", "MASTERED"
  val lastReviewedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
  @PrimaryKey val dateKey: String, // e.g., "Mon", "Tue", "2026-08-07"
  val studyTimeHours: Float,
  val flashcardsReviewedCount: Int,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sync_meta")
data class SyncMetaEntity(
  @PrimaryKey val key: String,
  val value: String,
  val updatedAt: Long = System.currentTimeMillis()
)
