package com.prepcivil.app.model

import androidx.compose.ui.graphics.Color

data class PredefinedChapter(
  val id: String,
  val chapterNumber: Int,
  val title: String,
  val subtitle: String,
  val defaultIsPremium: Boolean = false,
  val topics: List<String> = emptyList()
)

data class PredefinedBook(
  val id: String,
  val bookName: String,
  val authorOrPublisher: String,
  val subjectName: String,
  val badgeColor: Color,
  val description: String,
  val chapters: List<PredefinedChapter>
)

object UpscBookCatalog {
  val books: List<PredefinedBook> = listOf(
    PredefinedBook(
      id = "laxmikanth_polity",
      bookName = "Indian Polity",
      authorOrPublisher = "M. Laxmikanth (7th Edition)",
      subjectName = "Indian Polity & Governance",
      badgeColor = Color(0xFFBB86FC), // PurpleAccent
      description = "Standard Bible for Indian Constitution, Governance & Polity for UPSC CSE.",
      chapters = listOf(
        PredefinedChapter(
          id = "pol_ch1",
          chapterNumber = 1,
          title = "Historical Background",
          subtitle = "Regulating Act 1773 to Indian Independence Act 1947",
          defaultIsPremium = false,
          topics = listOf("Company Rule (1773-1858)", "Crown Rule (1858-1947)", "GOI Acts 1919 & 1935")
        ),
        PredefinedChapter(
          id = "pol_ch2",
          chapterNumber = 2,
          title = "Making of the Constitution",
          subtitle = "Constituent Assembly, Committees & Drafting Process",
          defaultIsPremium = false,
          topics = listOf("Cabinet Mission Plan", "Drafting Committee", "Objectives Resolution")
        ),
        PredefinedChapter(
          id = "pol_ch3",
          chapterNumber = 3,
          title = "Salient Features & Preamble",
          subtitle = "Lengthiest Written Constitution, Borrowed Features & Philosophy",
          defaultIsPremium = false,
          topics = listOf("42nd Amendment 1976", "Kesavananda Bharati Case", "Sovereign Secular Socialist")
        ),
        PredefinedChapter(
          id = "pol_ch4",
          chapterNumber = 4,
          title = "Fundamental Rights (Part III)",
          subtitle = "Articles 12 to 35 - Magna Carta of India & Writs",
          defaultIsPremium = true,
          topics = listOf("Right to Equality", "Art 21 Personal Liberty", "Article 32 Writs")
        ),
        PredefinedChapter(
          id = "pol_ch5",
          chapterNumber = 5,
          title = "DPSP & Fundamental Duties",
          subtitle = "Part IV (Art 36-51) & Part IVA (Art 51A)",
          defaultIsPremium = true,
          topics = listOf("Socialistic & Gandhian Principles", "Uniform Civil Code Art 44", "Swaran Singh Committee")
        ),
        PredefinedChapter(
          id = "pol_ch6",
          chapterNumber = 6,
          title = "Parliament & Union Executive",
          subtitle = "President, Prime Minister, Lok Sabha & Rajya Sabha",
          defaultIsPremium = true,
          topics = listOf("President Electoral College", "Art 110 Money Bills", "Art 123 Ordinances")
        ),
        PredefinedChapter(
          id = "pol_ch7",
          chapterNumber = 7,
          title = "Federal System & Emergency Provisions",
          subtitle = "Articles 352, 356, 360 & Centre-State Relations",
          defaultIsPremium = true,
          topics = listOf("National Emergency", "President's Rule", "Financial Emergency")
        ),
        PredefinedChapter(
          id = "pol_ch8",
          chapterNumber = 8,
          title = "Constitutional Bodies",
          subtitle = "ECI, UPSC, CAG, Finance Commission & Attorney General",
          defaultIsPremium = false,
          topics = listOf("Election Commission Art 324", "CAG Art 148", "Finance Commission Art 280")
        ),
        PredefinedChapter(
          id = "pol_ch9",
          chapterNumber = 9,
          title = "Non-Constitutional Bodies",
          subtitle = "NITI Aayog, NHRC, CVC, CBI & Lokpal",
          defaultIsPremium = false,
          topics = listOf("NITI Aayog Governing Council", "NHRC Powers", "Lokpal & Lokayuktas")
        ),
        PredefinedChapter(
          id = "pol_ch10",
          chapterNumber = 10,
          title = "Panchayati Raj & Local Self-Govt",
          subtitle = "73rd & 74th Constitutional Amendment Acts 1992",
          defaultIsPremium = false,
          topics = listOf("3-Tier Panchayats", "State Election Commission", "Urban Local Bodies")
        )
      )
    ),
    PredefinedBook(
      id = "spectrum_history",
      bookName = "Modern Indian History",
      authorOrPublisher = "Spectrum / Rajiv Ahir",
      subjectName = "Modern History",
      badgeColor = Color(0xFFFFB74D), // Amber accent
      description = "Comprehensive standard handbook covering British expansion, reform movements, and the Indian Freedom Struggle.",
      chapters = listOf(
        PredefinedChapter(
          id = "hist_ch1",
          chapterNumber = 1,
          title = "Sources & Advent of Europeans",
          subtitle = "Portuguese, Dutch, English & French Rivalry (Unit 1)",
          defaultIsPremium = false,
          topics = listOf("Vasco da Gama 1498", "Blue Water Policy", "Carnatic Wars")
        ),
        PredefinedChapter(
          id = "hist_ch2",
          chapterNumber = 2,
          title = "Expansion & British Consolidation",
          subtitle = "Plassey, Buxar, Subsidiary Alliance & Doctrine of Lapse",
          defaultIsPremium = false,
          topics = listOf("Battle of Plassey 1757", "Subsidiary Alliance System", "Annexation of Awadh")
        ),
        PredefinedChapter(
          id = "hist_ch3",
          chapterNumber = 3,
          title = "Socio-Religious Reform Movements",
          subtitle = "Brahmo Samaj, Arya Samaj, Aligarh Movement & Social Reformers",
          defaultIsPremium = false,
          topics = listOf("Raja Ram Mohan Roy", "Swami Dayanand Saraswati", "Sati Abolition 1829")
        ),
        PredefinedChapter(
          id = "hist_ch4",
          chapterNumber = 4,
          title = "Revolt of 1857 & Early Resistance",
          subtitle = "Causes, Key Centers, Leaders & Reasons for Failure",
          defaultIsPremium = true,
          topics = listOf("Mangal Pandey", "Rani Lakshmibai", "Queen's Proclamation 1858")
        ),
        PredefinedChapter(
          id = "hist_ch5",
          chapterNumber = 5,
          title = "INC & Early Nationalist Phase",
          subtitle = "Moderates (1885-1905), Extremists & Swadeshi Movement",
          defaultIsPremium = true,
          topics = listOf("Drain of Wealth Theory", "Partition of Bengal 1905", "Surat Split 1907")
        ),
        PredefinedChapter(
          id = "hist_ch6",
          chapterNumber = 6,
          title = "Gandhian Era & Mass Movements",
          subtitle = "Non-Cooperation, Civil Disobedience & Quit India 1942",
          defaultIsPremium = true,
          topics = listOf("Champaran 1917", "Dandi Salt March 1930", "Do or Die Slogan 1942")
        ),
        PredefinedChapter(
          id = "hist_ch7",
          chapterNumber = 7,
          title = "Constitutional Development under British Rule",
          subtitle = "Morley-Minto, Montagu-Chelmsford & GOI Act 1935",
          defaultIsPremium = false,
          topics = listOf("Separate Electorates 1909", "Dyarchy 1919", "Provincial Autonomy 1935")
        )
      )
    ),
    PredefinedBook(
      id = "ncert_geography",
      bookName = "Certificate & NCERT Geography",
      authorOrPublisher = "GC Leong / NCERT Class 11 & 12",
      subjectName = "Geography",
      badgeColor = Color(0xFF4FC3F7), // Light Blue
      description = "Physical geography fundamentals, Earth interior, Geomorphology, and Indian Drainage & Monsoon dynamics.",
      chapters = listOf(
        PredefinedChapter(
          id = "geo_ch1",
          chapterNumber = 1,
          title = "Physical Geography & Earth's Interior",
          subtitle = "Crust, Mantle, Core, Seismic Waves & Plate Tectonics",
          defaultIsPremium = false,
          topics = listOf("P & S Waves", "Asthenosphere", "Continental Drift & Tectonic Plates")
        ),
        PredefinedChapter(
          id = "geo_ch2",
          chapterNumber = 2,
          title = "Indian Physiography & Drainage",
          subtitle = "Himalayas, Northern Plains, Peninsular Plateau & River Systems",
          defaultIsPremium = false,
          topics = listOf("Bhabar Terai Khadar", "Himalayan vs Peninsular Rivers", "Godavari Dakshin Ganga")
        ),
        PredefinedChapter(
          id = "geo_ch3",
          chapterNumber = 3,
          title = "Atmosphere, Monsoons & Climate",
          subtitle = "Structure of Atmosphere, Insolation, Indian Monsoons & El Niño",
          defaultIsPremium = true,
          topics = listOf("Troposphere & Stratosphere", "ITCZ Shift", "El Niño & Positive IOD")
        ),
        PredefinedChapter(
          id = "geo_ch4",
          chapterNumber = 4,
          title = "Oceanography & Marine Resources",
          subtitle = "Ocean Floor Configuration, Ocean Currents, Tides & Coral Reefs",
          defaultIsPremium = true,
          topics = listOf("Warm vs Cold Ocean Currents", "Salinity & Thermocline", "Coral Bleaching")
        ),
        PredefinedChapter(
          id = "geo_ch5",
          chapterNumber = 5,
          title = "Soils, Vegetation & Indian Agriculture",
          subtitle = "Alluvial, Black & Red Soils, Forests & Crop Seasons (Kharif, Rabi)",
          defaultIsPremium = false,
          topics = listOf("Regur Black Cotton Soil", "Tropical Evergreen Forests", "Cropping Patterns")
        )
      )
    ),
    PredefinedBook(
      id = "ramesh_singh_economy",
      bookName = "Indian Economy",
      authorOrPublisher = "Ramesh Singh (15th Edition)",
      subjectName = "Indian Economy",
      badgeColor = Color(0xFF81C784), // Soft Green
      description = "Macroeconomics, National Income, Monetary Policy, RBI, Budgeting, and Foreign Trade.",
      chapters = listOf(
        PredefinedChapter(
          id = "econ_ch1",
          chapterNumber = 1,
          title = "National Income Accounting",
          subtitle = "GDP, GNP, NNP, Factor Cost & Real Growth Metrics",
          defaultIsPremium = false,
          topics = listOf("GDP vs GNP", "Real vs Nominal GDP", "GDP Deflator")
        ),
        PredefinedChapter(
          id = "econ_ch2",
          chapterNumber = 2,
          title = "Monetary Policy & Banking System",
          subtitle = "Repo Rate, CRR, SLR, RBI & Inflation Targeting MPC",
          defaultIsPremium = false,
          topics = listOf("Monetary Policy Committee", "Quantitative & Qualitative Tools", "NPA & Insolvency Code")
        ),
        PredefinedChapter(
          id = "econ_ch3",
          chapterNumber = 3,
          title = "Fiscal Policy, Budgeting & FRBM",
          subtitle = "Revenue vs Capital Deficit, Fiscal Deficit & FRBM Act 2003",
          defaultIsPremium = true,
          topics = listOf("Fiscal Deficit Formula", "Primary Deficit", "NK Singh FRBM Committee")
        ),
        PredefinedChapter(
          id = "econ_ch4",
          chapterNumber = 4,
          title = "Inflation, WPI, CPI & Business Cycles",
          subtitle = "Headline vs Core Inflation, Price Indices & Stagflation",
          defaultIsPremium = true,
          topics = listOf("Consumer Price Index (CPI)", "Wholesale Price Index (WPI)", "Base Effect")
        ),
        PredefinedChapter(
          id = "econ_ch5",
          chapterNumber = 5,
          title = "External Sector & Foreign Trade",
          subtitle = "Balance of Payments (BoP), Current Account Deficit & Forex Reserves",
          defaultIsPremium = false,
          topics = listOf("Current vs Capital Account", "NEER & REER", "FDI vs FPI Flows")
        )
      )
    ),
    PredefinedBook(
      id = "nitin_singhania_culture",
      bookName = "Indian Art & Culture",
      authorOrPublisher = "Nitin Singhania (4th Edition)",
      subjectName = "Art & Culture",
      badgeColor = Color(0xFFF06292), // Pink / Rose
      description = "Harappan seals, Rock-cut cave architecture, Temple styles, Classical dances, and Literature.",
      chapters = listOf(
        PredefinedChapter(
          id = "art_ch1",
          chapterNumber = 1,
          title = "Indian Architecture & Sculpture",
          subtitle = "Harappan Seals, Mauryan Pillars, Rock-Cut Caves & Stupas",
          defaultIsPremium = false,
          topics = listOf("Lost-Wax Casting", "Sarnath Lion Capital", "Ajanta & Ellora Caves")
        ),
        PredefinedChapter(
          id = "art_ch2",
          chapterNumber = 2,
          title = "Temple Architecture Styles",
          subtitle = "Nagara (North), Dravida (South) & Vesara Styles",
          defaultIsPremium = false,
          topics = listOf("Shikhara & Amalaka", "Gopuram & Vimana", "Brihadeswara Tanjore")
        ),
        PredefinedChapter(
          id = "art_ch3",
          chapterNumber = 3,
          title = "Classical Dances & Music",
          subtitle = "8 Classical Dances of India & Hindustani vs Carnatic Music",
          defaultIsPremium = true,
          topics = listOf("Tribhanga in Odissi", "Sattriya of Assam", "Raga & Tala Systems")
        ),
        PredefinedChapter(
          id = "art_ch4",
          chapterNumber = 4,
          title = "Indian Paintings & Handicrafts",
          subtitle = "Mural Paintings, Miniature Styles (Mughal, Rajput, Pahari) & GI Crafts",
          defaultIsPremium = true,
          topics = listOf("Frescoes of Ajanta", "Pala & Jain Miniatures", "Madhubani & Kalamkari")
        )
      )
    ),
    PredefinedBook(
      id = "shankar_environment",
      bookName = "Environment & Ecology",
      authorOrPublisher = "Shankar IAS Academy",
      subjectName = "Environment & Ecology",
      badgeColor = Color(0xFF26A69A), // Teal
      description = "Ecosystems, Biodiversity conservation, Climate Change COP, Ramsar Wetlands, and National Parks.",
      chapters = listOf(
        PredefinedChapter(
          id = "env_ch1",
          chapterNumber = 1,
          title = "Ecology & Ecosystem Dynamics",
          subtitle = "Food Chains, Ecological Pyramids, Bioaccumulation & Succession",
          defaultIsPremium = false,
          topics = listOf("Ecotone & Edge Effect", "Trophic Levels 10% Law", "Primary vs Secondary Succession")
        ),
        PredefinedChapter(
          id = "env_ch2",
          chapterNumber = 2,
          title = "Biodiversity Conservation",
          subtitle = "National Parks, Wildlife Sanctuaries, Biosphere Reserves & Hotspots",
          defaultIsPremium = false,
          topics = listOf("In-situ vs Ex-situ", "IUCN Red List Categories", "Project Tiger & Elephant")
        ),
        PredefinedChapter(
          id = "env_ch3",
          chapterNumber = 3,
          title = "Climate Change & Conventions",
          subtitle = "UNFCCC COP Summits, Paris Agreement, Kyoto Protocol & Carbon Credit",
          defaultIsPremium = true,
          topics = listOf("Nationally Determined Contributions (NDCs)", "Net Zero 2070 Target", "Loss and Damage Fund")
        ),
        PredefinedChapter(
          id = "env_ch4",
          chapterNumber = 4,
          title = "Pollution & International Treaties",
          subtitle = "Air & Water Pollution, Ramsar Sites, CITES, Basel & Montreal Protocol",
          defaultIsPremium = true,
          topics = listOf("AQI & PM2.5", "Ramsar Wetlands Criteria", "Ozone Layer Protection")
        )
      )
    ),
    PredefinedBook(
      id = "science_tech_core",
      bookName = "Science & Technology",
      authorOrPublisher = "TMH / Standard Reference",
      subjectName = "Science & Technology",
      badgeColor = Color(0xFFAB47BC), // Deep Violet
      description = "Space technology (ISRO), Biotechnology, AI, Quantum Computing, and Defence Developments.",
      chapters = listOf(
        PredefinedChapter(
          id = "st_ch1",
          chapterNumber = 1,
          title = "Space Tech & ISRO Missions",
          subtitle = "PSLV, GSLV LVM3, Chandrayaan-3, Aditya-L1 & Gaganyaan",
          defaultIsPremium = false,
          topics = listOf("Orbits (LEO, GEO, SSO)", "Aditya-L1 Lagrange Point", "NavIC Satellite System")
        ),
        PredefinedChapter(
          id = "st_ch2",
          chapterNumber = 2,
          title = "Biotechnology & Human Health",
          subtitle = "CRISPR-Cas9 Gene Editing, mRNA Vaccines, Stem Cells & Genome India",
          defaultIsPremium = true,
          topics = listOf("DNA vs RNA", "CAR-T Cell Therapy", "Recombinant DNA Tech")
        ),
        PredefinedChapter(
          id = "st_ch3",
          chapterNumber = 3,
          title = "AI, Quantum Computing & Cybersecurity",
          subtitle = "Generative AI, Quantum Supremacy, 5G/6G & National Cyber Policy",
          defaultIsPremium = true,
          topics = listOf("National Quantum Mission", "Generative AI & LLMs", "Critical Information Infrastructure")
        )
      )
    )
  )

  data class QuickPreset(
    val bookId: String,
    val chapterId: String,
    val label: String,
    val category: String
  )

  val quickPresets: List<QuickPreset> = listOf(
    QuickPreset("laxmikanth_polity", "pol_ch3", "Preamble & Salient Features", "Polity"),
    QuickPreset("laxmikanth_polity", "pol_ch4", "Fundamental Rights (Art 12-35)", "Polity"),
    QuickPreset("spectrum_history", "hist_ch4", "Revolt of 1857 & Leaders", "History"),
    QuickPreset("spectrum_history", "hist_ch6", "Gandhian Era & Quit India", "History"),
    QuickPreset("ncert_geography", "geo_ch2", "Indian Rivers & Drainage", "Geography"),
    QuickPreset("ncert_geography", "geo_ch3", "Monsoons & El Niño", "Geography"),
    QuickPreset("ramesh_singh_economy", "econ_ch2", "RBI Banking & Repo Rate", "Economy"),
    QuickPreset("ramesh_singh_economy", "econ_ch3", "Fiscal Deficit & Budgeting", "Economy"),
    QuickPreset("nitin_singhania_culture", "art_ch2", "Temple Styles (Nagara/Dravida)", "Culture"),
    QuickPreset("shankar_environment", "env_ch3", "Climate Change UNFCCC COP", "Environment"),
    QuickPreset("science_tech_core", "st_ch1", "ISRO Chandrayaan & Aditya-L1", "S&T")
  )
}
