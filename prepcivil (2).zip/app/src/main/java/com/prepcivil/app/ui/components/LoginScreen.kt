package com.prepcivil.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import com.prepcivil.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

@Composable
fun LoginScreen(
  onLoginSuccess: (userId: String, userEmail: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var isSignUpMode by remember { mutableStateOf(false) }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var passwordVisible by remember { mutableStateOf(false) }
  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val coroutineScope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF19181F))
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("login_card"),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(
        containerColor = Color(0xFF26242E)
      ),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3F3B4C))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
      ) {
        // App Logo & Title
        Box(
          modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .border(1.5.dp, Color(0xFF818CF8), CircleShape)
            .background(Color(0xFF21133B))
            .padding(6.dp),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_prep_civil_logo),
            contentDescription = "PrepCivil Logo",
            modifier = Modifier
              .fillMaxSize()
              .clip(CircleShape)
          )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "PrepCivil Portal",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = if (isSignUpMode) "Create an account to track your progress" else "Sign in to access your UPSC study suite",
            fontSize = 13.sp,
            color = Color(0xFF9E9AAB),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
          )
        }

        // Mode Toggle (Sign In / Sign Up)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF17161C))
            .padding(4.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (!isSignUpMode) Color(0xFFB5A4F4) else Color.Transparent)
              .clickable {
                isSignUpMode = false
                errorMessage = null
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Sign In",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = if (!isSignUpMode) Color(0xFF21133B) else Color(0xFF9E9AAB)
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSignUpMode) Color(0xFFB5A4F4) else Color.Transparent)
              .clickable {
                isSignUpMode = true
                errorMessage = null
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Sign Up",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = if (isSignUpMode) Color(0xFF21133B) else Color(0xFF9E9AAB)
            )
          }
        }

        // Error Banner
        AnimatedVisibility(visible = errorMessage != null) {
          errorMessage?.let { err ->
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFF33221A),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7A3E26))
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.ErrorOutline,
                  contentDescription = null,
                  tint = Color(0xFFFF8A65),
                  modifier = Modifier.size(20.dp)
                )
                Text(
                  text = err,
                  fontSize = 12.sp,
                  color = Color(0xFFFFCCBC),
                  fontWeight = FontWeight.Medium
                )
              }
            }
          }
        }

        // Email Field
        OutlinedTextField(
          value = email,
          onValueChange = {
            email = it
            errorMessage = null
          },
          label = { Text("Email Address") },
          leadingIcon = {
            Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFF9E9AAB))
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Email,
            imeAction = ImeAction.Next
          ),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFB5A4F4),
            unfocusedBorderColor = Color(0xFF3F3B4C),
            focusedLabelColor = Color(0xFFB5A4F4),
            unfocusedLabelColor = Color(0xFF9E9AAB),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("email_input_field")
        )

        // Password Field
        OutlinedTextField(
          value = password,
          onValueChange = {
            password = it
            errorMessage = null
          },
          label = { Text("Password") },
          leadingIcon = {
            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF9E9AAB))
          },
          trailingIcon = {
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
              Icon(
                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                contentDescription = if (passwordVisible) "Hide password" else "Show password",
                tint = Color(0xFF9E9AAB)
              )
            }
          },
          singleLine = true,
          visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Password,
            imeAction = ImeAction.Done
          ),
          keyboardActions = KeyboardActions(
            onDone = {
              if (email.isNotBlank() && password.isNotBlank() && !isLoading) {
                performAuth(
                  isSignUpMode = isSignUpMode,
                  email = email,
                  password = password,
                  onStart = { isLoading = true; errorMessage = null },
                  onError = { msg -> isLoading = false; errorMessage = msg },
                  onSuccess = { uid, emailStr ->
                    isLoading = false
                    onLoginSuccess(uid, emailStr)
                  },
                  coroutineScope = coroutineScope
                )
              }
            }
          ),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFB5A4F4),
            unfocusedBorderColor = Color(0xFF3F3B4C),
            focusedLabelColor = Color(0xFFB5A4F4),
            unfocusedLabelColor = Color(0xFF9E9AAB),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("password_input_field")
        )

        // Main Submit Button (Email/Password)
        Button(
          onClick = {
            if (email.isBlank() || password.isBlank()) {
              errorMessage = "Please enter both email and password."
              return@Button
            }
            performAuth(
              isSignUpMode = isSignUpMode,
              email = email,
              password = password,
              onStart = { isLoading = true; errorMessage = null },
              onError = { msg -> isLoading = false; errorMessage = msg },
              onSuccess = { uid, emailStr ->
                isLoading = false
                onLoginSuccess(uid, emailStr)
              },
              coroutineScope = coroutineScope
            )
          },
          enabled = !isLoading,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("login_submit_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFFB5A4F4),
            contentColor = Color(0xFF21133B)
          )
        ) {
          if (isLoading) {
            CircularProgressIndicator(
              modifier = Modifier.size(24.dp),
              color = Color(0xFF21133B),
              strokeWidth = 2.dp
            )
          } else {
            Text(
              text = if (isSignUpMode) "Create Account" else "Sign In",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}

private fun performAuth(
  isSignUpMode: Boolean,
  email: String,
  password: String,
  onStart: () -> Unit,
  onError: (String) -> Unit,
  onSuccess: (uid: String, email: String) -> Unit,
  coroutineScope: CoroutineScope
) {
  coroutineScope.launch(Dispatchers.IO) {
    withContext(Dispatchers.Main) { onStart() }
    try {
      val auth = FirebaseAuth.getInstance()
      val trimmedEmail = email.trim()
      if (isSignUpMode) {
        val authResult = auth.createUserWithEmailAndPassword(trimmedEmail, password).await()
        val user = authResult.user
        val uid = user?.uid ?: throw IllegalStateException("Failed to create user account")
        val isAdmin = trimmedEmail.equals("sabhishek607@gmail.com", ignoreCase = true)

        // Save user record in Firestore
        try {
          val firestore = FirebaseFirestore.getInstance()
          val userData = hashMapOf<String, Any>(
            "email" to trimmedEmail,
            "isAdmin" to isAdmin,
            "role" to if (isAdmin) "admin" else "user",
            "createdAt" to Timestamp.now()
          )
          firestore.collection("users").document(uid).set(userData).await()
        } catch (_: Exception) {}

        withContext(Dispatchers.Main) {
          onSuccess(uid, trimmedEmail)
        }
      } else {
        val authResult = auth.signInWithEmailAndPassword(trimmedEmail, password).await()
        val user = authResult.user
        val uid = user?.uid ?: throw IllegalStateException("Authentication failed")
        val userEmail = user.email ?: trimmedEmail

        // Check/create user document in Firestore upon login
        try {
          val firestore = FirebaseFirestore.getInstance()
          val userDoc = firestore.collection("users").document(uid).get().await()
          if (!userDoc.exists()) {
            val isAdmin = userEmail.equals("sabhishek607@gmail.com", ignoreCase = true)
            val userData = hashMapOf<String, Any>(
              "email" to userEmail,
              "isAdmin" to isAdmin,
              "role" to if (isAdmin) "admin" else "user",
              "createdAt" to Timestamp.now()
            )
            firestore.collection("users").document(uid).set(userData).await()
          }
        } catch (_: Exception) {}

        withContext(Dispatchers.Main) {
          onSuccess(uid, userEmail)
        }
      }
    } catch (e: Exception) {
      val rawMsg = e.localizedMessage ?: e.message ?: "Authentication failed"
      val userFriendlyMsg = when {
        rawMsg.contains("invalid-email", ignoreCase = true) -> "Please enter a valid email address."
        rawMsg.contains("wrong-password", ignoreCase = true) || rawMsg.contains("invalid-credential", ignoreCase = true) -> "Incorrect email or password."
        rawMsg.contains("user-not-found", ignoreCase = true) -> "No user account found with this email."
        rawMsg.contains("email-already-in-use", ignoreCase = true) -> "An account with this email already exists."
        rawMsg.contains("weak-password", ignoreCase = true) -> "Password should be at least 6 characters."
        else -> rawMsg
      }
      withContext(Dispatchers.Main) {
        onError(userFriendlyMsg)
      }
    }
  }
}

