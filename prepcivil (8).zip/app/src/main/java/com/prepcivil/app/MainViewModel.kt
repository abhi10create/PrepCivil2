package com.prepcivil.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.prepcivil.app.db.UserPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val userPreferencesRepository = UserPreferencesRepository(application)

  val isDarkMode: StateFlow<Boolean> = userPreferencesRepository.isDarkModeFlow
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = true
    )

  private val _isAuthChecking = MutableStateFlow<Boolean>(true)
  val isAuthChecking: StateFlow<Boolean> = _isAuthChecking.asStateFlow()

  private val _isAdmin = MutableStateFlow<Boolean>(false)
  val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

  private val _isProUser = MutableStateFlow<Boolean>(false)
  val isProUser: StateFlow<Boolean> = _isProUser.asStateFlow()

  private val _activePlanType = MutableStateFlow<String>("free")
  val activePlanType: StateFlow<String> = _activePlanType.asStateFlow()

  private val _isLoggedIn = MutableStateFlow<Boolean>(FirebaseAuth.getInstance().currentUser != null)
  val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

  private val _currentUserEmail = MutableStateFlow<String>(FirebaseAuth.getInstance().currentUser?.email ?: "")
  val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

  private val _currentUserId = MutableStateFlow<String>(FirebaseAuth.getInstance().currentUser?.uid ?: "")
  val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

  init {
    checkUserSession()
  }

  fun checkUserSession() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val auth = FirebaseAuth.getInstance()
        val user = auth.currentUser
        if (user != null) {
          _isLoggedIn.value = true
          _currentUserId.value = user.uid
          val email = user.email ?: if (user.isAnonymous) "Guest User" else "user@prepcivil.app"
          _currentUserEmail.value = email
          fetchAndSyncUserProfile(user.uid, email)
        } else {
          _isLoggedIn.value = false
          _isAdmin.value = false
        }
      } catch (e: Exception) {
        _isLoggedIn.value = false
        _isAdmin.value = false
      } finally {
        _isAuthChecking.value = false
      }
    }
  }

  fun onUserAuthenticated(uid: String, email: String) {
    viewModelScope.launch(Dispatchers.IO) {
      _isLoggedIn.value = true
      _currentUserId.value = uid
      _currentUserEmail.value = email.ifBlank { "Guest User" }
      fetchAndSyncUserProfile(uid, email)
    }
  }

  private suspend fun fetchAndSyncUserProfile(userId: String, emailStr: String) {
    try {
      val firestore = FirebaseFirestore.getInstance()
      val userDoc = firestore.collection("users").document(userId).get().await()

      var isUserAdmin = false
      var isUserPro = false
      var planStr = "free"
      if (userDoc.exists()) {
        val adminFlag = userDoc.getBoolean("isAdmin") ?: false
        val role = userDoc.getString("role") ?: ""
        planStr = userDoc.getString("plan") ?: "free"
        if (adminFlag || role.equals("admin", ignoreCase = true) || emailStr.equals("sabhishek607@gmail.com", ignoreCase = true)) {
          isUserAdmin = true
        }
        isUserPro = (userDoc.getBoolean("isPro") == true) ||
                    (userDoc.getBoolean("isSubscribed") == true) ||
                    (!planStr.equals("free", ignoreCase = true))
      } else {
        if (emailStr.equals("sabhishek607@gmail.com", ignoreCase = true)) {
          isUserAdmin = true
        }
        val userData = hashMapOf<String, Any>(
          "email" to emailStr,
          "isAdmin" to isUserAdmin,
          "isPro" to false,
          "isSubscribed" to false,
          "plan" to "free",
          "role" to if (isUserAdmin) "admin" else "user",
          "createdAt" to Timestamp.now()
        )
        firestore.collection("users").document(userId).set(userData).await()
      }
      _isAdmin.value = isUserAdmin
      _isProUser.value = isUserPro
      _activePlanType.value = planStr
    } catch (e: Exception) {
      if (emailStr.equals("sabhishek607@gmail.com", ignoreCase = true)) {
        _isAdmin.value = true
      }
    }
  }

  fun upgradeToPro(planType: String = "monthly") {
    viewModelScope.launch(Dispatchers.IO) {
      _isProUser.value = true
      _activePlanType.value = planType
      val userId = _currentUserId.value
      if (userId.isNotBlank()) {
        try {
          val firestore = FirebaseFirestore.getInstance()
          val updates = mapOf(
            "isPro" to true,
            "isSubscribed" to true,
            "plan" to planType
          )
          firestore.collection("users").document(userId).update(updates).await()
        } catch (e: Exception) {
          try {
            val firestore = FirebaseFirestore.getInstance()
            val userData = mapOf(
              "isPro" to true,
              "isSubscribed" to true,
              "plan" to planType,
              "email" to _currentUserEmail.value
            )
            firestore.collection("users").document(userId).set(userData, com.google.firebase.firestore.SetOptions.merge()).await()
          } catch (_: Exception) {}
        }
      }
    }
  }

  fun checkAdminStatus() {
    checkUserSession()
  }

  fun signOut() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        FirebaseAuth.getInstance().signOut()
      } catch (_: Exception) {}
      _isLoggedIn.value = false
      _isAdmin.value = false
      _isProUser.value = false
      _currentUserEmail.value = ""
      _currentUserId.value = ""
    }
  }

  fun toggleDarkMode(currentValue: Boolean) {
    viewModelScope.launch {
      userPreferencesRepository.setDarkMode(!currentValue)
    }
  }

  fun setDarkMode(enabled: Boolean) {
    viewModelScope.launch {
      userPreferencesRepository.setDarkMode(enabled)
    }
  }
}

