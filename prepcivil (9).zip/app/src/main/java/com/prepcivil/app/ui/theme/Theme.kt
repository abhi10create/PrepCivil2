package com.prepcivil.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF121216)
val BackgroundDark = Color(0xFF19181F)
val DarkContainer = Color(0xFF1E1D24)
val SurfaceDark = Color(0xFF26242E)
val DarkBorder = Color(0xFF2E2C38)
val DarkPurpleText = Color(0xFFE9D5FF)
val PurpleAccent = Color(0xFF9333EA)
val StatusGreen = Color(0xFF10B981)
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
val ErrorRed = Color(0xFFEF4444)
val HeatmapFill = Color(0xFF059669)
val SelectedTabBorder = Color(0xFF9333EA)
val CanvasBackground = Color(0xFF1E1D24)

private val DarkColorScheme = darkColorScheme(
    primary = PurpleAccent,
    background = DarkBackground,
    surface = DarkContainer,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = PurpleAccent,
    background = Color(0xFFF9FAFB),
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827)
)

@Composable
fun PrepCivilTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

@Composable
fun AppTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    PrepCivilTheme(darkTheme = darkTheme, content = content)
}
