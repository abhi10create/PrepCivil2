package com.prepcivil.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.R
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Subject
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary
import com.prepcivil.app.ui.theme.SurfaceDark
import com.prepcivil.app.ui.theme.SelectedTabBorder

import androidx.compose.ui.res.stringResource

enum class AppTab(val labelRes: Int) {
  DASHBOARD(R.string.tab_dashboard),
  WORKSPACE(R.string.tab_workspace),
  PYQS(R.string.tab_pyqs),
  FLASHCARDS(R.string.tab_flashcards),
  MASTERBANK(R.string.tab_masterbank),
  MAINS_AI(R.string.tab_mains_ai),
  STORE(R.string.tab_store),
  ADMIN(R.string.tab_admin);

  val label: String
    @Composable
    get() = stringResource(id = labelRes)
}

@Composable
fun PrepCivilLogoIcon(
  size: Dp = 48.dp,
  cornerRadius: Dp = 10.dp,
  borderWidth: Dp = 1.2.dp,
  fontSize: TextUnit = 16.sp,
  modifier: Modifier = Modifier
) {
  Image(
    painter = painterResource(id = R.drawable.ic_prep_civil_logo),
    contentDescription = "PrepCivil Logo",
    modifier = modifier.size(size)
  )
}

@Composable
fun PrepCivilTitleText(
  fontSize: TextUnit = 19.sp,
  modifier: Modifier = Modifier
) {
  Text(
    text = buildAnnotatedString {
      withStyle(style = SpanStyle(color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Black)) {
        append("Prep")
      }
      withStyle(style = SpanStyle(color = Color(0xFF818CF8), fontWeight = FontWeight.Black)) {
        append("Civil")
      }
    },
    fontSize = fontSize,
    modifier = modifier
  )
}

@Composable
fun TopNavBar(
  activeTab: AppTab,
  onTabSelected: (AppTab) -> Unit,
  isDarkMode: Boolean,
  onToggleDarkMode: () -> Unit,
  isSubscribed: Boolean = false,
  currentUserEmail: String = "sabhishek607@gmail.com",
  currentUserDisplayName: String = "",
  isAdmin: Boolean = false,
  onUpgradeToPro: (() -> Unit)? = null,
  onLogout: (() -> Unit)? = null
) {
  var showProfileSheet by remember { mutableStateOf(false) }

  val displayName = remember(currentUserEmail, currentUserDisplayName) {
    if (currentUserDisplayName.isNotBlank()) currentUserDisplayName
    else {
      val namePart = currentUserEmail.substringBefore("@")
      if (namePart.isNotBlank()) {
        namePart.split(".", "_", "-")
          .joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
      } else "PrepCivil Aspirant"
    }
  }

  if (showProfileSheet) {
    ProfileBottomSheet(
      userEmail = currentUserEmail,
      displayName = displayName,
      isSubscribed = isSubscribed,
      onDismiss = { showProfileSheet = false },
      onUpgradeToPro = onUpgradeToPro,
      onLogout = onLogout
    )
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.background)
      .border(1.dp, MaterialTheme.colorScheme.outline)
      .padding(horizontal = 12.dp, vertical = 8.dp)
  ) {
    // Top Row: App Title + Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Uniform Monogram Icon (Matches Home Screen App Icon)
        PrepCivilLogoIcon(
          size = 48.dp,
          cornerRadius = 10.dp,
          borderWidth = 1.2.dp,
          fontSize = 16.sp
        )

        // Monogram Icon + Title Row
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          PrepCivilTitleText(
            fontSize = 19.sp,
            modifier = Modifier.testTag("app_title")
          )

          if (isSubscribed) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(
                  Brush.horizontalGradient(
                    listOf(Color(0xFFFBBF24), Color(0xFFEAB308))
                  )
                )
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "PRO",
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0F172A)
              )
            }
          }
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Dark / Light toggle
        IconButton(
          onClick = onToggleDarkMode,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .testTag("dark_mode_toggle")
        ) {
          Icon(
            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
            contentDescription = "Toggle Theme",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
        }

        // Profile Avatar with Initials & Profile Sheet Trigger on Click
        val initials = remember(currentUserEmail) {
          if (currentUserEmail.isBlank() || currentUserEmail.contains("Guest", ignoreCase = true)) {
            "GU"
          } else {
            val namePart = currentUserEmail.substringBefore("@")
            if (namePart.length >= 2) namePart.take(2).uppercase() else namePart.uppercase()
          }
        }

        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .clickable { showProfileSheet = true }
            .testTag("user_profile_avatar"),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = initials,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Tab Switcher Responsive Layout
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .padding(3.dp)
    ) {
      val isWideScreen = maxWidth >= 600.dp

      if (isWideScreen) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          AppTab.entries.forEach { tab ->
            if (tab == AppTab.ADMIN && !isAdmin) return@forEach
            val selected = tab == activeTab
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(
                  if (selected) Color(0xFF302B48)
                  else Color.Transparent
                )
                .border(
                  width = 1.dp,
                  color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                  shape = RoundedCornerShape(12.dp)
                )
                .clickable { onTabSelected(tab) }
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("tab_${tab.name.lowercase()}"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = tab.label,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
              )
            }
          }
        }
      } else {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          AppTab.entries.forEach { tab ->
            if (tab == AppTab.ADMIN && !isAdmin) return@forEach
            val selected = tab == activeTab
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                  if (selected) Color(0xFF302B48)
                  else Color.Transparent
                )
                .border(
                  width = 1.dp,
                  color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                  shape = RoundedCornerShape(12.dp)
                )
                .clickable { onTabSelected(tab) }
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("tab_${tab.name.lowercase()}"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = tab.label,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun SubjectChapterSelectorBar(
  selectedSubject: Subject,
  subjects: List<Subject>,
  onSubjectSelected: (Subject) -> Unit,
  selectedChapter: Chapter,
  chapters: List<Chapter>,
  onChapterSelected: (Chapter) -> Unit,
  completedChapterIds: Set<String> = emptySet(),
  isProUser: Boolean = false,
  onOpenUpgradeModal: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  var subjectMenuExpanded by remember { mutableStateOf(false) }
  var chapterMenuExpanded by remember { mutableStateOf(false) }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surface)
      .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Subject Dropdown Box
    Box(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
          .clickable { subjectMenuExpanded = true }
          .padding(horizontal = 12.dp, vertical = 8.dp)
          .testTag("subject_dropdown"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Subject", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = selectedSubject.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
        Icon(
          imageVector = Icons.Default.ArrowDropDown,
          contentDescription = "Select Subject",
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      DropdownMenu(
        expanded = subjectMenuExpanded,
        onDismissRequest = { subjectMenuExpanded = false },
        modifier = Modifier.background(MaterialTheme.colorScheme.surface)
      ) {
        subjects.forEach { subject ->
          DropdownMenuItem(
            text = {
              Text(
                text = subject.name,
                color = if (subject.id == selectedSubject.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (subject.id == selectedSubject.id) FontWeight.Bold else FontWeight.Normal
              )
            },
            onClick = {
              onSubjectSelected(subject)
              subjectMenuExpanded = false
            }
          )
        }
      }
    }

    // Chapter Dropdown Box
    Box(modifier = Modifier.weight(1.2f)) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
          .clickable { chapterMenuExpanded = true }
          .padding(horizontal = 12.dp, vertical = 8.dp)
          .testTag("chapter_dropdown"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Chapter", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (completedChapterIds.contains(selectedChapter.id)) {
              Text(text = "✓ ", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = StatusGreen)
            }
            Text(
              text = selectedChapter.title,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1
            )
          }
        }
        Icon(
          imageVector = Icons.Default.ArrowDropDown,
          contentDescription = "Select Chapter",
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      DropdownMenu(
        expanded = chapterMenuExpanded,
        onDismissRequest = { chapterMenuExpanded = false },
        modifier = Modifier.background(MaterialTheme.colorScheme.surface)
      ) {
        chapters.distinctBy { it.id }.forEach { chapter ->
          val isLocked = chapter.isPremium && !isProUser
          val isCompleted = completedChapterIds.contains(chapter.id)

          DropdownMenuItem(
            text = {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = (if (isCompleted) "✓ " else "") + chapter.title,
                  color = if (isCompleted) StatusGreen else if (chapter.id == selectedChapter.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                  fontWeight = if (chapter.id == selectedChapter.id || isCompleted) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 13.sp,
                  modifier = Modifier.weight(1f)
                )
                if (isLocked) {
                  Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Premium Locked",
                    tint = Color(0xFFFF8A65),
                    modifier = Modifier.size(14.dp)
                  )
                } else if (isCompleted) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(StatusGreen.copy(alpha = 0.2f))
                      .border(1.dp, StatusGreen, RoundedCornerShape(4.dp))
                      .padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = "DONE",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = StatusGreen
                    )
                  }
                } else {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(Color(0xFF1B5E20))
                      .padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = "FREE",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = StatusGreen
                    )
                  }
                }
              }
            },
            onClick = {
              chapterMenuExpanded = false
              if (isLocked) {
                onOpenUpgradeModal?.invoke()
              } else {
                onChapterSelected(chapter)
              }
            }
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileBottomSheet(
  userEmail: String,
  displayName: String,
  isSubscribed: Boolean,
  onDismiss: () -> Unit,
  onUpgradeToPro: (() -> Unit)?,
  onLogout: (() -> Unit)?
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 16.dp)
        .testTag("profile_bottom_sheet"),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Large Avatar Circle
      val initials = remember(userEmail) {
        val namePart = userEmail.substringBefore("@")
        if (namePart.length >= 2) namePart.take(2).uppercase() else "PC"
      }

      Box(
        modifier = Modifier
          .size(68.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer)
          .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = initials,
          fontSize = 24.sp,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
      }

      // User Info Text
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        Text(
          text = displayName,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = userEmail,
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Subscription Status Badge
      Surface(
        shape = RoundedCornerShape(50.dp),
        color = if (isSubscribed) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (isSubscribed) Color(0xFFF59E0B) else MaterialTheme.colorScheme.outline)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = if (isSubscribed) Icons.Default.WorkspacePremium else Icons.Default.StarOutline,
            contentDescription = null,
            tint = if (isSubscribed) Color(0xFFD97706) else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = if (isSubscribed) "PRO PASS MEMBER" else "FREE TIER PLAN",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSubscribed) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Upgrade to Pro Option Button
      Button(
        onClick = {
          onDismiss()
          onUpgradeToPro?.invoke()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("profile_upgrade_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isSubscribed) Color(0xFF818CF8) else Color(0xFF6366F1),
          contentColor = Color.White
        )
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.WorkspacePremium,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = if (isSubscribed) "Manage Pro Subscription" else "Upgrade to Pro Pass",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }
      }

      // Sign Out Button
      OutlinedButton(
        onClick = {
          onDismiss()
          onLogout?.invoke()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("profile_sign_out_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(
          contentColor = MaterialTheme.colorScheme.error
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ExitToApp,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "Sign Out",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
