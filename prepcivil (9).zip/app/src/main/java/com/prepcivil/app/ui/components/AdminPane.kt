package com.prepcivil.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Flashcard
import com.prepcivil.app.model.QuizQuestion
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.ErrorRed
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import com.prepcivil.app.model.PredefinedBook
import com.prepcivil.app.model.PredefinedChapter
import com.prepcivil.app.model.UpscBookCatalog

data class AdminMainsQuestionItem(
  val id: String,
  val paper: String,
  val questionText: String,
  val maxMarks: Int,
  val targetWords: Int,
  val modelAnswer: String,
  val keyPoints: List<String>
)

data class AdminUserRecord(
  val id: String,
  val email: String,
  val name: String,
  val isPro: Boolean,
  val dailyLimitUsed: Int,
  val dailyLimitMax: Int
)

private fun generateAiContent(
  sourceBook: String,
  subject: String,
  title: String,
  isPremium: Boolean
): Chapter {
  val cleanId = title.lowercase().replace(Regex("[^a-z0-9]"), "_")

  val notes = listOf(
    "Synthesized from $sourceBook for Civil Services Examination.",
    "Core Objectives & Key Constitutional Directives for $title:",
    "1. Fundamental Framework: Establishes the core principles and statutory provisions governing $title under $sourceBook.",
    "2. Source of Constitutional Authority: Grounded in constitutional provisions, legislative enactments, and judicial precedents.",
    "3. Key Objectives & Scope: Enhances administrative efficiency, protects fundamental rights, and ensures transparent governance.",
    "4. Historical Milestones & Evolution: Evolved through major constitutional amendments, parliamentary acts, and landmark judgments.",
    "5. Amendability & Statutory Scope: Regulated by statutory rules, parliamentary oversight, and constitutional safeguards.",
    "6. Comparative Analysis: Bridges Indian constitutional principles with global standards in public administration and law.",
    "7. Institutional Machinery: Administered by central/state ministries, statutory commissions, and executive bodies.",
    "8. Practical Application: Critical for UPSC Prelims statement questions and Mains analytical answer writing.",
    "9. Contemporary Relevance: Frequently featured in current affairs, policy reforms, and Supreme Court rulings.",
    "10. Key Terminology: Essential concepts including locus standi, doctrine of severability, and basic structure.",
    "11. Analytical Perspective: Balanced approach evaluating strengths, challenges, and reform recommendations.",
    "12. PYQ Weightage: High yield topic tested consistently across last 10 years of Civil Services examinations.",
    "13. Administrative Accountability: Features checks and balances between legislature, executive, and judiciary.",
    "14. Public Policy Implications: Direct impact on socio-economic development, governance metrics, and citizen rights.",
    "15. Model Answer Strategy: Structure answers with intro, core arguments, landmark cases, and way forward."
  )

  val dummyChapter = Chapter(
    id = "ch_gen_$cleanId",
    title = title,
    subtitle = "Derived from $sourceBook",
    textContent = notes,
    flashcards = emptyList(),
    quizQuestions = emptyList(),
    isPremium = isPremium
  )

  val fullFlashcards = com.prepcivil.app.model.QuestionGenerator.get20Flashcards(dummyChapter, subject)
  val fullMcqs = com.prepcivil.app.model.QuestionGenerator.get20MasterbankQuestions(dummyChapter, subject)

  return dummyChapter.copy(
    flashcards = fullFlashcards,
    quizQuestions = fullMcqs
  )
}

@Composable
fun AdminPane(
  onPublishChapter: (subjectName: String, chapter: Chapter) -> Unit,
  isAdminAuthenticated: Boolean = true,
  currentUserEmail: String = "sabhishek607@gmail.com",
  onLogoutAdmin: () -> Unit = {},
  onReturnToDashboard: () -> Unit = {}
) {
  if (currentUserEmail != "sabhishek607@gmail.com") {
    onReturnToDashboard()
    return
  }

  if (!isAdminAuthenticated) {
    // Access Denied Screen for Unauthorized Non-Admin Users
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("access_denied_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(ErrorRed)
        )
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(28.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(ErrorRed.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AdminPanelSettings,
              contentDescription = "Access Denied",
              tint = ErrorRed,
              modifier = Modifier.size(32.dp)
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = "Access Denied",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = ErrorRed,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "Restricted to Authorized Administrators. Non-admin users cannot access AI content generation and publishing tools.",
            fontSize = 13.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(24.dp))

          Button(
            onClick = onReturnToDashboard,
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp)
              .testTag("return_to_dashboard_button")
          ) {
            Text(
              text = "Return to Main Dashboard",
              color = DarkPurpleText,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
    return
  }

  val defaultBook = UpscBookCatalog.books.first()
  val defaultChapter = defaultBook.chapters[2] // Preamble

  var adminTabSelection by remember { mutableIntStateOf(0) }

  var mainsQuestionsManagerList by remember { mutableStateOf(listOf(
    AdminMainsQuestionItem(
      id = "mq_1",
      paper = "GS Paper 2 (Polity)",
      questionText = "Discuss the role of the Governor in Indian federalism. Why has the office of the Governor been a subject of controversy in recent years? Suggest concrete measures for reform.",
      maxMarks = 15,
      targetWords = 250,
      modelAnswer = "The Governor in India occupies a dual constitutional position under Article 153 and as a vital link between the Union and the States.",
      keyPoints = listOf("Dual role (Art 153)", "Art 163 & 200 controversies", "Sarkaria & Punchhi Commissions", "Cooperative federalism")
    ),
    AdminMainsQuestionItem(
      id = "mq_2",
      paper = "GS Paper 1 (Culture)",
      questionText = "Examine the significance of the Bhakti Movement in Indian culture and discuss its impact on regional vernacular languages and social reform.",
      maxMarks = 15,
      targetWords = 250,
      modelAnswer = "The Bhakti Movement democratised spiritual pursuit, broke caste barriers, and fostered regional vernacular literature.",
      keyPoints = listOf("Vernacular languages", "Caste reform", "Bhakti literature", "Sufi syncretism")
    )
  )) }

  var adminUsersList by remember { mutableStateOf(listOf(
    AdminUserRecord("1", "sabhishek607@gmail.com", "Abhishek (Admin)", true, 2, 50),
    AdminUserRecord("2", "rahul.sharma@gmail.com", "Rahul Sharma", false, 5, 5),
    AdminUserRecord("3", "priya.verma@gmail.com", "Priya Verma", true, 14, 50),
    AdminUserRecord("4", "amit.kumar@gmail.com", "Amit Kumar", false, 5, 5),
    AdminUserRecord("5", "neha.singh@gmail.com", "Neha Singh", false, 3, 5)
  )) }

  var showMainsEditorDialog by remember { mutableStateOf(false) }
  var editingMainsItem by remember { mutableStateOf<AdminMainsQuestionItem?>(null) }
  var formPaper by remember { mutableStateOf("GS Paper 2 (Polity)") }
  var formQuestionText by remember { mutableStateOf("") }
  var formMaxMarks by remember { mutableStateOf("15") }
  var formTargetWords by remember { mutableStateOf("250") }
  var formModelAnswer by remember { mutableStateOf("") }
  var formKeyPoints by remember { mutableStateOf("") }

  var isStructuredSelectionMode by remember { mutableStateOf(true) }
  var bookSearchQuery by remember { mutableStateOf("") }
  var selectedBook by remember { mutableStateOf(defaultBook) }
  var selectedChapter by remember { mutableStateOf(defaultChapter) }

  var bookSource by remember { mutableStateOf("${defaultBook.bookName} (${defaultBook.authorOrPublisher})") }
  var subjectName by remember { mutableStateOf(defaultBook.subjectName) }
  var chapterTitle by remember { mutableStateOf("Chapter ${defaultChapter.chapterNumber}: ${defaultChapter.title}") }
  var isPremium by remember { mutableStateOf(defaultChapter.defaultIsPremium) }

  var isGenerating by remember { mutableStateOf(false) }
  var generatedChapter by remember { mutableStateOf<Chapter?>(null) }
  var activePreviewTab by remember { mutableIntStateOf(0) }
  var publishSuccessMessage by remember { mutableStateOf<String?>(null) }

  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp)
      .verticalScroll(scrollState),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Admin Module Navigation Tabs
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(DarkContainer)
        .padding(4.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      val titles = listOf("AI Generator", "Mains Manager", "Users & Limits", "GitHub Sync")
      titles.forEachIndexed { index, title ->
        val selected = adminTabSelection == index
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) PurpleAccent else Color.Transparent)
            .clickable { adminTabSelection = index }
            .padding(vertical = 10.dp)
            .testTag("admin_tab_$index"),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) DarkPurpleText else TextSecondary,
            maxLines = 1
          )
        }
      }
    }

    if (adminTabSelection == 1) {
      AdminMainsManagerSection(
        mainsQuestionsManagerList = mainsQuestionsManagerList,
        onAddClick = {
          editingMainsItem = null
          formPaper = "GS Paper 2 (Polity)"
          formQuestionText = ""
          formMaxMarks = "15"
          formTargetWords = "250"
          formModelAnswer = ""
          formKeyPoints = ""
          showMainsEditorDialog = true
        },
        onEditClick = { qItem ->
          editingMainsItem = qItem
          formPaper = qItem.paper
          formQuestionText = qItem.questionText
          formMaxMarks = qItem.maxMarks.toString()
          formTargetWords = qItem.targetWords.toString()
          formModelAnswer = qItem.modelAnswer
          formKeyPoints = qItem.keyPoints.joinToString(", ")
          showMainsEditorDialog = true
        },
        onDeleteClick = { id ->
          mainsQuestionsManagerList = mainsQuestionsManagerList.filter { it.id != id }
        }
      )
    } else if (adminTabSelection == 2) {
      AdminUsersManagerSection(
        adminUsersList = adminUsersList,
        onTogglePro = { userId ->
          adminUsersList = adminUsersList.map {
            if (it.id == userId) it.copy(isPro = !it.isPro, dailyLimitMax = if (!it.isPro) 50 else 5) else it
          }
        },
        onResetLimit = { userId ->
          adminUsersList = adminUsersList.map {
            if (it.id == userId) it.copy(dailyLimitUsed = 0) else it
          }
        }
      )
    } else if (adminTabSelection == 3) {
      AdminGitHubSyncSection()
    } else {
      // 0: AI Generator UI
      // 1. Admin Header
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("admin_header_card"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = DarkContainer),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = androidx.compose.ui.graphics.SolidColor(PurpleAccent)
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(PurpleAccent),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = "Admin Panel",
                tint = DarkPurpleText,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AI Course Content Generator",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent
              )
              Text(
                text = "Role: Authorized Administrator",
                fontSize = 11.sp,
                color = StatusGreen,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF1B5E20))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "AI ENGINE ACTIVE",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = StatusGreen
            )
          }
        }

        Text(
          text = "Generate structured notes, UPSC statement MCQs, and SRS flashcards directly from standard reference books using AI models.",
          fontSize = 12.sp,
          color = TextSecondary,
          lineHeight = 16.sp
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          Button(
            onClick = onLogoutAdmin,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3E2723)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.testTag("lock_admin_session_button")
          ) {
            Text(
              text = "Lock Admin Session",
              color = Color(0xFFFF8A65),
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Success Notification Dialog/Banner
    publishSuccessMessage?.let { msg ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("publish_success_banner"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B5E20)),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(StatusGreen)
        )
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Success",
            tint = StatusGreen,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = msg,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    // 2. Structured Selection vs Manual Input Container
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("admin_input_card"),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = DarkContainer),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = androidx.compose.ui.graphics.SolidColor(DarkBorder)
      )
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Mode Header & Switcher (Clean Stacked Segmented Control)
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Book,
              contentDescription = "Book Selection",
              tint = PurpleAccent,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Reference Book & Chapter Selection",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary,
              modifier = Modifier.weight(1f)
            )
          }

          // Full-width Segmented Mode Control
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.background)
              .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isStructuredSelectionMode) PurpleAccent else Color.Transparent)
                .clickable { isStructuredSelectionMode = true }
                .padding(vertical = 8.dp)
                .testTag("mode_structured_selector"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "📚 Preset Catalog",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isStructuredSelectionMode) DarkPurpleText else TextMuted
              )
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (!isStructuredSelectionMode) PurpleAccent else Color.Transparent)
                .clickable { isStructuredSelectionMode = false }
                .padding(vertical = 8.dp)
                .testTag("mode_manual_input"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "✏️ Custom Input",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (!isStructuredSelectionMode) DarkPurpleText else TextMuted
              )
            }
          }
        }

        if (isStructuredSelectionMode) {
          // ==========================================
          // STRUCTURED BOOK & CHAPTER SELECTOR
          // ==========================================

          // Quick Presets Row
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "⚡ High-Yield UPSC Topic Presets (1-Tap Selection):",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextMuted
            )

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              UpscBookCatalog.quickPresets.forEach { preset ->
                val isSelected = selectedBook.id == preset.bookId && selectedChapter.id == preset.chapterId
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) PurpleAccent else MaterialTheme.colorScheme.background)
                    .border(
                      width = 1.dp,
                      color = if (isSelected) PurpleAccent else DarkBorder,
                      shape = RoundedCornerShape(20.dp)
                    )
                    .clickable {
                      val foundBook = UpscBookCatalog.books.find { it.id == preset.bookId } ?: defaultBook
                      selectedBook = foundBook
                      subjectName = foundBook.subjectName
                      bookSource = "${foundBook.bookName} (${foundBook.authorOrPublisher})"

                      val foundCh = foundBook.chapters.find { it.id == preset.chapterId } ?: foundBook.chapters.first()
                      selectedChapter = foundCh
                      chapterTitle = "Chapter ${foundCh.chapterNumber}: ${foundCh.title}"
                      isPremium = foundCh.defaultIsPremium
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("preset_chip_${preset.chapterId}")
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.AutoAwesome,
                      contentDescription = null,
                      tint = if (isSelected) DarkPurpleText else PurpleAccent,
                      modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = preset.label,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) DarkPurpleText else TextPrimary
                    )
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(2.dp))

          // Filter & Search Bar
          OutlinedTextField(
            value = bookSearchQuery,
            onValueChange = { bookSearchQuery = it },
            placeholder = { Text("Filter books/chapters (e.g. Polity, History, Economy, Monsoon)...") },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = PurpleAccent
              )
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("search_catalog_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = PurpleAccent,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedPlaceholderColor = TextMuted,
              unfocusedPlaceholderColor = TextMuted
            ),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )

          // Step 1: Book Selection Cards
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = "1. Select Standard UPSC Reference Book:",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = PurpleAccent
            )

            val filteredBooks = UpscBookCatalog.books.filter { book ->
              bookSearchQuery.isEmpty() ||
                book.bookName.contains(bookSearchQuery, ignoreCase = true) ||
                book.subjectName.contains(bookSearchQuery, ignoreCase = true) ||
                book.authorOrPublisher.contains(bookSearchQuery, ignoreCase = true) ||
                book.chapters.any { it.title.contains(bookSearchQuery, ignoreCase = true) }
            }

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              filteredBooks.forEach { book ->
                val isSelected = selectedBook.id == book.id
                Card(
                  modifier = Modifier
                    .width(220.dp)
                    .clickable {
                      selectedBook = book
                      subjectName = book.subjectName
                      bookSource = "${book.bookName} (${book.authorOrPublisher})"
                      val firstCh = book.chapters.first()
                      selectedChapter = firstCh
                      chapterTitle = "Chapter ${firstCh.chapterNumber}: ${firstCh.title}"
                      isPremium = firstCh.defaultIsPremium
                    }
                    .testTag("book_card_${book.id}"),
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) book.badgeColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background
                  ),
                  border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(
                      if (isSelected) book.badgeColor else DarkBorder
                    )
                  )
                ) {
                  Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(6.dp))
                          .background(book.badgeColor.copy(alpha = 0.2f))
                          .padding(horizontal = 6.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = book.subjectName,
                          fontSize = 9.sp,
                          fontWeight = FontWeight.Bold,
                          color = book.badgeColor
                        )
                      }

                      if (isSelected) {
                        Icon(
                          imageVector = Icons.Default.CheckCircle,
                          contentDescription = "Selected",
                          tint = book.badgeColor,
                          modifier = Modifier.size(16.dp)
                        )
                      }
                    }

                    Text(
                      text = book.bookName,
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )

                    Text(
                      text = book.authorOrPublisher,
                      fontSize = 10.sp,
                      color = TextMuted
                    )

                    Text(
                      text = "📖 ${book.chapters.size} Chapters Available",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = book.badgeColor
                    )
                  }
                }
              }
            }
          }

          // Step 2: Chapter Selection Grid/List
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "2. Pick Specific Chapter from '${selectedBook.bookName}':",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent
              )
              Text(
                text = "${selectedBook.chapters.size} Chapters",
                fontSize = 11.sp,
                color = TextMuted
              )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              selectedBook.chapters.forEach { chapter ->
                val isSelected = selectedChapter.id == chapter.id
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) PurpleAccent.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background)
                    .border(
                      width = if (isSelected) 1.5.dp else 1.dp,
                      color = if (isSelected) PurpleAccent else DarkBorder,
                      shape = RoundedCornerShape(12.dp)
                    )
                    .clickable {
                      selectedChapter = chapter
                      chapterTitle = "Chapter ${chapter.chapterNumber}: ${chapter.title}"
                      isPremium = chapter.defaultIsPremium
                    }
                    .padding(12.dp)
                    .testTag("chapter_item_${chapter.id}")
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Row(
                      modifier = Modifier.weight(1f),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      // Chapter Number Badge
                      Box(
                        modifier = Modifier
                          .size(34.dp)
                          .clip(RoundedCornerShape(8.dp))
                          .background(if (isSelected) PurpleAccent else DarkBorder.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                      ) {
                        Text(
                          text = "Ch ${chapter.chapterNumber}",
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = if (isSelected) DarkPurpleText else TextPrimary
                        )
                      }

                      Spacer(modifier = Modifier.width(12.dp))

                      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                          text = chapter.title,
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Bold,
                          color = TextPrimary
                        )
                        Text(
                          text = chapter.subtitle,
                          fontSize = 11.sp,
                          color = TextSecondary,
                          lineHeight = 14.sp
                        )

                        if (chapter.topics.isNotEmpty()) {
                          Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp)
                          ) {
                            chapter.topics.take(2).forEach { topic ->
                              Box(
                                modifier = Modifier
                                  .clip(RoundedCornerShape(4.dp))
                                  .background(DarkBorder.copy(alpha = 0.4f))
                                  .padding(horizontal = 5.dp, vertical = 2.dp)
                              ) {
                                Text(
                                  text = topic,
                                  fontSize = 9.sp,
                                  color = TextMuted
                                )
                              }
                            }
                          }
                        }
                      }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Access Badge & Select Icon
                    Column(horizontalAlignment = Alignment.End) {
                      if (chapter.defaultIsPremium) {
                        Box(
                          modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFFFD54F).copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                          Text(
                            text = "PRO PASS",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD54F)
                          )
                        }
                      } else {
                        Box(
                          modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(StatusGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                          Text(
                            text = "FREE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusGreen
                          )
                        }
                      }

                      if (isSelected) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Icon(
                          imageVector = Icons.Default.CheckCircle,
                          contentDescription = "Selected Chapter",
                          tint = PurpleAccent,
                          modifier = Modifier.size(18.dp)
                        )
                      }
                    }
                  }
                }
              }
            }
          }

          // Active Configuration Summary Box
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(MaterialTheme.colorScheme.background)
              .border(1.dp, PurpleAccent, RoundedCornerShape(12.dp))
              .padding(14.dp)
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "🎯 Ready to Generate Content For:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StatusGreen
              )
              Text(
                text = "• Book: $bookSource",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
              )
              Text(
                text = "• Subject: $subjectName",
                fontSize = 12.sp,
                color = TextSecondary
              )
              Text(
                text = "• Chapter: $chapterTitle",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent
              )
            }
          }

        } else {
          // ==========================================
          // CUSTOM MANUAL INPUT MODE
          // ==========================================
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              text = "Custom Book & Topic Manual Configuration",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextMuted
            )

            // Book Source Name
            OutlinedTextField(
              value = bookSource,
              onValueChange = { bookSource = it },
              label = { Text("Standard Book / Source Name") },
              placeholder = { Text("e.g. Laxmikanth Polity, Ramesh Singh Economy") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("input_book_source"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurpleAccent,
                unfocusedBorderColor = DarkBorder,
                focusedLabelColor = PurpleAccent,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              ),
              singleLine = true
            )

            // Subject Name
            OutlinedTextField(
              value = subjectName,
              onValueChange = { subjectName = it },
              label = { Text("Subject Name") },
              placeholder = { Text("e.g. Indian Polity & Governance") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("input_subject_name"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurpleAccent,
                unfocusedBorderColor = DarkBorder,
                focusedLabelColor = PurpleAccent,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              ),
              singleLine = true
            )

            // Chapter Title
            OutlinedTextField(
              value = chapterTitle,
              onValueChange = { chapterTitle = it },
              label = { Text("Chapter Title / Topic") },
              placeholder = { Text("e.g. Chapter 3: Preamble of the Constitution") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("input_chapter_title"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurpleAccent,
                unfocusedBorderColor = DarkBorder,
                focusedLabelColor = PurpleAccent,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              ),
              singleLine = true
            )
          }
        }

        // Premium Chapter Access Checkbox
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { isPremium = !isPremium }
            .padding(vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          androidx.compose.material3.Checkbox(
            checked = isPremium,
            onCheckedChange = { isPremium = it },
            colors = androidx.compose.material3.CheckboxDefaults.colors(
              checkedColor = PurpleAccent,
              uncheckedColor = TextMuted
            ),
            modifier = Modifier.testTag("input_premium_checkbox")
          )
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = "Set as Premium Chapter (Pro Pass Required)",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextPrimary
            )
            Text(
              text = "Free users will see a lock icon & upgrade trigger.",
              fontSize = 10.sp,
              color = TextMuted
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Action Buttons Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (bookSource.isNotBlank() && chapterTitle.isNotBlank()) {
                isGenerating = true
                publishSuccessMessage = null
                generatedChapter = generateAiContent(bookSource, subjectName, chapterTitle, isPremium)
                isGenerating = false
              }
            },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("generate_all_button"),
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Generate AI",
                tint = DarkPurpleText,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "⚡ Generate AI Notes, MCQs & Flashcards",
                color = DarkPurpleText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Loading State
    if (isGenerating) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer)
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          CircularProgressIndicator(color = PurpleAccent, modifier = Modifier.size(36.dp))
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "AI is parsing source materials and generating notes, MCQs, and flashcards...",
            fontSize = 13.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center
          )
        }
      }
    }

    // 3. Content Preview Window & Publish
    generatedChapter?.let { ch ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_preview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(PurpleAccent)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Generated Content Preview",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = PurpleAccent
              )
              Text(
                text = "${ch.textContent.size} Sections • ${ch.get20MasterbankQuestions().size} Masterbank MCQs • ${ch.get20Flashcards().size} Flashcards",
                fontSize = 11.sp,
                color = TextMuted
              )
            }

            Button(
              onClick = {
                onPublishChapter(subjectName, ch)
                publishSuccessMessage = "🎉 Successfully published '${ch.title}' under '$subjectName'! Students can now access this chapter across all tools."
              },
              colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("publish_to_app_button")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Publish,
                  contentDescription = "Publish",
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Publish to App",
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Preview Sub-Tabs
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.background)
              .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            val tabs = listOf("Notes (${ch.textContent.size})", "MCQs (${ch.quizQuestions.size})", "Flashcards (${ch.flashcards.size})")
            tabs.forEachIndexed { index, title ->
              val isSelected = activePreviewTab == index
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSelected) PurpleAccent else Color.Transparent)
                  .clickable { activePreviewTab = index }
                  .padding(vertical = 6.dp)
                  .testTag("preview_tab_$index"),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = title,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) DarkPurpleText else TextSecondary
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Content Tab Panels
          when (activePreviewTab) {
            0 -> {
              // Notes Preview
              Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.testTag("preview_notes_section")
              ) {
                ch.textContent.forEach { paragraph ->
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(MaterialTheme.colorScheme.background)
                      .padding(10.dp)
                  ) {
                    Text(
                      text = paragraph,
                      fontSize = 12.sp,
                      color = TextPrimary,
                      lineHeight = 17.sp
                    )
                  }
                }
              }
            }
            1 -> {
              // MCQs Preview
              Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.testTag("preview_mcq_section")
              ) {
                ch.quizQuestions.forEachIndexed { qIdx, question ->
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(MaterialTheme.colorScheme.background)
                      .padding(12.dp)
                  ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                      Text(
                        text = "Q${qIdx + 1}. ${question.questionText}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                      )
                      question.options.forEachIndexed { optIdx, option ->
                        val isCorrect = optIdx == question.correctAnswerIndex
                        Text(
                          text = option,
                          fontSize = 11.sp,
                          color = if (isCorrect) StatusGreen else TextSecondary,
                          fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal
                        )
                      }
                      Text(
                        text = "Explanation: ${question.explanation}",
                        fontSize = 10.sp,
                        color = TextMuted,
                        lineHeight = 14.sp
                      )
                    }
                  }
                }
              }
            }
            2 -> {
              // Flashcards Preview
              Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.testTag("preview_flashcards_section")
              ) {
                ch.flashcards.forEachIndexed { fIdx, flashcard ->
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(MaterialTheme.colorScheme.background)
                      .padding(12.dp)
                  ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Text(
                          text = "Card #${fIdx + 1}",
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = PurpleAccent
                        )
                        Text(
                          text = flashcard.category,
                          fontSize = 10.sp,
                          color = TextMuted
                        )
                      }
                      Text(
                        text = "Q: ${flashcard.question}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                      )
                      Text(
                        text = "A: ${flashcard.answer}",
                        fontSize = 11.sp,
                        color = StatusGreen
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showMainsEditorDialog) {
    androidx.compose.ui.window.Dialog(onDismissRequest = { showMainsEditorDialog = false }) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent),
        modifier = Modifier.fillMaxWidth().padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = if (editingMainsItem == null) "Add New Mains Question" else "Edit Mains Question",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = PurpleAccent
          )

          OutlinedTextField(
            value = formPaper,
            onValueChange = { formPaper = it },
            label = { Text("GS Paper (e.g. GS Paper 2)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          OutlinedTextField(
            value = formQuestionText,
            onValueChange = { formQuestionText = it },
            label = { Text("Question Text") },
            modifier = Modifier.fillMaxWidth()
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = formMaxMarks,
              onValueChange = { formMaxMarks = it },
              label = { Text("Max Marks") },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
            OutlinedTextField(
              value = formTargetWords,
              onValueChange = { formTargetWords = it },
              label = { Text("Target Words") },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
          }

          OutlinedTextField(
            value = formModelAnswer,
            onValueChange = { formModelAnswer = it },
            label = { Text("Model Answer Outline") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = formKeyPoints,
            onValueChange = { formKeyPoints = it },
            label = { Text("Key Points (comma separated)") },
            modifier = Modifier.fillMaxWidth()
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(onClick = { showMainsEditorDialog = false }) {
              Text("Cancel")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                val marksInt = formMaxMarks.toIntOrNull() ?: 15
                val wordsInt = formTargetWords.toIntOrNull() ?: 250
                val kpList = formKeyPoints.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (editingMainsItem == null) {
                  val newItem = AdminMainsQuestionItem(
                    id = "mq_${System.currentTimeMillis()}",
                    paper = formPaper,
                    questionText = formQuestionText,
                    maxMarks = marksInt,
                    targetWords = wordsInt,
                    modelAnswer = formModelAnswer,
                    keyPoints = kpList
                  )
                  mainsQuestionsManagerList = mainsQuestionsManagerList + newItem
                } else {
                  mainsQuestionsManagerList = mainsQuestionsManagerList.map {
                    if (it.id == editingMainsItem!!.id) {
                      it.copy(
                        paper = formPaper,
                        questionText = formQuestionText,
                        maxMarks = marksInt,
                        targetWords = wordsInt,
                        modelAnswer = formModelAnswer,
                        keyPoints = kpList
                      )
                    } else it
                  }
                }
                showMainsEditorDialog = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent)
            ) {
              Text("Save Question", color = DarkPurpleText, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }

  Spacer(modifier = Modifier.height(16.dp))
}
}

@Composable
fun AdminGitHubSyncSection() {
  var repoUrl by remember { mutableStateOf("https://github.com/sabhishek607/PrepCivil-Android.git") }
  var branchName by remember { mutableStateOf("main") }
  var isSyncing by remember { mutableStateOf(false) }
  var syncMessage by remember { mutableStateOf<String?>(null) }
  var showInstructionDialog by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("github_sync_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = DarkContainer),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = androidx.compose.ui.graphics.SolidColor(PurpleAccent)
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "🐙 GitHub Code Repository Sync",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Sync latest code, components, database schemas, and assets to GitHub",
            fontSize = 12.sp,
            color = TextSecondary
          )
        }
      }

      // Repository Status Card
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E1B2E),
        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent.copy(alpha = 0.3f))
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(StatusGreen)
            )
            Text(
              text = "Workspace Git Engine Ready",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = StatusGreen
            )
          }

          Text(
            text = "• Branch: main\n• Platform: Google AI Studio Android Environment\n• Tracked Modules: :app (Kotlin/Compose, Room DB, Gemini SDK, Firebase)",
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 16.sp
          )
        }
      }

      // Method 1: Push via Google AI Studio Header
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161426)),
        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "Option 1: One-Click Sync via AI Studio Header (Recommended)",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = PurpleAccent
          )
          Text(
            text = "You can export and push this entire repository directly to GitHub using the built-in AI Studio export toolbar in your browser top bar.",
            fontSize = 12.sp,
            color = TextSecondary
          )

          Button(
            onClick = {
              showInstructionDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text("📖 View AI Studio GitHub Sync Guide", color = DarkPurpleText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }

      // Method 2: Configure Custom Git Remote
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Text(
          text = "Option 2: Personal GitHub Repository Remote",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )

        OutlinedTextField(
          value = repoUrl,
          onValueChange = { repoUrl = it },
          label = { Text("GitHub Remote URL") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = branchName,
          onValueChange = { branchName = it },
          label = { Text("Branch Name") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Button(
          onClick = {
            isSyncing = true
            syncMessage = "Code compiled & verified! Codebase is ready for GitHub sync."
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(if (isSyncing) "Verifying Workspace..." else "⚡ Verify & Prepare Code for GitHub", color = DarkPurpleText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        syncMessage?.let { msg ->
          Surface(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            shape = RoundedCornerShape(8.dp),
            color = StatusGreen.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, StatusGreen)
          ) {
            Text(
              text = "✓ $msg\nUse the top-right GitHub Export button in AI Studio to complete sync.",
              fontSize = 11.sp,
              color = StatusGreen,
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      }
    }
  }

  if (showInstructionDialog) {
    androidx.compose.ui.window.Dialog(
      onDismissRequest = { showInstructionDialog = false }
    ) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent),
        modifier = Modifier.fillMaxWidth().padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text("🐙 How to Sync to GitHub", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text("Follow these simple steps to sync your app codebase to GitHub:", fontSize = 12.sp, color = TextSecondary)
          Text(
            text = "1. Look at the top menu bar in your Google AI Studio browser interface.\n" +
                   "2. Click the 'Export' or 'GitHub' button.\n" +
                   "3. Connect your GitHub account when prompted.\n" +
                   "4. Choose 'Push to GitHub' and select your repository name.\n" +
                   "5. All Kotlin code, Compose UI, dependencies, and resources will be committed automatically!",
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 18.sp
          )
          Button(
            onClick = { showInstructionDialog = false },
            modifier = Modifier.align(Alignment.End),
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent)
          ) {
            Text("Got it!", color = DarkPurpleText, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

