package com.prepcivil.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import com.prepcivil.app.R
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Subject
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.ErrorRed
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

@Composable
fun PyqPane(
  subjects: List<Subject>,
  initialSubject: Subject,
  initialChapter: Chapter
) {
  var selectedSubject by remember { mutableStateOf(initialSubject) }
  var selectedChapter by remember { mutableStateOf(initialChapter) }

  var subjectDropdownExpanded by remember { mutableStateOf(false) }
  var chapterDropdownExpanded by remember { mutableStateOf(false) }

  var selectedYearFilter by remember { mutableStateOf("All Years") }

  // Get authentic UPSC PYQs (2013 - 2026) for selected chapter
  val allChapterPyqs = remember(selectedChapter) {
    selectedChapter.getPyqQuestions(selectedSubject.name)
  }

  val yearsList = listOf("All Years", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013")

  val filteredPyqs = remember(allChapterPyqs, selectedYearFilter) {
    if (selectedYearFilter == "All Years") {
      allChapterPyqs
    } else {
      allChapterPyqs.filter { 
        (it.year?.contains(selectedYearFilter) == true) || it.questionText.contains(selectedYearFilter)
      }
    }
  }

  val userSelectedAnswers = remember(selectedChapter, selectedYearFilter) { mutableStateMapOf<String, Int>() }

  val scrollState = rememberScrollState()
  val filterScrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp)
      .navigationBarsPadding()
      .padding(bottom = 16.dp)
      .verticalScroll(scrollState)
  ) {
    // 1. HEADER CARD & DROPDOWNS
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("pyq_header_card"),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.HistoryEdu,
              contentDescription = "PYQs",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "UPSC Previous Year Questions (2013 – 2026)",
              fontSize = 16.sp,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              text = "Authentic UPSC Prelims Questions & Official Keys",
              fontSize = 11.sp,
              color = TextMuted
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selectors Row (Subject & Chapter)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Subject Picker
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
              .clickable { subjectDropdownExpanded = true }
              .padding(horizontal = 10.dp, vertical = 8.dp)
              .testTag("pyq_subject_selector")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = stringResource(R.string.subject), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Text(text = selectedSubject.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
              }
              Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            DropdownMenu(
              expanded = subjectDropdownExpanded,
              onDismissRequest = { subjectDropdownExpanded = false }
            ) {
              subjects.forEach { sub ->
                DropdownMenuItem(
                  text = { Text(sub.name, fontSize = 13.sp) },
                  onClick = {
                    selectedSubject = sub
                    selectedChapter = sub.chapters.first()
                    subjectDropdownExpanded = false
                  }
                )
              }
            }
          }

          // Chapter Picker
          Box(
            modifier = Modifier
              .weight(1.2f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
              .clickable { chapterDropdownExpanded = true }
              .padding(horizontal = 10.dp, vertical = 8.dp)
              .testTag("pyq_chapter_selector")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = stringResource(R.string.chapter), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Text(text = selectedChapter.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, maxLines = 1)
              }
              Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            DropdownMenu(
              expanded = chapterDropdownExpanded,
              onDismissRequest = { chapterDropdownExpanded = false }
            ) {
              selectedSubject.chapters.forEach { ch ->
                DropdownMenuItem(
                  text = { Text(ch.title, fontSize = 13.sp) },
                  onClick = {
                    selectedChapter = ch
                    chapterDropdownExpanded = false
                  }
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // 2. YEAR FILTER BAR (2013 to 2026)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(filterScrollState)
        .padding(vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      yearsList.forEach { yr ->
        val isSelected = yr == selectedYearFilter
        val chipBg = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant
        val chipBorder = if (isSelected) MaterialTheme.colorScheme.surface else DarkBorder
        val textColor = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(chipBg)
            .border(1.dp, chipBorder, RoundedCornerShape(8.dp))
            .clickable { selectedYearFilter = yr }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("pyq_year_chip_$yr")
        ) {
          Text(
            text = yr,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Count Tag
    Text(
      text = "Showing ${filteredPyqs.size} Authentic PYQ Question${if (filteredPyqs.size != 1) "s" else ""} ($selectedYearFilter)",
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = TextMuted,
      modifier = Modifier.padding(bottom = 10.dp)
    )

    // 3. LIST OF AUTHENTIC PYQs
    if (filteredPyqs.isEmpty()) {
      Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(text = "No PYQs found for $selectedYearFilter in ${selectedChapter.title}", fontSize = 13.sp, color = TextMuted)
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = { selectedYearFilter = "All Years" },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text("Show All Years (2013-2026)", fontSize = 12.sp, color = Color.White)
          }
        }
      }
    } else {
      filteredPyqs.forEachIndexed { qIndex, question ->
        val userAns = userSelectedAnswers[question.id]

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .testTag("pyq_card_${question.id}"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (userAns != null) {
              if (userAns == question.correctAnswerIndex) StatusGreen else ErrorRed
            } else MaterialTheme.colorScheme.outline
          )
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Year Tag & Verification Badge
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x260284C7))
                    .border(1.dp, Color(0x660284C7), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = question.year ?: "UPSC Prelims",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF38BDF8)
                  )
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Verified, contentDescription = "Official", tint = StatusGreen, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Official UPSC Key", fontSize = 10.sp, color = StatusGreen, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = question.questionText,
              style = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 22.sp, color = MaterialTheme.colorScheme.onSurface),
              fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Options
            question.options.forEachIndexed { optIdx, optText ->
              val isSelected = userAns == optIdx
              val isCorrect = optIdx == question.correctAnswerIndex

              val optionBg = when {
                userAns != null && isCorrect -> StatusGreen.copy(alpha = 0.2f)
                userAns != null && isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.2f)
                isSelected -> Color(0x330284C7)
                else -> MaterialTheme.colorScheme.surfaceVariant
              }

              val optionBorder = when {
                userAns != null && isCorrect -> StatusGreen
                userAns != null && isSelected && !isCorrect -> ErrorRed
                isSelected -> Color(0xFF38BDF8)
                else -> MaterialTheme.colorScheme.outline
              }

              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(optionBg)
                  .border(1.dp, optionBorder, RoundedCornerShape(10.dp))
                  .clickable {
                    userSelectedAnswers[question.id] = optIdx
                  }
                  .padding(12.dp)
                  .testTag("pyq_${question.id}_opt_$optIdx")
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  RadioButton(
                    selected = isSelected,
                    onClick = { userSelectedAnswers[question.id] = optIdx },
                    colors = RadioButtonDefaults.colors(
                      selectedColor = Color(0xFF38BDF8),
                      unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = optText,
                    fontSize = 13.sp,
                    color = if (isSelected || (userAns != null && isCorrect)) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (isSelected || (userAns != null && isCorrect)) FontWeight.SemiBold else FontWeight.Normal,
                    lineHeight = 18.sp
                  )
                }
              }
            }

            // Official Explanation when answered
            if (userAns != null) {
              Spacer(modifier = Modifier.height(12.dp))
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(MaterialTheme.colorScheme.surfaceVariant)
                  .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                  .padding(12.dp)
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Key", tint = StatusGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Official UPSC Explanation:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = StatusGreen)
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(text = question.explanation, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 17.sp)
                }
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))
  }
}
