package com.prepcivil.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prepcivil.app.ui.theme.*

@Composable
fun StorePane(
    isProUser: Boolean = false,
    activePlanType: String = if (isProUser) "monthly" else "free",
    onOpenUpgradeModal: () -> Unit = {},
    onUpgradeMonthly: () -> Unit = onOpenUpgradeModal,
    onUpgradeAnnual: () -> Unit = onOpenUpgradeModal
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PurpleAccent.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Store",
                    tint = PurpleAccent,
                    modifier = Modifier.size(24.dp)
                )
            }
            Column {
                Text(
                    text = "UPSC Study Pass Store",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Choose the right study pass for your civil services preparation",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 1. Free Pass Card
        val isFreeActive = !isProUser || activePlanType.equals("free", ignoreCase = true)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("free_pass_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Free Pass",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "₹0",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Essential access for foundational UPSC preparation.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)

                Spacer(modifier = Modifier.height(16.dp))

                // Access rules
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    StoreFeatureRow("First 2 chapters per subject free")
                    StoreFeatureRow("Total 5 Mains AI evaluations")
                    StoreFeatureRow("Standard SRS Flashcards (preview)")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { /* Free Tier */ },
                    enabled = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("free_pass_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        disabledContentColor = if (isFreeActive) StatusGreen else MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isFreeActive) "★ Current Active Plan" else "Free Tier",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Pro Monthly Pass Card
        val isMonthlyActive = isProUser && (activePlanType.equals("monthly", ignoreCase = true) || activePlanType.equals("pro", ignoreCase = true))
        val isAnnualActive = isProUser && activePlanType.equals("annual", ignoreCase = true)

        val monthlyButtonText = when {
            isMonthlyActive -> "★ Current Active Plan"
            isAnnualActive -> "Active on Annual Plan"
            else -> "Upgrade to Pro Monthly (₹299)"
        }
        val monthlyButtonEnabled = !isProUser

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("pro_monthly_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, PurpleAccent)
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pro Monthly Pass",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurpleAccent
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₹299",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "₹399",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textDecoration = TextDecoration.LineThrough
                            )
                            Text(
                                text = " / month",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Billed Monthly • Cancel anytime",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)

                Spacer(modifier = Modifier.height(16.dp))

                // Exact Pro Feature List (No "Unlimited")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    StoreFeatureRow("Full access to all GS chapters (Laxmikanth, Spectrum, NCERTs)")
                    StoreFeatureRow("All daily SRS flashcard reviews")
                    StoreFeatureRow("Dual register canvas & note drawing export")
                    StoreFeatureRow("Detailed quiz analytics & UPSC question solutions")
                    StoreFeatureRow("Full Mains AI evaluation access")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onUpgradeMonthly,
                    enabled = monthlyButtonEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("pro_monthly_upgrade_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PurpleAccent,
                        disabledContainerColor = PurpleAccent.copy(alpha = 0.5f),
                        contentColor = Color.White,
                        disabledContentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!isMonthlyActive && !isAnnualActive) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = monthlyButtonText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Pro Annual Pass Card
        val annualButtonText = when {
            isAnnualActive -> "★ Current Active Plan"
            isMonthlyActive -> "Active on Monthly Plan"
            else -> "Get Pro Annual Pass (₹1,999)"
        }
        val annualButtonEnabled = !isProUser

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("pro_annual_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, StatusGreen)
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Pro Annual Pass",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusGreen
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(StatusGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "50% OFF",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusGreen
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₹1,999",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "₹3,999",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textDecoration = TextDecoration.LineThrough
                            )
                            Text(
                                text = " / year",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Billed Annually • Best value for serious aspirants",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)

                Spacer(modifier = Modifier.height(16.dp))

                // Exact Pro Feature List (No "Unlimited") - exact same feature list as monthly
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    StoreFeatureRow("Full access to all GS chapters (Laxmikanth, Spectrum, NCERTs)")
                    StoreFeatureRow("All daily SRS flashcard reviews")
                    StoreFeatureRow("Dual register canvas & note drawing export")
                    StoreFeatureRow("Detailed quiz analytics & UPSC question solutions")
                    StoreFeatureRow("Full Mains AI evaluation access")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onUpgradeAnnual,
                    enabled = annualButtonEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("pro_annual_upgrade_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StatusGreen,
                        disabledContainerColor = StatusGreen.copy(alpha = 0.5f),
                        contentColor = Color.Black,
                        disabledContentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!isMonthlyActive && !isAnnualActive) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = annualButtonText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun StoreFeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = StatusGreen,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}
