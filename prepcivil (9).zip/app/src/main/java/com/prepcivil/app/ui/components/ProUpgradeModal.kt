package com.prepcivil.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.prepcivil.app.ui.theme.DarkBackground
import com.prepcivil.app.ui.theme.DarkBorder
import com.prepcivil.app.ui.theme.DarkContainer
import com.prepcivil.app.ui.theme.DarkPurpleText
import com.prepcivil.app.ui.theme.PurpleAccent
import com.prepcivil.app.ui.theme.StatusGreen
import com.prepcivil.app.ui.theme.TextMuted
import com.prepcivil.app.ui.theme.TextPrimary
import com.prepcivil.app.ui.theme.TextSecondary

@Composable
fun ProUpgradeModal(
  onDismiss: () -> Unit,
  onUpgradeSuccess: (String) -> Unit
) {
  var isYearlyPlan by remember { mutableStateOf(true) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = DarkContainer,
      border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 4.dp, vertical = 12.dp)
        .testTag("pro_upgrade_modal")
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Header with Close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PurpleAccent),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = "Pro Pass",
                tint = DarkPurpleText,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "PrepCivil Pro Pass",
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = PurpleAccent
            )
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(28.dp).testTag("close_pro_modal_button")
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = TextMuted
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Unlock Full Civil Services Syllabus Access",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "Choose a launch offer plan to get instant unlimited access to all subjects, SRS flashcards, and study tools.",
          fontSize = 11.sp,
          color = TextSecondary,
          textAlign = TextAlign.Center,
          lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Two distinct Pricing Cards side-by-side
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Card 1: Pro Monthly
          val isMonthlySelected = !isYearlyPlan
          Card(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(14.dp))
              .clickable { isYearlyPlan = false }
              .testTag("monthly_plan_tab"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isMonthlySelected) Color(0xFF26203A) else DarkBackground
            ),
            border = androidx.compose.foundation.BorderStroke(
              width = if (isMonthlySelected) 2.dp else 1.dp,
              color = if (isMonthlySelected) PurpleAccent else DarkBorder
            )
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              horizontalAlignment = Alignment.Start
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Pro Monthly",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isMonthlySelected) PurpleAccent else TextPrimary
                )
                if (isMonthlySelected) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = PurpleAccent,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "₹299",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "₹399",
                  fontSize = 10.sp,
                  color = TextMuted,
                  style = androidx.compose.ui.text.TextStyle(textDecoration = TextDecoration.LineThrough)
                )
                Text(text = " / month", fontSize = 10.sp, color = TextMuted)
              }
            }
          }

          // Card 2: Pro Annual (Full Package)
          val isAnnualSelected = isYearlyPlan
          Card(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(14.dp))
              .clickable { isYearlyPlan = true }
              .testTag("yearly_plan_tab"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isAnnualSelected) Color(0xFF1E2E28) else DarkBackground
            ),
            border = androidx.compose.foundation.BorderStroke(
              width = if (isAnnualSelected) 2.dp else 1.dp,
              color = if (isAnnualSelected) StatusGreen else DarkBorder
            )
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              horizontalAlignment = Alignment.Start
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Pro Annual",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isAnnualSelected) StatusGreen else TextPrimary
                )
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(StatusGreen)
                    .padding(horizontal = 3.dp, vertical = 1.dp)
                ) {
                  Text(
                    text = "50% OFF",
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "₹1,999",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "₹3,999",
                  fontSize = 10.sp,
                  color = TextMuted,
                  style = androidx.compose.ui.text.TextStyle(textDecoration = TextDecoration.LineThrough)
                )
                Text(text = " / year", fontSize = 10.sp, color = TextMuted)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Feature checklist
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FeatureRow("All GS Chapters Unlocked (Laxmikanth, Spectrum, NCERTs)")
          FeatureRow("Unlimited Daily SRS Flashcard Reviews")
          FeatureRow("Dual Register Canvas & Note Drawing Export")
          FeatureRow("Detailed Quiz Analytics & UPSC Question Solutions")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // CTA Button
        Button(
          onClick = {
            onUpgradeSuccess(if (isYearlyPlan) "annual" else "monthly")
            onDismiss()
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .testTag("get_pro_pass_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isYearlyPlan) StatusGreen else PurpleAccent
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = "Pro Pass",
              tint = Color.Black,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isYearlyPlan) "Get Pro Annual — ₹1,999" else "Get Pro Monthly — ₹299",
              color = Color.Black,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Instant Activation • Money-back Guarantee",
          fontSize = 10.sp,
          color = TextMuted
        )
      }
    }
  }
}

@Composable
private fun FeatureRow(text: String) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Icon(
      imageVector = Icons.Default.CheckCircle,
      contentDescription = "Included",
      tint = StatusGreen,
      modifier = Modifier.size(16.dp)
    )
    Text(
      text = text,
      fontSize = 12.sp,
      color = TextPrimary,
      fontWeight = FontWeight.Medium
    )
  }
}

