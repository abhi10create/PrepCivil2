package com.prepcivil.app.ui.components

import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import com.prepcivil.app.db.AppSyncRepository
import com.prepcivil.app.model.Chapter
import com.prepcivil.app.model.Subject
import com.prepcivil.app.model.WorkspaceViewMode

@Composable
fun WorkspaceSplitScreenView(
    selectedSubject: Subject,
    subjects: List<Subject>,
    onSubjectSelected: (Subject) -> Unit,
    selectedChapter: Chapter,
    chapters: List<Chapter>,
    onChapterSelected: (Chapter) -> Unit,
    completedChapterIds: Set<String>,
    onToggleChapterCompleted: (String) -> Unit,
    isProUser: Boolean,
    onOpenUpgradeModal: () -> Unit,
    isZenMode: Boolean,
    onToggleZenMode: () -> Unit,
    syncRepository: AppSyncRepository,
    isDarkMode: Boolean = false
) {
    val isCompleted = completedChapterIds.contains(selectedChapter.id)
    var viewMode by remember { mutableStateOf(WorkspaceViewMode.SPLIT) }
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        when (viewMode) {
            WorkspaceViewMode.FULL_READER -> {
                ReaderPane(
                    chapter = selectedChapter,
                    isZenMode = isZenMode,
                    onToggleZenMode = onToggleZenMode,
                    isProUser = isProUser,
                    onOpenUpgradeModal = onOpenUpgradeModal,
                    isChapterCompleted = isCompleted,
                    onToggleChapterCompleted = {
                        onToggleChapterCompleted(selectedChapter.id)
                    },
                    syncRepository = syncRepository,
                    viewMode = viewMode,
                    onSetViewMode = { viewMode = it },
                    isDarkMode = isDarkMode,
                    modifier = Modifier.fillMaxSize()
                )
            }
            WorkspaceViewMode.FULL_CANVAS -> {
                ERegisterCanvasPane(
                    chapterId = selectedChapter.id,
                    syncRepository = syncRepository,
                    viewMode = viewMode,
                    onSetViewMode = { viewMode = it },
                    modifier = Modifier.fillMaxSize()
                )
            }
            WorkspaceViewMode.SPLIT -> {
                if (isLandscape) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.fillMaxHeight().weight(0.3f)) {
                            ReaderPane(
                                chapter = selectedChapter,
                                isZenMode = isZenMode,
                                onToggleZenMode = onToggleZenMode,
                                isProUser = isProUser,
                                onOpenUpgradeModal = onOpenUpgradeModal,
                                isChapterCompleted = isCompleted,
                                onToggleChapterCompleted = {
                                    onToggleChapterCompleted(selectedChapter.id)
                                },
                                syncRepository = syncRepository,
                                viewMode = viewMode,
                                onSetViewMode = { viewMode = it },
                                isDarkMode = isDarkMode,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Box(modifier = Modifier.fillMaxHeight().weight(0.7f)) {
                            ERegisterCanvasPane(
                                chapterId = selectedChapter.id,
                                syncRepository = syncRepository,
                                viewMode = viewMode,
                                onSetViewMode = { viewMode = it },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.fillMaxWidth().weight(0.5f)) {
                            ReaderPane(
                                chapter = selectedChapter,
                                isZenMode = isZenMode,
                                onToggleZenMode = onToggleZenMode,
                                isProUser = isProUser,
                                onOpenUpgradeModal = onOpenUpgradeModal,
                                isChapterCompleted = isCompleted,
                                onToggleChapterCompleted = {
                                    onToggleChapterCompleted(selectedChapter.id)
                                },
                                syncRepository = syncRepository,
                                viewMode = viewMode,
                                onSetViewMode = { viewMode = it },
                                isDarkMode = isDarkMode,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Box(modifier = Modifier.fillMaxWidth().weight(0.5f)) {
                            ERegisterCanvasPane(
                                chapterId = selectedChapter.id,
                                syncRepository = syncRepository,
                                viewMode = viewMode,
                                onSetViewMode = { viewMode = it },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
    }
}

